<?xml version="1.0" ?><!DOCTYPE TS><TS language="eu" version="2.0">
<context>
    <name>FolderWizardSourcePage</name>
    <message>
        <location filename="../src/gui/folderwizardsourcepage.ui" line="14"/>
        <source>Form</source>
        <translation>Formularioa</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardsourcepage.ui" line="33"/>
        <source>Pick a local folder on your computer to sync</source>
        <translation>Hautatu zure ordenagailuko karpeta lokala sinkronizatzeko</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardsourcepage.ui" line="44"/>
        <source>&amp;Choose...</source>
        <translation>&amp;Aukeratu...</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardsourcepage.ui" line="55"/>
        <source>&amp;Directory alias name:</source>
        <translation>&amp;Karpetaren ezizena:</translation>
    </message>
</context>
<context>
    <name>FolderWizardTargetPage</name>
    <message>
        <location filename="../src/gui/folderwizardtargetpage.ui" line="14"/>
        <source>Form</source>
        <translation>Formularioa</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardtargetpage.ui" line="128"/>
        <source>Select a remote destination folder</source>
        <translation>Hautatu hurruneko helburu karpeta</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardtargetpage.ui" line="140"/>
        <source>Create Folder</source>
        <translation>Sortu Karpeta</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardtargetpage.ui" line="160"/>
        <source>Refresh</source>
        <translation>Birkargatu</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardtargetpage.ui" line="174"/>
        <source>Folders</source>
        <translation>Karpetak</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardtargetpage.ui" line="107"/>
        <source>TextLabel</source>
        <translation>TestuEtiketa</translation>
    </message>
</context>
<context>
    <name>OCC::AccountSettings</name>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="14"/>
        <source>Form</source>
        <translation>Formularioa</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="20"/>
        <source>Account to Synchronize</source>
        <translation>Sinkronizatzeko Kontua</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="41"/>
        <source>Connected with &lt;server&gt; as &lt;user&gt;</source>
        <translation>&lt;user&gt; bezala &lt;server&gt;-n konektatuta</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="55"/>
        <source>Add Folder...</source>
        <translation>Gehitu Karpeta...</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="62"/>
        <location filename="../src/gui/accountsettings.cpp" line="167"/>
        <source>Pause</source>
        <translation>Pausarazi</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="69"/>
        <source>Remove</source>
        <translation>Ezabatu</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="76"/>
        <source>Choose What to Sync</source>
        <translation>Hautatu zer sinkronizatu</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="101"/>
        <source>Storage Usage</source>
        <translation>Biltegiratze Erabilera</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="123"/>
        <source>Retrieving usage information...</source>
        <translation>Erabileraren informazioa eskuratzen...</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="130"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; Some folders, including network mounted or shared folders, might have different limits.</source>
        <translation>&lt;b&gt;Oharra:&lt;/b&gt;Karpeta batzuk, sarekoa edo partekatutakoak, muga ezberdinak izan ditzazkete.</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="143"/>
        <source>Account Maintenance</source>
        <translation>Kontuaren Mantenua</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="152"/>
        <source>Edit Ignored Files</source>
        <translation>Editatu Baztertutako Fitxategiak</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="159"/>
        <source>Modify Account</source>
        <translation>Aldatu Kontua</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="111"/>
        <source>No account configured.</source>
        <translation>Ez da konturik konfiguratu.</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="169"/>
        <source>Resume</source>
        <translation>Berrekin</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="338"/>
        <source>Confirm Folder Remove</source>
        <translation>Baieztatu karpetaren ezabatzea</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="339"/>
        <source>&lt;p&gt;Do you really want to stop syncing the folder &lt;i&gt;%1&lt;/i&gt;?&lt;/p&gt;&lt;p&gt;&lt;b&gt;Note:&lt;/b&gt; This will not remove the files from your client.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Bentan nahi duzu karpetaren sinkronizazioa gelditu? &lt;i&gt;%1&lt;/i&gt;?&lt;/p&gt;&lt;p&gt;&lt;b&gt;Oharra:&lt;/b&gt;Honek ez du fitxategiak zure bezerotik ezabatuko.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="375"/>
        <source>Confirm Folder Reset</source>
        <translation>Baieztatu Karpetaren Leheneratzea</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="376"/>
        <source>&lt;p&gt;Do you really want to reset folder &lt;i&gt;%1&lt;/i&gt; and rebuild your client database?&lt;/p&gt;&lt;p&gt;&lt;b&gt;Note:&lt;/b&gt; This function is designed for maintenance purposes only. No files will be removed, but this can cause significant data traffic and take several minutes or hours to complete, depending on the size of the folder. Only use this option if advised by your administrator.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Benetan nahi duzu &lt;i&gt;%1&lt;/i&gt; karpeta leheneratu eta zure bezeroaren datu basea berreraiki?&lt;/p&gt;&lt;p&gt;&lt;b&gt;Oharra:&lt;/p&gt; Funtzio hau mantenurako bakarrik diseinauta izan da. Ez da fitxategirik ezabatuko, baina honek datu trafiko handia sor dezake eta minutu edo ordu batzuk behar izango ditu burutzeko, karpetaren tamainaren arabera. Erabili aukera hau bakarrik zure kudeatzaileak esanez gero.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="486"/>
        <source>Sync Running</source>
        <translation>Sinkronizazioa martxan da</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="487"/>
        <source>The syncing operation is running.&lt;br/&gt;Do you want to terminate it?</source>
        <translation>Sinkronizazio martxan da.&lt;br/&gt;Bukatu nahi al duzu?</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="610"/>
        <source>Discovering &apos;%1&apos;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="650"/>
        <source>%1 %2 (%3 of %4) %5 left at a rate of %6/s</source>
        <extracomment>Example text: &quot;uploading foobar.png (1MB of 2MB) time left 2 minutes at a rate of 24Kb/s&quot;</extracomment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="656"/>
        <source>%1 %2 (%3 of %4)</source>
        <extracomment>Example text: &quot;uploading foobar.png (2MB of 2MB)&quot;</extracomment>
        <translation>%1 %2 (%4 - %3tik)</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="660"/>
        <source>%1 %2</source>
        <extracomment>Example text: &quot;uploading foobar.png&quot;</extracomment>
        <translation>%1 %2</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="675"/>
        <source>%1 of %2, file %3 of %4
Total time left %5</source>
        <translation> %2-tik %1,  %4-tik %3 fitxategi
Geratzen den denbora %5</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="681"/>
        <source>file %1 of %2</source>
        <translation>%1. fitxategia %2tik</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="769"/>
        <source>%1 (%3%) of %2 server space in use.</source>
        <translation>%1 (%3%) tik %2 zerbitzariko lekua erabilia</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="773"/>
        <source>Currently there is no storage usage information available.</source>
        <translation>Orain ez dago eskuragarri biltegiratze erabileraren informazioa.</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="806"/>
        <source>Connected to &lt;a href=&quot;%1&quot;&gt;%2&lt;/a&gt;.</source>
        <translation>&lt;a href=&quot;%1&quot;&gt;%2&lt;/a&gt;ra konektatuta.</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="809"/>
        <source>Connected to &lt;a href=&quot;%1&quot;&gt;%2&lt;/a&gt; as &lt;i&gt;%3&lt;/i&gt;.</source>
        <translation> &lt;a href=&quot;%1&quot;&gt;%2&lt;/a&gt;ra konektatuta &lt;i&gt;%3&lt;/i&gt; erabiltzailearekin.</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="813"/>
        <source>No connection to %1 at &lt;a href=&quot;%2&quot;&gt;%3&lt;/a&gt;.</source>
        <translation>Ez dago %1-ra konexiorik hemendik &lt;a href=&quot;%2&quot;&gt;%3&lt;/a&gt;.</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="820"/>
        <source>No %1 connection configured.</source>
        <translation>Ez dago %1 konexiorik konfiguratuta.</translation>
    </message>
</context>
<context>
    <name>OCC::AddCertificateDialog</name>
    <message>
        <location filename="../src/gui/addcertificatedialog.ui" line="17"/>
        <source>SSL client certificate authentication</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/addcertificatedialog.ui" line="23"/>
        <source>This server probably requires a SSL client certificate.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/addcertificatedialog.ui" line="35"/>
        <source>Certificate :</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/addcertificatedialog.ui" line="51"/>
        <source>Browse...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/addcertificatedialog.ui" line="60"/>
        <source>Certificate password :</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/addcertificatedialog.cpp" line="23"/>
        <source>Select a certificate</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/addcertificatedialog.cpp" line="23"/>
        <source>Certificate files (*.p12 *.pfx)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::AuthenticationDialog</name>
    <message>
        <location filename="../src/libsync/authenticationdialog.cpp" line="29"/>
        <source>Authentication Required</source>
        <translation>Autentikazioa beharrezkoa</translation>
    </message>
    <message>
        <location filename="../src/libsync/authenticationdialog.cpp" line="31"/>
        <source>Enter username and password for &apos;%1&apos; at %2.</source>
        <translation>Sartu erabiltzaile izena eta pasahitza &apos;%1&apos;-rentzat hemen: %2.</translation>
    </message>
    <message>
        <location filename="../src/libsync/authenticationdialog.cpp" line="35"/>
        <source>&amp;User:</source>
        <translation>&amp;Erabiltzailea:</translation>
    </message>
    <message>
        <location filename="../src/libsync/authenticationdialog.cpp" line="36"/>
        <source>&amp;Password:</source>
        <translation>&amp;Pasahitza:</translation>
    </message>
</context>
<context>
    <name>OCC::ConnectionValidator</name>
    <message>
        <location filename="../src/libsync/connectionvalidator.cpp" line="63"/>
        <source>No ownCloud account configured</source>
        <translation>Ez dago ownCloud konturik konfiguratuta</translation>
    </message>
    <message>
        <location filename="../src/libsync/connectionvalidator.cpp" line="86"/>
        <source>The configured server for this client is too old</source>
        <translation>Bezero honentzako konfiguratutako zerbitzaria oso zaharra da</translation>
    </message>
    <message>
        <location filename="../src/libsync/connectionvalidator.cpp" line="87"/>
        <source>Please update to the latest server and restart the client.</source>
        <translation>Mesedez eguneratu zerbitzarira eta berrabiarazi bezeroa.</translation>
    </message>
    <message>
        <location filename="../src/libsync/connectionvalidator.cpp" line="106"/>
        <location filename="../src/libsync/connectionvalidator.cpp" line="113"/>
        <source>Unable to connect to %1</source>
        <translation>Ezin izan da %1ra konektatu</translation>
    </message>
    <message>
        <location filename="../src/libsync/connectionvalidator.cpp" line="114"/>
        <source>timeout</source>
        <translation>denbora iraungi da</translation>
    </message>
    <message>
        <location filename="../src/libsync/connectionvalidator.cpp" line="147"/>
        <source>The provided credentials are not correct</source>
        <translation>Emandako kredentzialak ez dira zuzenak</translation>
    </message>
</context>
<context>
    <name>OCC::DeleteJob</name>
    <message>
        <location filename="../src/libsync/propagateremotedelete.cpp" line="41"/>
        <source>Connection timed out</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::Folder</name>
    <message>
        <location filename="../src/gui/folder.cpp" line="107"/>
        <source>Unable to create csync-context</source>
        <translation>Ezin da csync-context sortu</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="162"/>
        <source>Local folder %1 does not exist.</source>
        <translation>Bertako %1 karpeta ez da existitzen.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="165"/>
        <source>%1 should be a directory but is not.</source>
        <translation>%1 karpeta bat izan behar zen baina ez da.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="168"/>
        <source>%1 is not readable.</source>
        <translation>%1 ezin da irakurri.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="359"/>
        <source>%1: %2</source>
        <translation>%1: %2</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="459"/>
        <source>%1 and %2 other files have been removed.</source>
        <comment>%1 names a file.</comment>
        <translation>%1 eta  beste %2 fitxategi ezabatu dira.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="461"/>
        <source>%1 has been removed.</source>
        <comment>%1 names a file.</comment>
        <translation>%1 ezabatua izan da.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="466"/>
        <source>%1 and %2 other files have been downloaded.</source>
        <comment>%1 names a file.</comment>
        <translation>%1 eta  beste %2 fitxategi deskargatu dira.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="468"/>
        <source>%1 has been downloaded.</source>
        <comment>%1 names a file.</comment>
        <translation>%1 deskargatu da.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="473"/>
        <source>%1 and %2 other files have been updated.</source>
        <translation>%1 eta  beste %2 fitxategi kargatu dira.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="475"/>
        <source>%1 has been updated.</source>
        <comment>%1 names a file.</comment>
        <translation>%1 kargatu da.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="480"/>
        <source>%1 has been renamed to %2 and %3 other files have been renamed.</source>
        <translation>%1  %2-(e)ra berrizendatu da eta beste %3 fitxategi berrizendatu dira.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="482"/>
        <source>%1 has been renamed to %2.</source>
        <comment>%1 and %2 name files.</comment>
        <translation>%1  %2-(e)ra berrizendatu da.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="487"/>
        <source>%1 has been moved to %2 and %3 other files have been moved.</source>
        <translation>%1  %2-(e)ra berrizendatu da eta beste %3 fitxategi mugitu dira.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="489"/>
        <source>%1 has been moved to %2.</source>
        <translation>%1 %2-(e)ra mugitu da.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="494"/>
        <source>%1 and %2 other files could not be synced due to errors. See the log for details.</source>
        <comment>%1 names a file.</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="496"/>
        <source>%1 could not be synced due to an error. See the log for details.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="504"/>
        <source>Sync Activity</source>
        <translation>Sinkronizazio Jarduerak</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="782"/>
        <source>Could not read system exclude file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="1002"/>
        <source>This sync would remove all the files in the sync folder '%1'.
This might be because the folder was silently reconfigured, or that all the file were manually removed.
Are you sure you want to perform this operation?</source>
        <translation>Sinkronizazioak &apos;%1&apos;  sinkronizazio karpetako fitxategi guztiak ezabatuko ditu.
Izan daiteke karpeta isilpean birkonfiguratu delako edo fitxategi guztiak eskuz ezabatu direlako.
Ziur zaude eragiketa hau egin nahi duzula?</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="1006"/>
        <source>Remove All Files?</source>
        <translation>Ezabatu Fitxategi Guztiak?</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="1008"/>
        <source>Remove all files</source>
        <translation>Ezabatu fitxategi guztiak</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="1009"/>
        <source>Keep files</source>
        <translation>Mantendu fitxategiak</translation>
    </message>
</context>
<context>
    <name>OCC::FolderMan</name>
    <message>
        <location filename="../src/gui/folderman.cpp" line="232"/>
        <source>Could not reset folder state</source>
        <translation>Ezin izan da karpetaren egoera berrezarri</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="233"/>
        <source>An old sync journal &apos;%1&apos; was found, but could not be removed. Please make sure that no application is currently using it.</source>
        <translation>Aurkitu da &apos;%1&apos; sinkronizazio erregistro zaharra, baina ezin da ezabatu. Ziurtatu aplikaziorik ez dela erabiltzen ari.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1021"/>
        <source>Undefined State.</source>
        <translation>Definitu gabeko egoera.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1024"/>
        <source>Waits to start syncing.</source>
        <translation>Itxoiten sinkronizazioa hasteko.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1027"/>
        <source>Preparing for sync.</source>
        <translation>Sinkronizazioa prestatzen.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1030"/>
        <source>Sync is running.</source>
        <translation>Sinkronizazioa martxan da.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1033"/>
        <source>Last Sync was successful.</source>
        <translation>Azkeneko sinkronizazioa ongi burutu zen.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1038"/>
        <source>Last Sync was successful, but with warnings on individual files.</source>
        <translation>Azkenengo sinkronizazioa ongi burutu zen, baina banakako fitxategi batzuetan abisuak egon dira.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1041"/>
        <source>Setup Error.</source>
        <translation>Konfigurazio errorea.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1044"/>
        <source>User Abort.</source>
        <translation>Erabiltzaileak bertan behera utzi.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1047"/>
        <source>Sync is paused.</source>
        <translation>Sinkronizazioa pausatuta dago.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1053"/>
        <source>%1 (Sync is paused)</source>
        <translation>%1 (Sinkronizazioa pausatuta dago)</translation>
    </message>
</context>
<context>
    <name>OCC::FolderStatusDelegate</name>
    <message>
        <location filename="../src/gui/folderstatusmodel.cpp" line="95"/>
        <location filename="../src/gui/folderstatusmodel.cpp" line="264"/>
        <source>File</source>
        <translation>Fitxategia</translation>
    </message>
    <message>
        <location filename="../src/gui/folderstatusmodel.cpp" line="218"/>
        <source>Syncing all files in your account with</source>
        <translation>Fitxategi guztiak sinkronizatzen zure kontuan honekin</translation>
    </message>
    <message>
        <location filename="../src/gui/folderstatusmodel.cpp" line="221"/>
        <source>Remote path: %1</source>
        <translation>Urruneko bidea: %1</translation>
    </message>
</context>
<context>
    <name>OCC::FolderWizard</name>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="502"/>
        <location filename="../src/gui/folderwizard.cpp" line="504"/>
        <source>Add Folder</source>
        <translation>Gehitu Karpeta</translation>
    </message>
</context>
<context>
    <name>OCC::FolderWizardLocalPath</name>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="63"/>
        <source>Click to select a local folder to sync.</source>
        <translation>Klikatu sinkronizatzeko bertako karpeta bat sinkronizatzeko.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="67"/>
        <source>Enter the path to the local folder.</source>
        <translation>Sartu bertako karpeta berriaren bidea:</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="71"/>
        <source>The directory alias is a descriptive name for this sync connection.</source>
        <translation>Direktorioaren ezizena sinkronizazio konexioaren izen deskriptiboa da.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="100"/>
        <source>No valid local folder selected!</source>
        <translation>Ez da bertako karpeta egokirik hautatu!</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="105"/>
        <source>You have no permission to write to the selected folder!</source>
        <translation>Ez daukazu hautatutako karpetan idazteko baimenik!</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="129"/>
        <source>The local path %1 is already an upload folder. Please pick another one!</source>
        <translation>%1 sarbidean badago kargatzeko karpeta bat. Hautatu beste bat!</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="134"/>
        <source>An already configured folder is contained in the current entry.</source>
        <translation>Karpeta honek dagoeneko konfiguratuta dagoen beste karpeta bat du barnean</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="141"/>
        <source>The selected folder is a symbolic link. An already configured folder is contained in the folder this link is pointing to.</source>
        <translation>Hautatutako karpeta esteka sinboliko bat da. Eta konfituratutako karpeta dagoeneko badago esteka apuntatzen duen karpetan.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="148"/>
        <source>An already configured folder contains the currently entered folder.</source>
        <translation>Karpeta batek dagoeneko barnean du orain sartutako karpeta.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="154"/>
        <source>The selected folder is a symbolic link. An already configured folder is the parent of the current selected contains the folder this link is pointing to.</source>
        <translation>Hautatutako karpeta esteka sinboliko bat da. Eta konfiguratutako karpeta estekak apuntatzen  duen karpetaren gurasoa da. </translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="167"/>
        <source>The alias can not be empty. Please provide a descriptive alias word.</source>
        <translation>Ezizena ezin da hutsa izan. Mesedez jarri hitz esanguratsu bat.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="178"/>
        <source>The alias &lt;i&gt;%1&lt;/i&gt; is already in use. Please pick another alias.</source>
        <translation> &lt;i&gt;%1&lt;/i&gt; ezizena dagoeneko erabiltzen ari da. Hautatu beste ezizen bat.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="211"/>
        <source>Select the source folder</source>
        <translation>Hautatu jatorrizko karpeta</translation>
    </message>
</context>
<context>
    <name>OCC::FolderWizardRemotePath</name>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="258"/>
        <source>Create Remote Folder</source>
        <translation>Sortu Urruneko Karpeta</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="259"/>
        <source>Enter the name of the new folder to be created below &apos;%1&apos;:</source>
        <translation>Sartu behean sortuko den karpeta berriaren izena &apos;%1&apos;:</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="288"/>
        <source>Folder was successfully created on %1.</source>
        <translation>%1-en karpeta ongi sortu da.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="296"/>
        <source>Failed to create the folder on %1. Please check manually.</source>
        <translation>Huts egin du %1-(e)an karpeta sortzen. Egiaztatu eskuz.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="345"/>
        <source>Choose this to sync the entire account</source>
        <translation>Hautatu hau kontu osoa sinkronizatzeko</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="400"/>
        <source>This folder is already being synced.</source>
        <translation>Karpeta hau dagoeneko sinkronizatzen ari da.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="402"/>
        <source>You are already syncing &lt;i&gt;%1&lt;/i&gt;, which is a parent folder of &lt;i&gt;%2&lt;/i&gt;.</source>
        <translation>Dagoeneko  &lt;i&gt;%1&lt;/i&gt; sinkronizatzen ari zara, &lt;i&gt;%2&lt;/i&gt;-ren guraso karpeta dena.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="406"/>
        <source>You are already syncing all your files. Syncing another folder is &lt;b&gt;not&lt;/b&gt; supported. If you want to sync multiple folders, please remove the currently configured root folder sync.</source>
        <translation>Dagoeneko fitxategi guztiak sinkronizatzen ari zara. &lt;b&gt;Ezin&lt;b&gt; da sinkronizatu beste karpeta bat. Hainbat karpeta batera sinkronizatu nahi baduzu ezaba ezazu orain konfiguratuta duzun sinkronizazio karpeta nagusia.</translation>
    </message>
</context>
<context>
    <name>OCC::FolderWizardSelectiveSync</name>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="444"/>
        <source>Choose What to Sync: You can optionally deselect remote subfolders you do not wish to synchronize.</source>
        <translation>Hautatu zer nahi duzun sinkronizatzea: Sinkronizatu nahi ez dituzun urruneko azpikarpetak desmarkatu ditzazkezu.</translation>
    </message>
</context>
<context>
    <name>OCC::FormatWarningsWizardPage</name>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="45"/>
        <location filename="../src/gui/folderwizard.cpp" line="47"/>
        <source>&lt;b&gt;Warning:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Abisua:&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>OCC::GETFileJob</name>
    <message>
        <location filename="../src/libsync/propagatedownload.cpp" line="122"/>
        <source>No E-Tag received from server, check Proxy/Gateway</source>
        <translation>Ez da E-Tagik jaso zerbitzaritik, egiaztatu Proxy/Gateway</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagatedownload.cpp" line="129"/>
        <source>We received a different E-Tag for resuming. Retrying next time.</source>
        <translation>Jarraitzeko E-Tag ezberdina jaso dugu. Hurrengoan saiatuko gara berriz.</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagatedownload.cpp" line="156"/>
        <source>Server returned wrong content-range</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/propagatedownload.cpp" line="257"/>
        <source>Connection Timeout</source>
        <translation>Konexioa denboraz kanpo</translation>
    </message>
</context>
<context>
    <name>OCC::GeneralSettings</name>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="14"/>
        <source>Form</source>
        <translation>Formularioa</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="20"/>
        <source>General Settings</source>
        <translation>Ezarpen orokorrak</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="26"/>
        <source>Launch on System Startup</source>
        <translation>Abiarazi Sistemaren Abioan</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="33"/>
        <source>Show Desktop Notifications</source>
        <translation>Erakutsi Mahagaineko Jakinarazpenak</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="40"/>
        <source>Use Monochrome Icons</source>
        <translation>Erabili kolore bakarreko ikonoak</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="47"/>
        <source>Show crash reporter</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="57"/>
        <location filename="../src/gui/generalsettings.ui" line="63"/>
        <source>About</source>
        <translation>Honi buruz</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="73"/>
        <source>Updates</source>
        <translation>Eguneraketak</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="98"/>
        <source>&amp;Restart &amp;&amp; Update</source>
        <translation>Be&amp;rrabiarazi eta Eguneratu</translation>
    </message>
</context>
<context>
    <name>OCC::HttpCredentialsGui</name>
    <message>
        <location filename="../src/libsync/creds/httpcredentials.cpp" line="400"/>
        <source>Enter Password</source>
        <translation>Sartu Pasahitza</translation>
    </message>
    <message>
        <location filename="../src/libsync/creds/httpcredentials.cpp" line="401"/>
        <source>Please enter %1 password for user &apos;%2&apos;:</source>
        <translation>Mesedez sartu %1 pasahitza &apos;%2&apos; erabiltzailerako:</translation>
    </message>
</context>
<context>
    <name>OCC::IgnoreListEditor</name>
    <message>
        <location filename="../src/gui/ignorelisteditor.ui" line="14"/>
        <source>Ignored Files Editor</source>
        <translation>Baztertutako Fitxategien Editorea</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.ui" line="53"/>
        <source>Add</source>
        <translation>Gehitu</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.ui" line="63"/>
        <source>Remove</source>
        <translation>Ezabatu</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="35"/>
        <source>Files or directories matching a pattern will not be synchronized.

Checked items will also be deleted if they prevent a directory from being removed. This is useful for meta data.</source>
        <translation>Eredu bat jarraitzen duten fitxategiak ez dira sinkronizatuko.

Markatutakoak ezabatuko dira karpeta bat ezabatzeko beharrezkoa bada. Hau meta datuentzat interesgarria da.</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="97"/>
        <source>Could not open file</source>
        <translation>Ezin izan da fitxategia ireki</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="98"/>
        <source>Cannot write changes to &apos;%1&apos;.</source>
        <translation>Ezin izan dira aldaketa idatzi hemen &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="105"/>
        <source>Add Ignore Pattern</source>
        <translation>Gehitu Baztertzeko Eredua</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="106"/>
        <source>Add a new ignore pattern:</source>
        <translation>Gehitu baztertzeko eredu berria:</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="128"/>
        <source>Edit Ignore Pattern</source>
        <translation>Editatu Baztertzeko Eredua</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="129"/>
        <source>Edit ignore pattern:</source>
        <translation>Editatu baztertzeko eredua</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="140"/>
        <source>This entry is provided by the system at &apos;%1&apos; and cannot be modified in this view.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::LogBrowser</name>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="59"/>
        <source>Log Output</source>
        <translation>Egunkari Irteera</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="71"/>
        <source>&amp;Search: </source>
        <translation>&amp;Bilatu:</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="79"/>
        <source>&amp;Find</source>
        <translation>&amp;Aurkitu:</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="97"/>
        <source>Clear</source>
        <translation>Garbitu</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="98"/>
        <source>Clear the log display.</source>
        <translation>Garbitu egunkari bistaratzea.</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="104"/>
        <source>S&amp;ave</source>
        <translation>&amp;Gorde</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="105"/>
        <source>Save the log file to a file on disk for debugging.</source>
        <translation>Gorde egunkari fitxategia fitxategi batean arazteko.</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="184"/>
        <source>Save log file</source>
        <translation>Gorde egunkari fitxategia</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="194"/>
        <source>Error</source>
        <translation>Errorea</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="194"/>
        <source>Could not write to log file </source>
        <translation>Ezin da egunkari fitxategia idatzi</translation>
    </message>
</context>
<context>
    <name>OCC::Logger</name>
    <message>
        <location filename="../src/libsync/logger.cpp" line="148"/>
        <source>Error</source>
        <translation>Errorea</translation>
    </message>
    <message>
        <location filename="../src/libsync/logger.cpp" line="149"/>
        <source>&lt;nobr&gt;File &apos;%1&apos;&lt;br/&gt;cannot be opened for writing.&lt;br/&gt;&lt;br/&gt;The log output can &lt;b&gt;not&lt;/b&gt; be saved!&lt;/nobr&gt;</source>
        <translation>&lt;nobr&gt;&apos;%1&apos; Fitxategia&lt;br/&gt; ezin da idazteko ireki.&lt;br/&gt;&lt;br/&gt;Egunkariaren irteera &lt;b&gt;ezin&lt;/b&gt; da gorde!&lt;/nobr&gt;</translation>
    </message>
</context>
<context>
    <name>OCC::MoveJob</name>
    <message>
        <location filename="../src/libsync/propagateremotemove.cpp" line="45"/>
        <source>Connection timed out</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::NSISUpdater</name>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="256"/>
        <source>New Version Available</source>
        <translation>Bertsio berria eskuragarri</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="262"/>
        <source>&lt;p&gt;A new version of the %1 Client is available.&lt;/p&gt;&lt;p&gt;&lt;b&gt;%2&lt;/b&gt; is available for download. The installed version is %3.&lt;/p&gt;</source>
        <translation>&lt;p&gt; %1 bezeroaren bertsio berri bat eskuragarri dago.&lt;/p&gt;&lt;p&gt;&lt;b&gt;%2&lt;/b&gt;deskargatzeko prest dago. Instalatuta dagoen bersioa %3 da.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="275"/>
        <source>Skip this version</source>
        <translation>Ez eguneratu bertsio hau</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="276"/>
        <source>Skip this time</source>
        <translation>Utzi aldi honetan</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="277"/>
        <source>Get update</source>
        <translation>Eskuratu eguneraketa</translation>
    </message>
</context>
<context>
    <name>OCC::NetworkSettings</name>
    <message>
        <location filename="../src/gui/networksettings.ui" line="14"/>
        <source>Form</source>
        <translation>Formularioa</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="23"/>
        <source>Proxy Settings</source>
        <translation>Proxy Ezarpenak</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="29"/>
        <source>No Proxy</source>
        <translation>Proxyrik ez</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="42"/>
        <source>Use system proxy</source>
        <translation>Erabili sistemaren proxya</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="52"/>
        <source>Specify proxy manually as</source>
        <translation>Zehaztu eskuz honako proxy mota</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="80"/>
        <source>Host</source>
        <translation>Ostalaria</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="100"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="134"/>
        <source>Proxy server requires authentication</source>
        <translation>Proxy zerbitzariak autentikazioa behar du</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="190"/>
        <source>Download Bandwidth</source>
        <translation>Deskargatzeko Banda Zabalera</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="196"/>
        <location filename="../src/gui/networksettings.ui" line="278"/>
        <source>Limit to</source>
        <translation>Honetara mugatu</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="218"/>
        <location filename="../src/gui/networksettings.ui" line="320"/>
        <source>KBytes/s</source>
        <translation>KByte/s</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="227"/>
        <location filename="../src/gui/networksettings.ui" line="295"/>
        <source>No limit</source>
        <translation>Mugarik ez</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="272"/>
        <source>Upload Bandwidth</source>
        <translation>Igotzeko Banda Zabalera</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="285"/>
        <source>Limit automatically</source>
        <translation>Automatikoki mugatu</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.cpp" line="34"/>
        <source>Hostname of proxy server</source>
        <translation>Proxy zerbitzariaren hostalari izena</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.cpp" line="35"/>
        <source>Username for proxy server</source>
        <translation>Proxy zerbitzariaren erabiltzaile izena</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.cpp" line="36"/>
        <source>Password for proxy server</source>
        <translation>Proxy zerbitzarirako pasahitza</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.cpp" line="38"/>
        <source>HTTP(S) proxy</source>
        <translation>HTTP(S) proxy</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.cpp" line="39"/>
        <source>SOCKS5 proxy</source>
        <translation>SOCKS5 proxy</translation>
    </message>
</context>
<context>
    <name>OCC::OCUpdater</name>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="55"/>
        <source>New Update Ready</source>
        <translation>Eguneraketa Berria Prest</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="56"/>
        <source>A new update is about to be installed. The updater may ask
for additional privileges during the process.</source>
        <translation>Eguneraketa bat instalatzeko prest dago. Eguneratzaileak
 pribilegio osagarriak eskatzen ahal dizkizu.</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="77"/>
        <source>Downloading version %1. Please wait...</source>
        <translation>%1 Bertsioa deskargatzen. Mesedez itxoin...</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="79"/>
        <source>Version %1 available. Restart application to start the update.</source>
        <translation>%1 Bertsioa eskuragarri. Abiarazi aplikazioa eguneraketa hasteko.</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="81"/>
        <source>Could not download update. Please click &lt;a href=&apos;%1&apos;&gt;here&lt;/a&gt; to download the update manually.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="83"/>
        <source>Could not check for new updates.</source>
        <translation>Ezin da eguneraketarik bilatu.</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="85"/>
        <source>New version %1 available. Please use the system&apos;s update tool to install it.</source>
        <translation>%1 bertsio berria eskuragarri dago. Utziozu sistemaren eguneratzaileari instalatzen.</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="87"/>
        <source>Checking update server...</source>
        <translation>Eguneraketa zerbitzaria galdetzen...</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="89"/>
        <source>Update status is unknown: Did not check for new updates.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="93"/>
        <source>No updates available. Your installation is at the latest version.</source>
        <translation>Ez dago eguneraketarik eskuragarri. Zure instalazioa azkenengo bertsioa da.</translation>
    </message>
</context>
<context>
    <name>OCC::OwncloudAdvancedSetupPage</name>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="50"/>
        <source>Connect to %1</source>
        <translation>%1ra konektatu</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="51"/>
        <source>Setup local folder options</source>
        <translation>Konfiguratu bertako karpeten aukerak</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="60"/>
        <source>Connect...</source>
        <translation>Konektatu...</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="135"/>
        <source>%1 folder &apos;%2&apos; is synced to local folder &apos;%3&apos;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="141"/>
        <source>&lt;p&gt;&lt;small&gt;&lt;strong&gt;Warning:&lt;/strong&gt; You currently have multiple folders configured. If you continue with the current settings, the folder configurations will be discarded and a single root folder sync will be created!&lt;/small&gt;&lt;/p&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="148"/>
        <source>&lt;p&gt;&lt;small&gt;&lt;strong&gt;Warning:&lt;/strong&gt; The local directory is not empty. Pick a resolution!&lt;/small&gt;&lt;/p&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="265"/>
        <source>Local Sync Folder</source>
        <translation>Sinkronizazio karpeta lokala</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="278"/>
        <source>Update advanced setup</source>
        <translation>Eguneratu ezarpen aurreratuak</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="297"/>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="318"/>
        <source>(%1)</source>
        <translation>(%1)</translation>
    </message>
</context>
<context>
    <name>OCC::OwncloudHttpCredsPage</name>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.cpp" line="46"/>
        <source>Connect to %1</source>
        <translation>%1ra konektatu</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.cpp" line="47"/>
        <source>Enter user credentials</source>
        <translation>Sartu erabiltzailearen kredentzialak</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.cpp" line="164"/>
        <source>Update user credentials</source>
        <translation>Eguneratu erabiltzailearen kredentzialak</translation>
    </message>
</context>
<context>
    <name>OCC::OwncloudSetupPage</name>
    <message>
        <location filename="../src/gui/wizard/owncloudsetuppage.cpp" line="50"/>
        <source>Connect to %1</source>
        <translation>%1ra konektatu</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetuppage.cpp" line="51"/>
        <source>Setup %1 server</source>
        <translation>Konfiguratu %1 zerbitzaria</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetuppage.cpp" line="120"/>
        <source>This url is NOT secure as it is not encrypted.
It is not advisable to use it.</source>
        <translation>Url hori EZ da segurua ez baitago kodetuta.
Ez da gomendagarria erabltzea.</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetuppage.cpp" line="124"/>
        <source>This url is secure. You can use it.</source>
        <translation>Url hau segurua da. Berau erabili dezakezu.</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetuppage.cpp" line="163"/>
        <source>&amp;Next &gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetuppage.cpp" line="295"/>
        <source>Update %1 server</source>
        <translation>Eguneratu %1 zerbitzaria</translation>
    </message>
</context>
<context>
    <name>OCC::OwncloudSetupWizard</name>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="161"/>
        <source>&lt;font color=&quot;green&quot;&gt;Successfully connected to %1: %2 version %3 (%4)&lt;/font&gt;&lt;br/&gt;&lt;br/&gt;</source>
        <translation>&lt;font color=&quot;green&quot;&gt;Konexioa ongi burutu da  %1 zerbitzarian: %2 bertsioa %3 (%4)&lt;/font&gt;&lt;br/&gt;&lt;br/&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="185"/>
        <source>Failed to connect to %1 at %2:&lt;br/&gt;%3</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="193"/>
        <source>Timeout while trying to connect to %1 at %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="204"/>
        <source>Trying to connect to %1 at %2...</source>
        <translation>%2 zerbitzarian dagoen %1 konektatzen...</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="253"/>
        <source>Access forbidden by server. To verify that you have proper access, &lt;a href=&quot;%1&quot;&gt;click here&lt;/a&gt; to access the service with your browser.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="275"/>
        <source>Local sync folder %1 already exists, setting it up for sync.&lt;br/&gt;&lt;br/&gt;</source>
        <translation>Bertako %1 karpeta dagoeneko existitzen da, sinkronizaziorako prestatzen.&lt;br/&gt;&lt;br/&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="277"/>
        <source>Creating local sync folder %1... </source>
        <translation>Bertako sinkronizazio %1 karpeta sortzen...</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="281"/>
        <source>ok</source>
        <translation>ados</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="283"/>
        <source>failed.</source>
        <translation>huts egin du.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="285"/>
        <source>Could not create local folder %1</source>
        <translation>Ezin da %1 karpeta lokala sortu</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="310"/>
        <source>No remote folder specified!</source>
        <translation>Ez da urruneko karpeta zehaztu!</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="316"/>
        <source>Error: %1</source>
        <translation>Errorea: %1</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="329"/>
        <source>creating folder on ownCloud: %1</source>
        <translation>ownClouden karpeta sortzen: %1</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="345"/>
        <source>Remote folder %1 created successfully.</source>
        <translation>Urruneko %1 karpeta ongi sortu da.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="347"/>
        <source>The remote folder %1 already exists. Connecting it for syncing.</source>
        <translation>Urruneko %1 karpeta dagoeneko existintzen da. Bertara konetatuko da sinkronizatzeko.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="349"/>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="351"/>
        <source>The folder creation resulted in HTTP error code %1</source>
        <translation>Karpeta sortzeak HTTP %1 errore kodea igorri du</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="353"/>
        <source>The remote folder creation failed because the provided credentials are wrong!&lt;br/&gt;Please go back and check your credentials.&lt;/p&gt;</source>
        <translation>Huts egin du urrutiko karpeta sortzen emandako kredintzialak ez direlako zuzenak!&lt;br/&gt; Egin atzera eta egiaztatu zure kredentzialak.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="356"/>
        <source>&lt;p&gt;&lt;font color=&quot;red&quot;&gt;Remote folder creation failed probably because the provided credentials are wrong.&lt;/font&gt;&lt;br/&gt;Please go back and check your credentials.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;font color=&quot;red&quot;&gt;Urruneko karpeten sortzeak  huts egin du ziuraski emandako kredentzialak gaizki daudelako.&lt;/font&gt;&lt;br/&gt;Mesedez atzera joan eta egiaztatu zure kredentzialak.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="361"/>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="362"/>
        <source>Remote folder %1 creation failed with error &lt;tt&gt;%2&lt;/tt&gt;.</source>
        <translation>Urruneko %1 karpetaren sortzeak huts egin du &lt;tt&gt;%2&lt;/tt&gt; errorearekin.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="378"/>
        <source>A sync connection from %1 to remote directory %2 was set up.</source>
        <translation>Sinkronizazio konexio bat konfiguratu da %1 karpetatik urruneko %2 karpetara.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="383"/>
        <source>Successfully connected to %1!</source>
        <translation>%1-era ongi konektatu da!</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="390"/>
        <source>Connection to %1 could not be established. Please check again.</source>
        <translation>%1 konexioa ezin da ezarri. Mesedez egiaztatu berriz.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="403"/>
        <source>Folder rename failed</source>
        <translation>Karpetaren berrizendatzeak huts egin du</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="404"/>
        <source>Can&apos;t remove and back up the folder because the folder or a file in it is open in another program. Please close the folder or file and hit retry or cancel the setup.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="450"/>
        <source>&lt;font color=&quot;green&quot;&gt;&lt;b&gt;Local sync folder %1 successfully created!&lt;/b&gt;&lt;/font&gt;</source>
        <translation>&lt;font color=&quot;green&quot;&gt;&lt;b&gt;Bertako sinkronizazio %1 karpeta ongi sortu da!&lt;/b&gt;&lt;/font&gt;</translation>
    </message>
</context>
<context>
    <name>OCC::OwncloudWizard</name>
    <message>
        <location filename="../src/gui/wizard/owncloudwizard.cpp" line="74"/>
        <source>%1 Connection Wizard</source>
        <translation>%1 Konexio Morroia</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudwizard.cpp" line="83"/>
        <source>Skip folders configuration</source>
        <translation>Saltatu karpeten ezarpenak</translation>
    </message>
</context>
<context>
    <name>OCC::OwncloudWizardResultPage</name>
    <message>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.cpp" line="38"/>
        <source>Everything set up!</source>
        <translation>Dena konfiguratu da!</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.cpp" line="42"/>
        <source>Open Local Folder</source>
        <translation>Ireki karpeta lokala</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.cpp" line="50"/>
        <source>Open %1 in Browser</source>
        <translation>Ireki %1 Arakatzailean</translation>
    </message>
</context>
<context>
    <name>OCC::PUTFileJob</name>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="76"/>
        <source>Connection Timeout</source>
        <translation>Konexioa denboraz kanpo</translation>
    </message>
</context>
<context>
    <name>OCC::PollJob</name>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="121"/>
        <source>Invalid JSON reply from the poll URL</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::PropagateDownloadFileLegacy</name>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="435"/>
        <source>Sync was aborted by user.</source>
        <translation>Sinkronizazioa erabiltzaileak bertan behera utzi du</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="488"/>
        <source>No E-Tag received from server, check Proxy/Gateway</source>
        <translation>Ez da E-Tagik jaso zerbitzaritik, egiaztatu Proxy/Gateway</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="494"/>
        <source>We received a different E-Tag for resuming. Retrying next time.</source>
        <translation>Jarraitzeko E-Tag ezberdina jaso dugu. Hurrengoan saiatuko gara berriz.</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="516"/>
        <source>Server returned wrong content-range</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="567"/>
        <source>File %1 can not be downloaded because of a local file name clash!</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::PropagateDownloadFileQNAM</name>
    <message>
        <location filename="../src/libsync/propagatedownload.cpp" line="271"/>
        <source>File %1 can not be downloaded because of a local file name clash!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/propagatedownload.cpp" line="429"/>
        <source>The file could not be downloaded completely.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/propagatedownload.cpp" line="465"/>
        <source>File %1 cannot be saved because of a local file name clash!</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::PropagateItemJob</name>
    <message>
        <location filename="../src/libsync/owncloudpropagator.cpp" line="81"/>
        <source>; Restoration Failed: </source>
        <translation>; huth egin du berreskuratzen:</translation>
    </message>
    <message>
        <location filename="../src/libsync/owncloudpropagator.cpp" line="104"/>
        <source>Continue blacklisting: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/owncloudpropagator.cpp" line="200"/>
        <source>A file or directory was removed from a read only share, but restoring failed: %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::PropagateLocalMkdir</name>
    <message>
        <location filename="../src/libsync/propagatorjobs.cpp" line="116"/>
        <source>Attention, possible case sensitivity clash with %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/propagatorjobs.cpp" line="121"/>
        <source>could not create directory %1</source>
        <translation>Ezin izan da %1 karpeta sortu</translation>
    </message>
</context>
<context>
    <name>OCC::PropagateLocalRemove</name>
    <message>
        <location filename="../src/libsync/propagatorjobs.cpp" line="57"/>
        <source>Error removing &apos;%1&apos;: %2; </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/propagatorjobs.cpp" line="68"/>
        <source>Could not remove directory &apos;%1&apos;; </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/propagatorjobs.cpp" line="83"/>
        <source>Could not remove %1 because of a local file name clash</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::PropagateLocalRename</name>
    <message>
        <location filename="../src/libsync/propagatorjobs.cpp" line="148"/>
        <source>File %1 can not be renamed to %2 because of a local file name clash</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::PropagateRemoteDelete</name>
    <message>
        <location filename="../src/libsync/propagateremotedelete.cpp" line="87"/>
        <source>The file has been removed from a read only share. It was restored.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/propagateremotedelete.cpp" line="103"/>
        <source>Wrong HTTP code returned by server. Expected 204, but recieved &quot;%1 %2&quot;.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::PropagateRemoteMkdir</name>
    <message>
        <location filename="../src/libsync/propagateremotemkdir.cpp" line="67"/>
        <source>Wrong HTTP code returned by server. Expected 201, but recieved &quot;%1 %2&quot;.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::PropagateRemoteMove</name>
    <message>
        <location filename="../src/libsync/propagateremotemove.cpp" line="73"/>
        <source>This folder must not be renamed. It is renamed back to its original name.</source>
        <translation>Karpeta hau ezin da berrizendatu. Bere jatorrizko izenera berrizendatu da.</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagateremotemove.cpp" line="75"/>
        <source>This folder must not be renamed. Please name it back to Shared.</source>
        <translation>Karpeta hau ezin da berrizendatu. Mesedez jarri berriz Shared izena.</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagateremotemove.cpp" line="111"/>
        <source>The file was renamed but is part of a read only share. The original file was restored.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/propagateremotemove.cpp" line="127"/>
        <source>Wrong HTTP code returned by server. Expected 201, but recieved &quot;%1 %2&quot;.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::PropagateUploadFileLegacy</name>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="243"/>
        <location filename="../src/libsync/propagator_legacy.cpp" line="302"/>
        <source>Local file changed during sync, syncing once it arrived completely</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="246"/>
        <source>Sync was aborted by user.</source>
        <translation>Sinkronizazioa erabiltzaileak bertan behera utzi du</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="252"/>
        <source>The file was edited locally but is part of a read only share. It is restored and your edit is in the conflict file.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::PropagateUploadFileQNAM</name>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="156"/>
        <source>File Removed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="171"/>
        <location filename="../src/libsync/propagateupload.cpp" line="510"/>
        <source>Local file changed during sync.</source>
        <translation>Fitxategi lokala aldatu da sinkronizazioan.</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="438"/>
        <source>The file was edited locally but is part of a read only share. It is restored and your edit is in the conflict file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="468"/>
        <source>Poll URL missing</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="493"/>
        <source>The local file was removed during sync.</source>
        <translation>Fitxategi lokala ezabatu da sinkronizazioan.</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="525"/>
        <source>The server did not acknowledge the last chunk. (No e-tag were present)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::ProtocolWidget</name>
    <message>
        <location filename="../src/gui/protocolwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formularioa</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.ui" line="20"/>
        <source>Sync Activity</source>
        <translation>Sinkronizazio Jarduerak</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.ui" line="49"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.ui" line="54"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="50"/>
        <source>Time</source>
        <translation>Noiz</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="51"/>
        <source>File</source>
        <translation>Fitxategia</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="52"/>
        <source>Folder</source>
        <translation>Karpeta</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="53"/>
        <source>Action</source>
        <translation>Ekintza</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="54"/>
        <source>Size</source>
        <translation>Tamaina</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="68"/>
        <source>Retry Sync</source>
        <translation>Saiatu berriz sinkronizatzen</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="72"/>
        <source>Copy</source>
        <translation>Kopiatu</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="73"/>
        <source>Copy the activity list to the clipboard.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="118"/>
        <source>Copied to clipboard</source>
        <translation>Arbelera kopiatua</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="118"/>
        <source>The sync status has been copied to the clipboard.</source>
        <translation>Sinkronizazio egoera arbelera kopiatu da.</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="262"/>
        <source>Currently no files are ignored because of previous errors and no downloads are in progress.</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <location filename="../src/gui/protocolwidget.cpp" line="265"/>
        <source>%n files are ignored because of previous errors.
</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message numerus="yes">
        <location filename="../src/gui/protocolwidget.cpp" line="266"/>
        <source>%n files are partially downloaded.
</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="267"/>
        <source>Try to sync these again.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::SelectiveSyncDialog</name>
    <message>
        <location filename="../src/gui/selectivesyncdialog.cpp" line="306"/>
        <source>Unchecked folders will be &lt;b&gt;removed&lt;/b&gt; from your local file system and will not be synchronized to this computer anymore</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/selectivesyncdialog.cpp" line="318"/>
        <source>Choose What to Sync: Select remote subfolders you wish to synchronize.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/selectivesyncdialog.cpp" line="319"/>
        <source>Choose What to Sync: Deselect remote subfolders you do not wish to synchronize.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/selectivesyncdialog.cpp" line="325"/>
        <source>Choose What to Sync</source>
        <translation>Hautatu zer sinkronizatu</translation>
    </message>
</context>
<context>
    <name>OCC::SelectiveSyncTreeView</name>
    <message>
        <location filename="../src/gui/selectivesyncdialog.cpp" line="36"/>
        <source>Loading ...</source>
        <translation>Kargatzen...</translation>
    </message>
    <message>
        <location filename="../src/gui/selectivesyncdialog.cpp" line="47"/>
        <source>Name</source>
        <translation>Izena</translation>
    </message>
    <message>
        <location filename="../src/gui/selectivesyncdialog.cpp" line="48"/>
        <source>Size</source>
        <translation>Tamaina</translation>
    </message>
</context>
<context>
    <name>OCC::SettingsDialog</name>
    <message>
        <location filename="../src/gui/settingsdialog.ui" line="14"/>
        <source>Settings</source>
        <translation>Ezarpenak</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialog.cpp" line="72"/>
        <source>Account</source>
        <translation>Kontua</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialog.cpp" line="77"/>
        <source>Activity</source>
        <translation>Jarduera</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialog.cpp" line="83"/>
        <source>General</source>
        <translation>Orokorra</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialog.cpp" line="89"/>
        <source>Network</source>
        <translation>Sarea</translation>
    </message>
</context>
<context>
    <name>OCC::SettingsDialogMac</name>
    <message>
        <location filename="../src/gui/settingsdialogmac.cpp" line="63"/>
        <source>%1</source>
        <translation>%1</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialogmac.cpp" line="67"/>
        <source>Account</source>
        <translation>Kontua</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialogmac.cpp" line="71"/>
        <source>Activity</source>
        <translation>Jarduera</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialogmac.cpp" line="75"/>
        <source>General</source>
        <translation>Orokorra</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialogmac.cpp" line="79"/>
        <source>Network</source>
        <translation>Sarea</translation>
    </message>
</context>
<context>
    <name>OCC::ShareDialog</name>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="14"/>
        <source>Share NewDocument.odt</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="26"/>
        <source>Share Info</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="34"/>
        <location filename="../src/gui/sharedialog.ui" line="177"/>
        <source>TextLabel</source>
        <translation>TestuEtiketa</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="53"/>
        <source>share label</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="75"/>
        <source>OwnCloud Path:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="89"/>
        <source>Share link</source>
        <translation>Elkarbanatu lotura</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="127"/>
        <source>Set password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="149"/>
        <source>Set expiry date</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="67"/>
        <location filename="../src/gui/sharedialog.cpp" line="461"/>
        <source>%1 path: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="68"/>
        <source>%1 Sharing</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="141"/>
        <source>Password Protected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="299"/>
        <source>Choose a password for the public link</source>
        <translation>Aukeratu pasahitz bat esteka publikorako</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="351"/>
        <source>OCS API error code: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="374"/>
        <source>There is no sync folder configured.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="386"/>
        <source>Can not find an folder to upload to.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="393"/>
        <source>Sharing of external directories is not yet working.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="408"/>
        <source>A sync file with the same name exists. The file can not be registered to sync.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="420"/>
        <source>Waiting to upload...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="422"/>
        <source>Unable to register in sync space.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="453"/>
        <source>The file can not be synced.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="463"/>
        <source>Sync of registered file was not successful yet.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::ShibbolethCredentials</name>
    <message>
        <location filename="../src/libsync/creds/shibbolethcredentials.cpp" line="291"/>
        <source>Login Error</source>
        <translation>Errorea sartzean</translation>
    </message>
    <message>
        <location filename="../src/libsync/creds/shibbolethcredentials.cpp" line="291"/>
        <source>You must sign in as user %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::ShibbolethWebView</name>
    <message>
        <location filename="../src/libsync/creds/shibboleth/shibbolethwebview.cpp" line="55"/>
        <source>%1 - Authenticate</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/creds/shibboleth/shibbolethwebview.cpp" line="61"/>
        <source>Reauthentication required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/creds/shibboleth/shibbolethwebview.cpp" line="61"/>
        <source>Your session has expired. You need to re-login to continue to use the client.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/creds/shibboleth/shibbolethwebview.cpp" line="108"/>
        <source>%1 - %2</source>
        <translation>%1 - %2</translation>
    </message>
</context>
<context>
    <name>OCC::SocketApi</name>
    <message>
        <location filename="../src/gui/socketapi.cpp" line="431"/>
        <source>Share with %1</source>
        <comment>parameter is ownCloud</comment>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::SslButton</name>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="97"/>
        <source>&lt;h3&gt;Certificate Details&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;&gt;Ziurtagiriaren Zehaztapenak&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="100"/>
        <source>Common Name (CN):</source>
        <translation>Izen Arrunta (IA):</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="101"/>
        <source>Subject Alternative Names:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="103"/>
        <source>Organization (O):</source>
        <translation>Erakundea (O):</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="104"/>
        <source>Organizational Unit (OU):</source>
        <translation>Erakunde Atala (OU):</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="105"/>
        <source>State/Province:</source>
        <translation>Estatua/Erkidegoa:</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="106"/>
        <source>Country:</source>
        <translation>Herrialdea:</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="107"/>
        <source>Serial:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="110"/>
        <source>&lt;h3&gt;Issuer&lt;/h3&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="113"/>
        <source>Issuer:</source>
        <translation>Jaulkitzailea:</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="114"/>
        <source>Issued on:</source>
        <translation>Jaulkitze-data:</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="115"/>
        <source>Expires on:</source>
        <translation>Iraungitze-data:</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="118"/>
        <source>&lt;h3&gt;Fingerprints&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;Hatz-markak&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="122"/>
        <source>MD 5:</source>
        <translation>MD 5:</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="124"/>
        <source>SHA-256:</source>
        <translation>SHA-256:</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="126"/>
        <source>SHA-1:</source>
        <translation>SHA-1:</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="130"/>
        <source>&lt;p&gt;&lt;b&gt;Note:&lt;/b&gt; This certificate was manually approved&lt;/p&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="150"/>
        <source>%1 (self-signed)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="152"/>
        <source>%1</source>
        <translation>%1</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="189"/>
        <source>This connection is encrypted using %1 bit %2.
</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="192"/>
        <source>Certificate information:</source>
        <translation>Ziurtagiriaren informazioa:</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="221"/>
        <source>This connection is NOT secure as it is not encrypted.
</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::SslErrorDialog</name>
    <message>
        <location filename="../src/gui/sslerrordialog.ui" line="14"/>
        <source>Form</source>
        <translation>Formularioa</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.ui" line="25"/>
        <source>Trust this certificate anyway</source>
        <translation>Fidatu ziurtagiri honetaz hala ere</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.ui" line="44"/>
        <location filename="../src/gui/sslerrordialog.cpp" line="65"/>
        <source>SSL Connection</source>
        <translation>SSL Konexioa</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="134"/>
        <source>Warnings about current SSL Connection:</source>
        <translation>Abisua uneko SSL konexioari buruz:</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="169"/>
        <source>with Certificate %1</source>
        <translation>%1 ziurtagiriarekin</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="177"/>
        <location filename="../src/gui/sslerrordialog.cpp" line="178"/>
        <location filename="../src/gui/sslerrordialog.cpp" line="179"/>
        <source>&amp;lt;not specified&amp;gt;</source>
        <translation>&amp;lt;zehaztu gabe&amp;gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="180"/>
        <location filename="../src/gui/sslerrordialog.cpp" line="200"/>
        <source>Organization: %1</source>
        <translation>Erakundea: %1</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="181"/>
        <location filename="../src/gui/sslerrordialog.cpp" line="201"/>
        <source>Unit: %1</source>
        <translation>Unitatea: %1</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="182"/>
        <location filename="../src/gui/sslerrordialog.cpp" line="202"/>
        <source>Country: %1</source>
        <translation>Herrialdea: %1</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="189"/>
        <source>Fingerprint (MD5): &lt;tt&gt;%1&lt;/tt&gt;</source>
        <translation>Hatz-marka (MD5): &lt;tt&gt;%1&lt;/tt&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="190"/>
        <source>Fingerprint (SHA1): &lt;tt&gt;%1&lt;/tt&gt;</source>
        <translation>Hatz-marka (SHA1): &lt;tt&gt;%1&lt;/tt&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="192"/>
        <source>Effective Date: %1</source>
        <translation>Balio-data: %1</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="193"/>
        <source>Expiration Date: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="197"/>
        <source>Issuer: %1</source>
        <translation>Jaulkitzailea: %1</translation>
    </message>
</context>
<context>
    <name>OCC::SyncEngine</name>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="92"/>
        <source>Success.</source>
        <translation>Arrakasta.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="95"/>
        <source>CSync failed to load or create the journal file. Make sure you have read and write permissions in the local sync directory.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="99"/>
        <source>CSync failed to load the journal file. The journal file is corrupted.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="102"/>
        <source>&lt;p&gt;The %1 plugin for csync could not be loaded.&lt;br/&gt;Please verify the installation!&lt;/p&gt;</source>
        <translation>&lt;p&gt;csyncen %1 plugina ezin da kargatu.&lt;br/&gt;Mesedez egiaztatu instalazioa!&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="105"/>
        <source>CSync got an error while processing internal trees.</source>
        <translation>CSyncek errorea izan du barne zuhaitzak prozesatzerakoan.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="108"/>
        <source>CSync failed to reserve memory.</source>
        <translation>CSyncek huts egin du memoria alokatzean.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="111"/>
        <source>CSync fatal parameter error.</source>
        <translation>CSync parametro larri errorea.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="114"/>
        <source>CSync processing step update failed.</source>
        <translation>CSync prozesatzearen eguneratu urratsak huts egin du.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="117"/>
        <source>CSync processing step reconcile failed.</source>
        <translation>CSync prozesatzearen berdinkatze urratsak huts egin du.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="120"/>
        <source>CSync could not authenticate at the proxy.</source>
        <translation>CSyncek ezin izan du proxya autentikatu.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="123"/>
        <source>CSync failed to lookup proxy or server.</source>
        <translation>CSyncek huts egin du zerbitzaria edo proxia bilatzean.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="126"/>
        <source>CSync failed to authenticate at the %1 server.</source>
        <translation>CSyncek huts egin du %1 zerbitzarian autentikatzean.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="129"/>
        <source>CSync failed to connect to the network.</source>
        <translation>CSyncek sarera konektatzean huts egin du.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="132"/>
        <source>A network connection timeout happened.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="135"/>
        <source>A HTTP transmission error happened.</source>
        <translation>HTTP transmisio errore bat gertatu da.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="138"/>
        <source>CSync failed due to not handled permission deniend.</source>
        <translation>CSyncek huts egin du kudeatu gabeko baimen ukapen bat dela eta.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="141"/>
        <source>CSync failed to access </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="144"/>
        <source>CSync tried to create a directory that already exists.</source>
        <translation>CSyncek dagoeneko existitzen zen karpeta bat sortzen saiatu da.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="147"/>
        <source>CSync: No space on %1 server available.</source>
        <translation>CSync: Ez dago lekurik %1 zerbitzarian.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="150"/>
        <source>CSync unspecified error.</source>
        <translation>CSyncen zehaztugabeko errorea.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="153"/>
        <source>Aborted by the user</source>
        <translation>Erabiltzaileak bertan behera utzita</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="156"/>
        <source>The mounted directory is temporarily not available on the server</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="159"/>
        <source>An error opening a directory happened</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="162"/>
        <source>An internal error number %1 happened.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="217"/>
        <source>The item is not synced because of previous errors: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="340"/>
        <source>Symbolic links are not supported in syncing.</source>
        <translation>Esteka sinbolikoak ezin dira sinkronizatu.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="343"/>
        <source>Hard links are not supported in syncing.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="346"/>
        <source>File is listed on the ignore list.</source>
        <translation>Fitxategia baztertutakoen zerrendan dago.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="349"/>
        <source>File contains invalid characters that can not be synced cross platform.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="366"/>
        <source>Filename encoding is not valid</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="567"/>
        <source>Unable to initialize a sync journal.</source>
        <translation>Ezin izan da sinkronizazio egunerokoa hasieratu.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="648"/>
        <source>Cannot open the sync journal</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="895"/>
        <location filename="../src/libsync/syncengine.cpp" line="902"/>
        <source>Ignored because of the &quot;choose what to sync&quot; blacklist</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="920"/>
        <source>Not allowed because you don&apos;t have permission to add sub-directories in that directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="926"/>
        <source>Not allowed because you don&apos;t have permission to add parent directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="933"/>
        <source>Not allowed because you don&apos;t have permission to add files in that directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="953"/>
        <source>Not allowed to upload this file because it is read-only on the server, restoring</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="970"/>
        <location filename="../src/libsync/syncengine.cpp" line="990"/>
        <source>Not allowed to remove, restoring</source>
        <translation>Ezabatzeko baimenik gabe, berrezartzen</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="1003"/>
        <source>Local files and share folder removed.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="1058"/>
        <source>Move not allowed, item restored</source>
        <translation>Mugitzea ez dago baimenduta, elementua berrezarri da</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="1067"/>
        <source>Move not allowed because %1 is read-only</source>
        <translation>Mugitzea ez dago baimenduta %1 irakurtzeko bakarrik delako</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="1068"/>
        <source>the destination</source>
        <translation>helburua</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="1068"/>
        <source>the source</source>
        <translation>jatorria</translation>
    </message>
</context>
<context>
    <name>OCC::Systray</name>
    <message>
        <location filename="../src/gui/systray.cpp" line="49"/>
        <source>%1: %2</source>
        <translation>%1: %2</translation>
    </message>
</context>
<context>
    <name>OCC::Theme</name>
    <message>
        <location filename="../src/libsync/theme.cpp" line="233"/>
        <source>&lt;p&gt;Version %1. For more information please visit &lt;a href=&apos;%2&apos;&gt;%3&lt;/a&gt;.&lt;/p&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="237"/>
        <source>&lt;p&gt;Copyright ownCloud, Incorporated&lt;/p&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="238"/>
        <source>&lt;p&gt;Distributed by %1 and licensed under the GNU General Public License (GPL) Version 2.0.&lt;br/&gt;%2 and the %2 logo are registered trademarks of %1 in the United States, other countries, or both.&lt;/p&gt;</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::ownCloudGui</name>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="221"/>
        <source>Please sign in</source>
        <translation>Mesedez saioa hasi</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="226"/>
        <source>Disconnected from server</source>
        <translation>Zerbitzaritik deskonektatuta</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="259"/>
        <source>Folder %1: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="264"/>
        <source>No sync folders configured.</source>
        <translation>Ez dago sinkronizazio karpetarik definituta.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="274"/>
        <source>There are no sync folders configured.</source>
        <translation>Ez dago sinkronizazio karpetarik definituta.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="295"/>
        <source>None.</source>
        <translation>Bat ere ez.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="299"/>
        <source>Recent Changes</source>
        <translation>Azkenengo Aldaketak</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="316"/>
        <source>Open %1 folder</source>
        <translation>Ireki %1 karpeta</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="326"/>
        <source>Managed Folders:</source>
        <translation>Kudeatutako karpetak:</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="335"/>
        <source>Open folder &apos;%1&apos;</source>
        <translation>Ireki &apos;%1&apos; karpeta</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="412"/>
        <source>Open %1 in browser</source>
        <translation>Ireki %1 arakatzailean</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="414"/>
        <source>Calculating quota...</source>
        <translation>Kuota kalkulatzen...</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="416"/>
        <source>Unknown status</source>
        <translation>Egoera ezezaguna</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="418"/>
        <source>Settings...</source>
        <translation>Ezarpenak...</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="419"/>
        <source>Details...</source>
        <translation>Xehetasunak...</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="424"/>
        <source>Help</source>
        <translation>Laguntza</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="426"/>
        <source>Quit %1</source>
        <translation>%1etik Irten</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="429"/>
        <source>Sign in...</source>
        <translation>Saioa hasi...</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="431"/>
        <source>Sign out</source>
        <translation>Saioa bukatu</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="435"/>
        <source>Crash now</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="446"/>
        <source>Quota n/a</source>
        <translation>Kouta e/e</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="453"/>
        <source>%1% of %2 in use</source>
        <translation>%2tik %%1 erabilita</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="465"/>
        <source>No items synced recently</source>
        <translation>Ez da azken aldian ezer sinkronizatu</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="477"/>
        <source>Discovering &apos;%1&apos;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="482"/>
        <source>Syncing %1 of %2  (%3 left)</source>
        <translation>Sinkronizatzen %1 %2tik (%3 faltan)</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="487"/>
        <source>Syncing %1 (%2 left)</source>
        <translation>Sinkronizatzen %1 (%2faltan)</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="507"/>
        <source>%1 (%2, %3)</source>
        <translation>%1 (%2, %3)</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="536"/>
        <source>Up to date</source>
        <translation>Eguneratua</translation>
    </message>
</context>
<context>
    <name>OCC::ownCloudTheme</name>
    <message utf8="true">
        <location filename="../src/libsync/owncloudtheme.cpp" line="48"/>
        <source>&lt;p&gt;Version %2. For more information visit &lt;a href=&quot;%3&quot;&gt;%4&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;small&gt;By Klaas Freitag, Daniel Molkentin, Jan-Christoph Borchardt, Olivier Goffart, Markus Götz and others.&lt;/small&gt;&lt;/p&gt;&lt;p&gt;Copyright ownCloud, Inc.&lt;/p&gt;&lt;p&gt;Licensed under the GNU General Public License (GPL) Version 2.0&lt;br/&gt;ownCloud and the ownCloud Logo are registered trademarks of ownCloud, Inc. in the United States, other countries, or both.&lt;/p&gt;</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OwncloudAdvancedSetupPage</name>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="20"/>
        <source>Form</source>
        <translation>Formularioa</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="32"/>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="78"/>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="115"/>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="234"/>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="272"/>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="299"/>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="322"/>
        <source>TextLabel</source>
        <translation>TestuEtiketa</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="88"/>
        <source>Server</source>
        <translation>Zerbitzaria</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="265"/>
        <source>Choose what to sync</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="131"/>
        <source>&amp;Local Folder</source>
        <translation>Karpeta &amp;lokala</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="174"/>
        <source>&amp;Start a clean sync (Erases the local folder!)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="209"/>
        <source>pbSelectLocalFolder</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="161"/>
        <source>&amp;Keep local data</source>
        <translation>Mantendu datu lo&amp;kalak</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="171"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If this box is checked, existing content in the local directory will be erased to start a clean sync from the server.&lt;/p&gt;&lt;p&gt;Do not check this if the local content should be uploaded to the servers directory.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="224"/>
        <source>S&amp;ync everything from server</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="306"/>
        <source>Status message</source>
        <translation>Egoera mezua</translation>
    </message>
</context>
<context>
    <name>OwncloudConnectionMethodDialog</name>
    <message>
        <location filename="../src/gui/wizard/owncloudconnectionmethoddialog.ui" line="14"/>
        <source>Connection failed</source>
        <translation>Konexioak huts egin du</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudconnectionmethoddialog.ui" line="43"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Failed to connect to the secure server address specified. How do you wish to proceed?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudconnectionmethoddialog.ui" line="55"/>
        <source>Select a different URL</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudconnectionmethoddialog.ui" line="62"/>
        <source>Retry unencrypted over HTTP (insecure)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudconnectionmethoddialog.ui" line="69"/>
        <source>Configure client-side TLS certificate</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudconnectionmethoddialog.cpp" line="18"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Failed to connect to the secure server address &lt;em&gt;%1&lt;/em&gt;. How do you wish to proceed?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OwncloudHttpCredsPage</name>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.ui" line="14"/>
        <source>Form</source>
        <translation>Formularioa</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.ui" line="38"/>
        <source>&amp;Username</source>
        <translation>&amp;Erabiltzaile-izena</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.ui" line="48"/>
        <source>&amp;Password</source>
        <translation>&amp;Pasahitza</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.ui" line="58"/>
        <source>Error Label</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.ui" line="109"/>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.ui" line="122"/>
        <source>TextLabel</source>
        <translation>TestuEtiketa</translation>
    </message>
</context>
<context>
    <name>OwncloudSetupPage</name>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="14"/>
        <location filename="../src/gui/wizard/owncloudsetupnocredspage.ui" line="20"/>
        <source>Form</source>
        <translation>Formularioa</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="20"/>
        <source>Server &amp;address:</source>
        <translation>Zerbitzariaren &amp;helbidea:</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="36"/>
        <location filename="../src/gui/owncloudsetuppage.ui" line="129"/>
        <location filename="../src/gui/owncloudsetuppage.ui" line="156"/>
        <location filename="../src/gui/wizard/owncloudsetupnocredspage.ui" line="32"/>
        <location filename="../src/gui/wizard/owncloudsetupnocredspage.ui" line="187"/>
        <source>TextLabel</source>
        <translation>TestuEtiketa</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="47"/>
        <source>Use &amp;secure connection</source>
        <translation>Erabili konexio &amp;segurua</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="60"/>
        <source>CheckBox</source>
        <translation>Aukerakutxa</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="75"/>
        <source>&amp;Username:</source>
        <translation>&amp;Erabiltzaile izena:</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="85"/>
        <source>Enter the ownCloud username.</source>
        <translation>Sartu zure ownCloud erabiltzaile izena.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="92"/>
        <source>&amp;Password:</source>
        <translation>&amp;Pasahitza:</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="102"/>
        <source>Enter the ownCloud password.</source>
        <translation>Sartu zure ownCloud pasahitza.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="117"/>
        <source>Do not allow the local storage of the password.</source>
        <translation>Ez baimendu pasahitzaren bertako biltegiratzea.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="120"/>
        <source>&amp;Do not store password on local machine</source>
        <translation>&amp;Ez gorde pasahitza ordenagailuan</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="140"/>
        <source>https://</source>
        <translation>https://</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="147"/>
        <source>Enter the url of the ownCloud you want to connect to (without http or https).</source>
        <translation>Sartu konektatu nahi duzun ownCloud zerbitzariaren urla (http edo https gabe).</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetupnocredspage.ui" line="83"/>
        <source>Server &amp;Address</source>
        <translation>Zerbitzari &amp;Helbidea</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetupnocredspage.ui" line="99"/>
        <source>https://...</source>
        <translation>https://...</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetupnocredspage.ui" line="157"/>
        <source>Error Label</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OwncloudWizardResultPage</name>
    <message>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.ui" line="14"/>
        <source>Form</source>
        <translation>Formularioa</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.ui" line="20"/>
        <source>TextLabel</source>
        <translation>TestuEtiketa</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.ui" line="163"/>
        <source>Your entire account is synced to the local folder </source>
        <translation>Zure kontu osoa karpeta lokalera sinkronizaturik dago</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.ui" line="98"/>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.ui" line="120"/>
        <source>PushButton</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Utility</name>
    <message>
        <location filename="../src/libsync/utility.cpp" line="113"/>
        <source>%L1 TiB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/utility.cpp" line="116"/>
        <source>%L1 GiB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/utility.cpp" line="119"/>
        <source>%L1 MiB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/utility.cpp" line="122"/>
        <source>%L1 KiB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/utility.cpp" line="125"/>
        <source>%L1 B</source>
        <translation>%L1 B</translation>
    </message>
</context>
<context>
    <name>main.cpp</name>
    <message>
        <location filename="../src/gui/main.cpp" line="45"/>
        <source>System Tray not available</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="46"/>
        <source>%1 requires on a working system tray. If you are running XFCE, please follow &lt;a href=&quot;http://docs.xfce.org/xfce/xfce4-panel/systray&quot;&gt;these instructions&lt;/a&gt;. Otherwise, please install a system tray application such as &apos;trayer&apos; and try again.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ownCloudTheme::about()</name>
    <message>
        <location filename="../src/libsync/theme.cpp" line="220"/>
        <source>&lt;p&gt;&lt;small&gt;Built from Git revision &lt;a href=&quot;%1&quot;&gt;%2&lt;/a&gt; on %3, %4 using Qt %5.&lt;/small&gt;&lt;/p&gt;</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>progress</name>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="32"/>
        <source>Downloaded</source>
        <translation>Deskargatua</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="34"/>
        <source>Uploaded</source>
        <translation>Igoa</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="37"/>
        <source>Deleted</source>
        <translation>Ezabatuta</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="40"/>
        <source>Moved to %1</source>
        <translation>%1era mugituta</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="42"/>
        <source>Ignored</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="44"/>
        <source>Filesystem access error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="46"/>
        <source>Error</source>
        <translation>Errorea</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="49"/>
        <location filename="../src/libsync/progressdispatcher.cpp" line="52"/>
        <source>Unknown</source>
        <translation>Ezezaguna</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="62"/>
        <source>downloading</source>
        <translation>deskargatzen</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="64"/>
        <source>uploading</source>
        <translation>igotzen</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="66"/>
        <source>deleting</source>
        <translation>ezabatzen</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="69"/>
        <source>moving</source>
        <translation>mugitzen</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="71"/>
        <source>ignoring</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="73"/>
        <location filename="../src/libsync/progressdispatcher.cpp" line="75"/>
        <source>error</source>
        <translation>errorea</translation>
    </message>
</context>
<context>
    <name>theme</name>
    <message>
        <location filename="../src/libsync/theme.cpp" line="54"/>
        <source>Status undefined</source>
        <translation>Definitu gabeko egoera</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="57"/>
        <source>Waiting to start sync</source>
        <translation>Itxoiten sinkronizazioaren hasiera</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="60"/>
        <source>Sync is running</source>
        <translation>Sinkronizazioa martxan da</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="63"/>
        <source>Sync Success</source>
        <translation>Sinkronizazioa ongi burutu da</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="66"/>
        <source>Sync Success, some files were ignored.</source>
        <translation>Sinkronizazioa ongi burutu da, fitxategi batzuk baztertu dira.</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="69"/>
        <source>Sync Error</source>
        <translation>Sinkronizazio Errorea</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="72"/>
        <source>Setup Error</source>
        <translation>Konfigurazio Errorea</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="75"/>
        <source>Preparing to sync</source>
        <translation>Sinkronizazioa prestatzen</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="78"/>
        <source>Aborting...</source>
        <translation>Bertan-behera uzten</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="81"/>
        <source>Sync is paused</source>
        <translation>Sinkronizazioa pausatuta dago</translation>
    </message>
</context>
</TS>