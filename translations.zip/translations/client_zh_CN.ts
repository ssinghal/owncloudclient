<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_CN" version="2.0">
<context>
    <name>FolderWizardSourcePage</name>
    <message>
        <location filename="../src/gui/folderwizardsourcepage.ui" line="14"/>
        <source>Form</source>
        <translation>窗体</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardsourcepage.ui" line="33"/>
        <source>Pick a local folder on your computer to sync</source>
        <translation>选择一个进行同步的本地文件夹：</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardsourcepage.ui" line="44"/>
        <source>&amp;Choose...</source>
        <translation>选择 (&amp;C)...</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardsourcepage.ui" line="55"/>
        <source>&amp;Directory alias name:</source>
        <translation>目录别名 (&amp;D):</translation>
    </message>
</context>
<context>
    <name>FolderWizardTargetPage</name>
    <message>
        <location filename="../src/gui/folderwizardtargetpage.ui" line="14"/>
        <source>Form</source>
        <translation>窗体</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardtargetpage.ui" line="128"/>
        <source>Select a remote destination folder</source>
        <translation>选择远端目标文件夹</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardtargetpage.ui" line="140"/>
        <source>Create Folder</source>
        <translation>创建文件夹</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardtargetpage.ui" line="160"/>
        <source>Refresh</source>
        <translation>刷新</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardtargetpage.ui" line="174"/>
        <source>Folders</source>
        <translation>文件夹</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardtargetpage.ui" line="107"/>
        <source>TextLabel</source>
        <translation>文本标签</translation>
    </message>
</context>
<context>
    <name>OCC::AccountSettings</name>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="14"/>
        <source>Form</source>
        <translation>窗体</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="20"/>
        <source>Account to Synchronize</source>
        <translation>需同步的账户</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="41"/>
        <source>Connected with &lt;server&gt; as &lt;user&gt;</source>
        <translation>&lt;user&gt; 已经连接到 &lt;server&gt; </translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="55"/>
        <source>Add Folder...</source>
        <translation>增加文件夹...</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="62"/>
        <location filename="../src/gui/accountsettings.cpp" line="167"/>
        <source>Pause</source>
        <translation>暂停</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="69"/>
        <source>Remove</source>
        <translation>移除</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="76"/>
        <source>Choose What to Sync</source>
        <translation>选择同步内容</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="101"/>
        <source>Storage Usage</source>
        <translation>存储使用情况</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="123"/>
        <source>Retrieving usage information...</source>
        <translation>返回使用率信息...</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="130"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; Some folders, including network mounted or shared folders, might have different limits.</source>
        <translation>&lt;b&gt;注释：&lt;/b&gt; 一些文件夹，例如网络挂载的和共享的文件夹，可能有不同的限制。</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="143"/>
        <source>Account Maintenance</source>
        <translation>帐户维护</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="152"/>
        <source>Edit Ignored Files</source>
        <translation>编辑忽略的文件</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="159"/>
        <source>Modify Account</source>
        <translation>修改帐户</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="111"/>
        <source>No account configured.</source>
        <translation>没有配置的帐号。</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="169"/>
        <source>Resume</source>
        <translation>继续</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="338"/>
        <source>Confirm Folder Remove</source>
        <translation>确认移除文件夹</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="339"/>
        <source>&lt;p&gt;Do you really want to stop syncing the folder &lt;i&gt;%1&lt;/i&gt;?&lt;/p&gt;&lt;p&gt;&lt;b&gt;Note:&lt;/b&gt; This will not remove the files from your client.&lt;/p&gt;</source>
        <translation>&lt;p&gt;你真的要停止 &lt;i&gt;%1%&lt;/i&gt; 文件夹的同步吗？&lt;/p&gt;&lt;p&gt;&lt;b&gt;注释：&lt;/b&gt;这不会删除你客户端中的文件。&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="375"/>
        <source>Confirm Folder Reset</source>
        <translation>确认文件夹重置</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="376"/>
        <source>&lt;p&gt;Do you really want to reset folder &lt;i&gt;%1&lt;/i&gt; and rebuild your client database?&lt;/p&gt;&lt;p&gt;&lt;b&gt;Note:&lt;/b&gt; This function is designed for maintenance purposes only. No files will be removed, but this can cause significant data traffic and take several minutes or hours to complete, depending on the size of the folder. Only use this option if advised by your administrator.&lt;/p&gt;</source>
        <translation>&lt;p&gt;您真希望重置文件夹 &lt;i&gt;%1&lt;/i&gt; 并重新构建您的客户端数据库吗？&lt;/p&gt;&lt;p&gt;&lt;b&gt;注意：&lt;/b&gt;此功能设计仅用作维护操作。没有文件将被移除，但这将导致大量的数据传输。根据文件夹的大小，这一过程将持续几分钟到几小时。请仅在管理员指导的情况下使用此功能。&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="486"/>
        <source>Sync Running</source>
        <translation>同步正在运行</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="487"/>
        <source>The syncing operation is running.&lt;br/&gt;Do you want to terminate it?</source>
        <translation>正在执行同步。&lt;br /&gt;您确定要关闭它吗？</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="610"/>
        <source>Discovering &apos;%1&apos;</source>
        <translation>正在发现 &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="650"/>
        <source>%1 %2 (%3 of %4) %5 left at a rate of %6/s</source>
        <extracomment>Example text: &quot;uploading foobar.png (1MB of 2MB) time left 2 minutes at a rate of 24Kb/s&quot;</extracomment>
        <translation>%1 %2 (%3 / %4)，%5 后完成 (%6/s)</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="656"/>
        <source>%1 %2 (%3 of %4)</source>
        <extracomment>Example text: &quot;uploading foobar.png (2MB of 2MB)&quot;</extracomment>
        <translation>%1 %2 (%3 / %4)</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="660"/>
        <source>%1 %2</source>
        <extracomment>Example text: &quot;uploading foobar.png&quot;</extracomment>
        <translation>%1 %2</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="675"/>
        <source>%1 of %2, file %3 of %4
Total time left %5</source>
        <translation>%1 / %2 （第 %3 个文件，共 %4 个）
%5 后全部完成</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="681"/>
        <source>file %1 of %2</source>
        <translation>第 %1 个文件，共 %2 个</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="769"/>
        <source>%1 (%3%) of %2 server space in use.</source>
        <translation>已使用 %3% 的服务器空间 (%1 / %2)</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="773"/>
        <source>Currently there is no storage usage information available.</source>
        <translation>目前没有储存使用量信息可用。</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="806"/>
        <source>Connected to &lt;a href=&quot;%1&quot;&gt;%2&lt;/a&gt;.</source>
        <translation>已连接到&lt;a href=&quot;%1&quot;&gt;%2&lt;/a&gt;。</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="809"/>
        <source>Connected to &lt;a href=&quot;%1&quot;&gt;%2&lt;/a&gt; as &lt;i&gt;%3&lt;/i&gt;.</source>
        <translation>已作为 &lt;i&gt;%3&lt;/i&gt; 连接到 &lt;a href=&quot;%1&quot;&gt;%2&lt;/a&gt;。</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="813"/>
        <source>No connection to %1 at &lt;a href=&quot;%2&quot;&gt;%3&lt;/a&gt;.</source>
        <translation>无法连接 %1 （&lt;a href=&quot;%2&quot;&gt;%3&lt;/a&gt;）。</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="820"/>
        <source>No %1 connection configured.</source>
        <translation>没有 %1 连接配置。</translation>
    </message>
</context>
<context>
    <name>OCC::AddCertificateDialog</name>
    <message>
        <location filename="../src/gui/addcertificatedialog.ui" line="17"/>
        <source>SSL client certificate authentication</source>
        <translation>SSL 客户端证书认证</translation>
    </message>
    <message>
        <location filename="../src/gui/addcertificatedialog.ui" line="23"/>
        <source>This server probably requires a SSL client certificate.</source>
        <translation>连接本服务器可能需要一个 SSL 客户端证书。</translation>
    </message>
    <message>
        <location filename="../src/gui/addcertificatedialog.ui" line="35"/>
        <source>Certificate :</source>
        <translation>证书：</translation>
    </message>
    <message>
        <location filename="../src/gui/addcertificatedialog.ui" line="51"/>
        <source>Browse...</source>
        <translation>浏览...</translation>
    </message>
    <message>
        <location filename="../src/gui/addcertificatedialog.ui" line="60"/>
        <source>Certificate password :</source>
        <translation>证书密码：</translation>
    </message>
    <message>
        <location filename="../src/gui/addcertificatedialog.cpp" line="23"/>
        <source>Select a certificate</source>
        <translation>选择证书</translation>
    </message>
    <message>
        <location filename="../src/gui/addcertificatedialog.cpp" line="23"/>
        <source>Certificate files (*.p12 *.pfx)</source>
        <translation>证书文件 (*.p12 *.pfx)</translation>
    </message>
</context>
<context>
    <name>OCC::AuthenticationDialog</name>
    <message>
        <location filename="../src/libsync/authenticationdialog.cpp" line="29"/>
        <source>Authentication Required</source>
        <translation>需要认证</translation>
    </message>
    <message>
        <location filename="../src/libsync/authenticationdialog.cpp" line="31"/>
        <source>Enter username and password for &apos;%1&apos; at %2.</source>
        <translation>输入 %1 （%2）的用户名和密码</translation>
    </message>
    <message>
        <location filename="../src/libsync/authenticationdialog.cpp" line="35"/>
        <source>&amp;User:</source>
        <translation>用户名 (&amp;U)：</translation>
    </message>
    <message>
        <location filename="../src/libsync/authenticationdialog.cpp" line="36"/>
        <source>&amp;Password:</source>
        <translation>密码 (&amp;P)：</translation>
    </message>
</context>
<context>
    <name>OCC::ConnectionValidator</name>
    <message>
        <location filename="../src/libsync/connectionvalidator.cpp" line="63"/>
        <source>No ownCloud account configured</source>
        <translation>没有已经配置的 ownCloud 帐号</translation>
    </message>
    <message>
        <location filename="../src/libsync/connectionvalidator.cpp" line="86"/>
        <source>The configured server for this client is too old</source>
        <translation>此客户端连接到的服务器版本过旧</translation>
    </message>
    <message>
        <location filename="../src/libsync/connectionvalidator.cpp" line="87"/>
        <source>Please update to the latest server and restart the client.</source>
        <translation>请更新到最新的服务器版本然后重启客户端。</translation>
    </message>
    <message>
        <location filename="../src/libsync/connectionvalidator.cpp" line="106"/>
        <location filename="../src/libsync/connectionvalidator.cpp" line="113"/>
        <source>Unable to connect to %1</source>
        <translation>无法连接到 %1</translation>
    </message>
    <message>
        <location filename="../src/libsync/connectionvalidator.cpp" line="114"/>
        <source>timeout</source>
        <translation>超时</translation>
    </message>
    <message>
        <location filename="../src/libsync/connectionvalidator.cpp" line="147"/>
        <source>The provided credentials are not correct</source>
        <translation>提供的证书不正确</translation>
    </message>
</context>
<context>
    <name>OCC::DeleteJob</name>
    <message>
        <location filename="../src/libsync/propagateremotedelete.cpp" line="41"/>
        <source>Connection timed out</source>
        <translation>连接超时</translation>
    </message>
</context>
<context>
    <name>OCC::Folder</name>
    <message>
        <location filename="../src/gui/folder.cpp" line="107"/>
        <source>Unable to create csync-context</source>
        <translation>不能生成 csync-context</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="162"/>
        <source>Local folder %1 does not exist.</source>
        <translation>本地文件夹 %1 不存在。</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="165"/>
        <source>%1 should be a directory but is not.</source>
        <translation>%1 应为目录但并不是。</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="168"/>
        <source>%1 is not readable.</source>
        <translation>%1 不可读。</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="359"/>
        <source>%1: %2</source>
        <translation>%1: %2</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="459"/>
        <source>%1 and %2 other files have been removed.</source>
        <comment>%1 names a file.</comment>
        <translation>%1 和 %2 个其它文件已被移除。</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="461"/>
        <source>%1 has been removed.</source>
        <comment>%1 names a file.</comment>
        <translation>%1 已移除。</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="466"/>
        <source>%1 and %2 other files have been downloaded.</source>
        <comment>%1 names a file.</comment>
        <translation>%1 和 %2 个其它文件已下载。</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="468"/>
        <source>%1 has been downloaded.</source>
        <comment>%1 names a file.</comment>
        <translation>%1 已下载。</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="473"/>
        <source>%1 and %2 other files have been updated.</source>
        <translation>%1 和 %2 个其它文件已更新。</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="475"/>
        <source>%1 has been updated.</source>
        <comment>%1 names a file.</comment>
        <translation>%1 已更新。</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="480"/>
        <source>%1 has been renamed to %2 and %3 other files have been renamed.</source>
        <translation>%1 已经更名为 %2，其它 %3 个文件也已更名。</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="482"/>
        <source>%1 has been renamed to %2.</source>
        <comment>%1 and %2 name files.</comment>
        <translation>%1 已更名为 %2。</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="487"/>
        <source>%1 has been moved to %2 and %3 other files have been moved.</source>
        <translation>%1 已移动到 %2，其它 %3 个文件也已移动。</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="489"/>
        <source>%1 has been moved to %2.</source>
        <translation>%1 已移动至 %2。</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="494"/>
        <source>%1 and %2 other files could not be synced due to errors. See the log for details.</source>
        <comment>%1 names a file.</comment>
        <translation>%1 和 %2 个其它文件同步出错。详情请查看日志。</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="496"/>
        <source>%1 could not be synced due to an error. See the log for details.</source>
        <translation>%1 同步出错。详情请查看日志。</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="504"/>
        <source>Sync Activity</source>
        <translation>同步活动</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="782"/>
        <source>Could not read system exclude file</source>
        <translation>无法读取系统排除的文件</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="1002"/>
        <source>This sync would remove all the files in the sync folder '%1'.
This might be because the folder was silently reconfigured, or that all the file were manually removed.
Are you sure you want to perform this operation?</source>
        <translation>这个同步将会移除在同步文件夹 %1 下的所有文件。
这可能因为该文件夹被默默地重新配置过，或者所有的文件被手动地移除了。
你确定执行该操作吗？</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="1006"/>
        <source>Remove All Files?</source>
        <translation>删除所有文件？</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="1008"/>
        <source>Remove all files</source>
        <translation>删除所有文件</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="1009"/>
        <source>Keep files</source>
        <translation>保持所有文件</translation>
    </message>
</context>
<context>
    <name>OCC::FolderMan</name>
    <message>
        <location filename="../src/gui/folderman.cpp" line="232"/>
        <source>Could not reset folder state</source>
        <translation>不能重置文件夹状态</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="233"/>
        <source>An old sync journal &apos;%1&apos; was found, but could not be removed. Please make sure that no application is currently using it.</source>
        <translation>一个旧的同步日志 &apos;%1&apos; 被找到，但是不能被移除。请确定没有应用程序正在使用它。</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1021"/>
        <source>Undefined State.</source>
        <translation>未知状态。</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1024"/>
        <source>Waits to start syncing.</source>
        <translation>等待启动同步。</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1027"/>
        <source>Preparing for sync.</source>
        <translation>准备同步。</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1030"/>
        <source>Sync is running.</source>
        <translation>同步正在运行。</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1033"/>
        <source>Last Sync was successful.</source>
        <translation>最后一次同步成功。</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1038"/>
        <source>Last Sync was successful, but with warnings on individual files.</source>
        <translation>上次同步已成功，不过一些文件出现了警告。</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1041"/>
        <source>Setup Error.</source>
        <translation>安装失败</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1044"/>
        <source>User Abort.</source>
        <translation>用户撤销。</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1047"/>
        <source>Sync is paused.</source>
        <translation>同步已暂停。</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1053"/>
        <source>%1 (Sync is paused)</source>
        <translation>%1 (同步已暂停)</translation>
    </message>
</context>
<context>
    <name>OCC::FolderStatusDelegate</name>
    <message>
        <location filename="../src/gui/folderstatusmodel.cpp" line="95"/>
        <location filename="../src/gui/folderstatusmodel.cpp" line="264"/>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../src/gui/folderstatusmodel.cpp" line="218"/>
        <source>Syncing all files in your account with</source>
        <translation>同步所有的文件到你的帐户里通过</translation>
    </message>
    <message>
        <location filename="../src/gui/folderstatusmodel.cpp" line="221"/>
        <source>Remote path: %1</source>
        <translation>远程路径： %1</translation>
    </message>
</context>
<context>
    <name>OCC::FolderWizard</name>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="502"/>
        <location filename="../src/gui/folderwizard.cpp" line="504"/>
        <source>Add Folder</source>
        <translation>增加目录</translation>
    </message>
</context>
<context>
    <name>OCC::FolderWizardLocalPath</name>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="63"/>
        <source>Click to select a local folder to sync.</source>
        <translation>点击选择进行同步的本地文件夹。</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="67"/>
        <source>Enter the path to the local folder.</source>
        <translation>输入本地文件夹的路径。</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="71"/>
        <source>The directory alias is a descriptive name for this sync connection.</source>
        <translation>目录别名</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="100"/>
        <source>No valid local folder selected!</source>
        <translation>未选择有效的本地文件夹！</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="105"/>
        <source>You have no permission to write to the selected folder!</source>
        <translation>你没有写入所选文件夹的权限！</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="129"/>
        <source>The local path %1 is already an upload folder. Please pick another one!</source>
        <translation>本地路径 %1 已经是同步文件夹。</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="134"/>
        <source>An already configured folder is contained in the current entry.</source>
        <translation>当前路径包含一个已配置的文件夹。</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="141"/>
        <source>The selected folder is a symbolic link. An already configured folder is contained in the folder this link is pointing to.</source>
        <translation>选择的文件夹是一个符号连接，连接指向的文件夹已经是同步文件夹。</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="148"/>
        <source>An already configured folder contains the currently entered folder.</source>
        <translation>选择的文件夹在已有的同步文件夹中。</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="154"/>
        <source>The selected folder is a symbolic link. An already configured folder is the parent of the current selected contains the folder this link is pointing to.</source>
        <translation>选择的文件夹是一个符号连接，连接指向的文件夹已经在已有的同步文件夹中。</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="167"/>
        <source>The alias can not be empty. Please provide a descriptive alias word.</source>
        <translation>别名不能为空。请提供一个描述性的别名。</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="178"/>
        <source>The alias &lt;i&gt;%1&lt;/i&gt; is already in use. Please pick another alias.</source>
        <translation>别名 &lt;i&gt;%1&lt;/i&gt; 已被占用。请使用另一个别名。</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="211"/>
        <source>Select the source folder</source>
        <translation>选择源目录</translation>
    </message>
</context>
<context>
    <name>OCC::FolderWizardRemotePath</name>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="258"/>
        <source>Create Remote Folder</source>
        <translation>创建远程文件夹</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="259"/>
        <source>Enter the name of the new folder to be created below &apos;%1&apos;:</source>
        <translation>输入 %1 中的新文件夹的名称：</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="288"/>
        <source>Folder was successfully created on %1.</source>
        <translation>文件夹在您的 %1 上不可用。&lt;br/&gt;请点此创建它。</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="296"/>
        <source>Failed to create the folder on %1. Please check manually.</source>
        <translation>无法在 %1 处创建文件夹。请自行检查。</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="345"/>
        <source>Choose this to sync the entire account</source>
        <translation>选择此项以同步整个账户</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="400"/>
        <source>This folder is already being synced.</source>
        <translation>文件夹已在同步中。</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="402"/>
        <source>You are already syncing &lt;i&gt;%1&lt;/i&gt;, which is a parent folder of &lt;i&gt;%2&lt;/i&gt;.</source>
        <translation>你已经在同步 &lt;i&gt;%1&lt;/i&gt;，&lt;i&gt;%2&lt;/i&gt; 是它的一个子文件夹。</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="406"/>
        <source>You are already syncing all your files. Syncing another folder is &lt;b&gt;not&lt;/b&gt; supported. If you want to sync multiple folders, please remove the currently configured root folder sync.</source>
        <translation>你已经设置同步了你的所有文件，无法同步另一文件夹。要同步多个文件夹，请取消当前设置的根文件夹同步。</translation>
    </message>
</context>
<context>
    <name>OCC::FolderWizardSelectiveSync</name>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="444"/>
        <source>Choose What to Sync: You can optionally deselect remote subfolders you do not wish to synchronize.</source>
        <translation>选择同步内容（取消选中不需同步的远程子文件夹）</translation>
    </message>
</context>
<context>
    <name>OCC::FormatWarningsWizardPage</name>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="45"/>
        <location filename="../src/gui/folderwizard.cpp" line="47"/>
        <source>&lt;b&gt;Warning:&lt;/b&gt; </source>
        <translation>&lt;b&gt;警告：&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>OCC::GETFileJob</name>
    <message>
        <location filename="../src/libsync/propagatedownload.cpp" line="122"/>
        <source>No E-Tag received from server, check Proxy/Gateway</source>
        <translation>未能收到来自服务器的 E-Tag，请检查代理/网关</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagatedownload.cpp" line="129"/>
        <source>We received a different E-Tag for resuming. Retrying next time.</source>
        <translation>我们收到了不同的恢复 E-Tag，将在下次尝试。</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagatedownload.cpp" line="156"/>
        <source>Server returned wrong content-range</source>
        <translation>服务器返回了错误的内容长度</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagatedownload.cpp" line="257"/>
        <source>Connection Timeout</source>
        <translation>连接超时</translation>
    </message>
</context>
<context>
    <name>OCC::GeneralSettings</name>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="14"/>
        <source>Form</source>
        <translation>窗体</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="20"/>
        <source>General Settings</source>
        <translation>常规设置</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="26"/>
        <source>Launch on System Startup</source>
        <translation>在系统启动是启动</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="33"/>
        <source>Show Desktop Notifications</source>
        <translation>显示桌面提醒</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="40"/>
        <source>Use Monochrome Icons</source>
        <translation>选择单色图标</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="47"/>
        <source>Show crash reporter</source>
        <translation>显示崩溃报告器</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="57"/>
        <location filename="../src/gui/generalsettings.ui" line="63"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="73"/>
        <source>Updates</source>
        <translation>更新</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="98"/>
        <source>&amp;Restart &amp;&amp; Update</source>
        <translation>重启并更新 (&amp;R)</translation>
    </message>
</context>
<context>
    <name>OCC::HttpCredentialsGui</name>
    <message>
        <location filename="../src/libsync/creds/httpcredentials.cpp" line="400"/>
        <source>Enter Password</source>
        <translation>输入密码</translation>
    </message>
    <message>
        <location filename="../src/libsync/creds/httpcredentials.cpp" line="401"/>
        <source>Please enter %1 password for user &apos;%2&apos;:</source>
        <translation>请输入账户 %2 的 %1 密码：</translation>
    </message>
</context>
<context>
    <name>OCC::IgnoreListEditor</name>
    <message>
        <location filename="../src/gui/ignorelisteditor.ui" line="14"/>
        <source>Ignored Files Editor</source>
        <translation>忽略的文件编辑器</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.ui" line="53"/>
        <source>Add</source>
        <translation>增加</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.ui" line="63"/>
        <source>Remove</source>
        <translation>移除</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="35"/>
        <source>Files or directories matching a pattern will not be synchronized.

Checked items will also be deleted if they prevent a directory from being removed. This is useful for meta data.</source>
        <translation>匹配到模式的文件或文件夹将不会被同步。

如果选中的项目正在阻止文件夹的删除，它们也会被删除。这对于元数据很有用。</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="97"/>
        <source>Could not open file</source>
        <translation>不能打开文件</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="98"/>
        <source>Cannot write changes to &apos;%1&apos;.</source>
        <translation>无法向 %1 中写入修改。</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="105"/>
        <source>Add Ignore Pattern</source>
        <translation>增加忽略模式</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="106"/>
        <source>Add a new ignore pattern:</source>
        <translation>增加新的忽略模式：</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="128"/>
        <source>Edit Ignore Pattern</source>
        <translation>编辑忽略模式</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="129"/>
        <source>Edit ignore pattern:</source>
        <translation>编辑忽略模式：</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="140"/>
        <source>This entry is provided by the system at &apos;%1&apos; and cannot be modified in this view.</source>
        <translation>此项目由系统在 %1 处提供，不能在这里被修改。</translation>
    </message>
</context>
<context>
    <name>OCC::LogBrowser</name>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="59"/>
        <source>Log Output</source>
        <translation>日志输出</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="71"/>
        <source>&amp;Search: </source>
        <translation>搜索 (&amp;S)： </translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="79"/>
        <source>&amp;Find</source>
        <translation>查找 (&amp;F)</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="97"/>
        <source>Clear</source>
        <translation>清除</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="98"/>
        <source>Clear the log display.</source>
        <translation>清空日志显示。</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="104"/>
        <source>S&amp;ave</source>
        <translation>保存 (&amp;S)</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="105"/>
        <source>Save the log file to a file on disk for debugging.</source>
        <translation>保存日志文件到磁盘以供调试。</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="184"/>
        <source>Save log file</source>
        <translation>保存日志文件</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="194"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="194"/>
        <source>Could not write to log file </source>
        <translation>无法写到日志文件</translation>
    </message>
</context>
<context>
    <name>OCC::Logger</name>
    <message>
        <location filename="../src/libsync/logger.cpp" line="148"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../src/libsync/logger.cpp" line="149"/>
        <source>&lt;nobr&gt;File &apos;%1&apos;&lt;br/&gt;cannot be opened for writing.&lt;br/&gt;&lt;br/&gt;The log output can &lt;b&gt;not&lt;/b&gt; be saved!&lt;/nobr&gt;</source>
        <translation>&lt;nobr&gt;文件 &apos;%1&apos;&lt;br/&gt;不能写入。&lt;br/&gt;&lt;br/&gt;将&lt;b&gt;不&lt;/b&gt;能保存日志输出！&lt;/nobr&gt;</translation>
    </message>
</context>
<context>
    <name>OCC::MoveJob</name>
    <message>
        <location filename="../src/libsync/propagateremotemove.cpp" line="45"/>
        <source>Connection timed out</source>
        <translation>连接超时</translation>
    </message>
</context>
<context>
    <name>OCC::NSISUpdater</name>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="256"/>
        <source>New Version Available</source>
        <translation>新版本可用</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="262"/>
        <source>&lt;p&gt;A new version of the %1 Client is available.&lt;/p&gt;&lt;p&gt;&lt;b&gt;%2&lt;/b&gt; is available for download. The installed version is %3.&lt;/p&gt;</source>
        <translation>&lt;p&gt;新版本的 %1 客户端可用。&lt;/p&gt;&lt;p&gt;&lt;b&gt;%2&lt;/b&gt; 已经开放下载。已安装的版本是 %3。&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="275"/>
        <source>Skip this version</source>
        <translation>跳过这个版本</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="276"/>
        <source>Skip this time</source>
        <translation>本次跳过</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="277"/>
        <source>Get update</source>
        <translation>获取更新</translation>
    </message>
</context>
<context>
    <name>OCC::NetworkSettings</name>
    <message>
        <location filename="../src/gui/networksettings.ui" line="14"/>
        <source>Form</source>
        <translation>窗体</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="23"/>
        <source>Proxy Settings</source>
        <translation>代理设置</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="29"/>
        <source>No Proxy</source>
        <translation>无代理</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="42"/>
        <source>Use system proxy</source>
        <translation>使用系统代理</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="52"/>
        <source>Specify proxy manually as</source>
        <translation>手动设置代理为</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="80"/>
        <source>Host</source>
        <translation>主机</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="100"/>
        <source>:</source>
        <translation>：</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="134"/>
        <source>Proxy server requires authentication</source>
        <translation>代理服务器需要认证</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="190"/>
        <source>Download Bandwidth</source>
        <translation>下载带宽</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="196"/>
        <location filename="../src/gui/networksettings.ui" line="278"/>
        <source>Limit to</source>
        <translation>限制为</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="218"/>
        <location filename="../src/gui/networksettings.ui" line="320"/>
        <source>KBytes/s</source>
        <translation>KBytes/s</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="227"/>
        <location filename="../src/gui/networksettings.ui" line="295"/>
        <source>No limit</source>
        <translation>无限制</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="272"/>
        <source>Upload Bandwidth</source>
        <translation>上传带宽</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="285"/>
        <source>Limit automatically</source>
        <translation>自动限制</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.cpp" line="34"/>
        <source>Hostname of proxy server</source>
        <translation>代理服务器主机名</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.cpp" line="35"/>
        <source>Username for proxy server</source>
        <translation>代理服务器用户名</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.cpp" line="36"/>
        <source>Password for proxy server</source>
        <translation>代理服务器密码</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.cpp" line="38"/>
        <source>HTTP(S) proxy</source>
        <translation>HTTP(S) 代理</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.cpp" line="39"/>
        <source>SOCKS5 proxy</source>
        <translation>SOCKS5 代理</translation>
    </message>
</context>
<context>
    <name>OCC::OCUpdater</name>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="55"/>
        <source>New Update Ready</source>
        <translation>新的更新已经准备就绪</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="56"/>
        <source>A new update is about to be installed. The updater may ask
for additional privileges during the process.</source>
        <translation>更新将会安装。安装过程可能会要求额外的权限。</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="77"/>
        <source>Downloading version %1. Please wait...</source>
        <translation>正在下载版本 %1，请稍后....</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="79"/>
        <source>Version %1 available. Restart application to start the update.</source>
        <translation>版本 %1 现在可用，请重启应用以开始更新。</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="81"/>
        <source>Could not download update. Please click &lt;a href=&apos;%1&apos;&gt;here&lt;/a&gt; to download the update manually.</source>
        <translation>无法下载更新，请点击&lt;a href=&apos;%1&apos;&gt;此处&lt;/a&gt;手动下载更新。</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="83"/>
        <source>Could not check for new updates.</source>
        <translation>无法检查新更新。</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="85"/>
        <source>New version %1 available. Please use the system&apos;s update tool to install it.</source>
        <translation>新版本 %1 已经可用，使用系统更新工具升级。</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="87"/>
        <source>Checking update server...</source>
        <translation>检查更新服务器</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="89"/>
        <source>Update status is unknown: Did not check for new updates.</source>
        <translation>还没有检查过更新。</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="93"/>
        <source>No updates available. Your installation is at the latest version.</source>
        <translation>亲，你使用的已经是最新的版本了</translation>
    </message>
</context>
<context>
    <name>OCC::OwncloudAdvancedSetupPage</name>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="50"/>
        <source>Connect to %1</source>
        <translation>连接到 %1</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="51"/>
        <source>Setup local folder options</source>
        <translation>设置本地文件夹</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="60"/>
        <source>Connect...</source>
        <translation>连接...</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="135"/>
        <source>%1 folder &apos;%2&apos; is synced to local folder &apos;%3&apos;</source>
        <translation>%1 文件夹 &apos;%2&apos; 将被同步到本地文件夹 &apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="141"/>
        <source>&lt;p&gt;&lt;small&gt;&lt;strong&gt;Warning:&lt;/strong&gt; You currently have multiple folders configured. If you continue with the current settings, the folder configurations will be discarded and a single root folder sync will be created!&lt;/small&gt;&lt;/p&gt;</source>
        <translation>警告：当前设置了多个文件夹。如果继续当前操作，文件夹设置将丢失，且一个根文件夹会被建立并同步。</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="148"/>
        <source>&lt;p&gt;&lt;small&gt;&lt;strong&gt;Warning:&lt;/strong&gt; The local directory is not empty. Pick a resolution!&lt;/small&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;small&gt;&lt;strong&gt;警告：&lt;/strong&gt; 本地目录非空。选择一个操作！&lt;/small&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="265"/>
        <source>Local Sync Folder</source>
        <translation>本地同步文件夹</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="278"/>
        <source>Update advanced setup</source>
        <translation>更新高级设置</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="297"/>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="318"/>
        <source>(%1)</source>
        <translation>(%1)</translation>
    </message>
</context>
<context>
    <name>OCC::OwncloudHttpCredsPage</name>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.cpp" line="46"/>
        <source>Connect to %1</source>
        <translation>连接到 %1</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.cpp" line="47"/>
        <source>Enter user credentials</source>
        <translation>输入用户密码</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.cpp" line="164"/>
        <source>Update user credentials</source>
        <translation>修改用户密码</translation>
    </message>
</context>
<context>
    <name>OCC::OwncloudSetupPage</name>
    <message>
        <location filename="../src/gui/wizard/owncloudsetuppage.cpp" line="50"/>
        <source>Connect to %1</source>
        <translation>连接到 %1</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetuppage.cpp" line="51"/>
        <source>Setup %1 server</source>
        <translation>设置 %1 服务器</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetuppage.cpp" line="120"/>
        <source>This url is NOT secure as it is not encrypted.
It is not advisable to use it.</source>
        <translation>这个地址没有使用加密，不够安全，不建议使用。</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetuppage.cpp" line="124"/>
        <source>This url is secure. You can use it.</source>
        <translation>此地址是安全的。您可以使用它</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetuppage.cpp" line="163"/>
        <source>&amp;Next &gt;</source>
        <translation>下一步 (&amp;N) &gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetuppage.cpp" line="295"/>
        <source>Update %1 server</source>
        <translation>更新 %1 服务器</translation>
    </message>
</context>
<context>
    <name>OCC::OwncloudSetupWizard</name>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="161"/>
        <source>&lt;font color=&quot;green&quot;&gt;Successfully connected to %1: %2 version %3 (%4)&lt;/font&gt;&lt;br/&gt;&lt;br/&gt;</source>
        <translation>&lt;font color=&quot;green&quot;&gt;成功连接到 %1：%2 版本 %3 (%4)&lt;/font&gt;&lt;br/&gt;&lt;br/&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="185"/>
        <source>Failed to connect to %1 at %2:&lt;br/&gt;%3</source>
        <translation>连接到 %1 （%2）失败：&lt;br /&gt;%3</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="193"/>
        <source>Timeout while trying to connect to %1 at %2.</source>
        <translation>连接到 %1 （%2） 时超时。</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="204"/>
        <source>Trying to connect to %1 at %2...</source>
        <translation>尝试连接位于 %2 的 %1...</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="253"/>
        <source>Access forbidden by server. To verify that you have proper access, &lt;a href=&quot;%1&quot;&gt;click here&lt;/a&gt; to access the service with your browser.</source>
        <translation>服务器拒绝了访问。&lt;a href=&quot;%1&quot;&gt;点击这里打开浏览器&lt;/a&gt; 来确认您是否有权访问。</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="275"/>
        <source>Local sync folder %1 already exists, setting it up for sync.&lt;br/&gt;&lt;br/&gt;</source>
        <translation>本地同步文件夹 %1 已存在，将使用它来同步。&lt;br/&gt;&lt;br/&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="277"/>
        <source>Creating local sync folder %1... </source>
        <translation>正在创建本地同步文件夹 %1...</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="281"/>
        <source>ok</source>
        <translation>成功</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="283"/>
        <source>failed.</source>
        <translation>失败</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="285"/>
        <source>Could not create local folder %1</source>
        <translation>不能创建本地文件夹 %1</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="310"/>
        <source>No remote folder specified!</source>
        <translation>未指定远程文件夹！</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="316"/>
        <source>Error: %1</source>
        <translation>错误：%1</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="329"/>
        <source>creating folder on ownCloud: %1</source>
        <translation>在 ownCloud 创建文件夹：%1</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="345"/>
        <source>Remote folder %1 created successfully.</source>
        <translation>远程目录%1成功创建。</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="347"/>
        <source>The remote folder %1 already exists. Connecting it for syncing.</source>
        <translation>远程文件夹 %1 已存在。连接它以供同步。</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="349"/>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="351"/>
        <source>The folder creation resulted in HTTP error code %1</source>
        <translation>创建文件夹出现 HTTP 错误代码 %1</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="353"/>
        <source>The remote folder creation failed because the provided credentials are wrong!&lt;br/&gt;Please go back and check your credentials.&lt;/p&gt;</source>
        <translation>远程文件夹创建失败，因为提供的凭证有误！&lt;br/&gt;请返回并检查您的凭证。&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="356"/>
        <source>&lt;p&gt;&lt;font color=&quot;red&quot;&gt;Remote folder creation failed probably because the provided credentials are wrong.&lt;/font&gt;&lt;br/&gt;Please go back and check your credentials.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;font color=&quot;red&quot;&gt;远程文件夹创建失败，可能是由于提供的用户名密码不正确。&lt;/font&gt;&lt;br/&gt;请返回并检查它们。&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="361"/>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="362"/>
        <source>Remote folder %1 creation failed with error &lt;tt&gt;%2&lt;/tt&gt;.</source>
        <translation>创建远程文件夹 %1 失败，错误为 &lt;tt&gt;%2&lt;/tt&gt;。</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="378"/>
        <source>A sync connection from %1 to remote directory %2 was set up.</source>
        <translation>已经设置了一个 %1 到远程文件夹 %2 的同步连接</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="383"/>
        <source>Successfully connected to %1!</source>
        <translation>成功连接到了 %1！</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="390"/>
        <source>Connection to %1 could not be established. Please check again.</source>
        <translation>无法建立到 %1的链接，请稍后重试</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="403"/>
        <source>Folder rename failed</source>
        <translation>文件夹更名失败</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="404"/>
        <source>Can&apos;t remove and back up the folder because the folder or a file in it is open in another program. Please close the folder or file and hit retry or cancel the setup.</source>
        <translation>无法移除和备份文件夹，由于文件夹或文件正在被另一程序占用。请关闭程序后重试，或取消安装。</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="450"/>
        <source>&lt;font color=&quot;green&quot;&gt;&lt;b&gt;Local sync folder %1 successfully created!&lt;/b&gt;&lt;/font&gt;</source>
        <translation>&lt;font color=&quot;green&quot;&gt;&lt;b&gt;本地同步目录 %1 已成功创建&lt;/b&gt;&lt;/font&gt;</translation>
    </message>
</context>
<context>
    <name>OCC::OwncloudWizard</name>
    <message>
        <location filename="../src/gui/wizard/owncloudwizard.cpp" line="74"/>
        <source>%1 Connection Wizard</source>
        <translation>%1 链接向导</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudwizard.cpp" line="83"/>
        <source>Skip folders configuration</source>
        <translation>跳过文件夹设置</translation>
    </message>
</context>
<context>
    <name>OCC::OwncloudWizardResultPage</name>
    <message>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.cpp" line="38"/>
        <source>Everything set up!</source>
        <translation>一切都设置好了！</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.cpp" line="42"/>
        <source>Open Local Folder</source>
        <translation>打开本地文件夹</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.cpp" line="50"/>
        <source>Open %1 in Browser</source>
        <translation>在浏览器中打开 %1</translation>
    </message>
</context>
<context>
    <name>OCC::PUTFileJob</name>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="76"/>
        <source>Connection Timeout</source>
        <translation>连接超时</translation>
    </message>
</context>
<context>
    <name>OCC::PollJob</name>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="121"/>
        <source>Invalid JSON reply from the poll URL</source>
        <translation>推送 URL 传来的 JSON 无效</translation>
    </message>
</context>
<context>
    <name>OCC::PropagateDownloadFileLegacy</name>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="435"/>
        <source>Sync was aborted by user.</source>
        <translation>同步被用户撤销。</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="488"/>
        <source>No E-Tag received from server, check Proxy/Gateway</source>
        <translation>未能收到来自服务器的 E-Tag，请检查代理/网关</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="494"/>
        <source>We received a different E-Tag for resuming. Retrying next time.</source>
        <translation>我们收到了不同的恢复 E-Tag，将在下次尝试。</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="516"/>
        <source>Server returned wrong content-range</source>
        <translation>服务器返回了错误的内容长度</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="567"/>
        <source>File %1 can not be downloaded because of a local file name clash!</source>
        <translation>由于本地文件名冲突，文件 %1 无法下载。</translation>
    </message>
</context>
<context>
    <name>OCC::PropagateDownloadFileQNAM</name>
    <message>
        <location filename="../src/libsync/propagatedownload.cpp" line="271"/>
        <source>File %1 can not be downloaded because of a local file name clash!</source>
        <translation>由于本地文件名冲突，文件 %1 无法下载。</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagatedownload.cpp" line="429"/>
        <source>The file could not be downloaded completely.</source>
        <translation>文件无法完整下载。</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagatedownload.cpp" line="465"/>
        <source>File %1 cannot be saved because of a local file name clash!</source>
        <translation>由于本地文件名冲突，文件 %1 无法保存。</translation>
    </message>
</context>
<context>
    <name>OCC::PropagateItemJob</name>
    <message>
        <location filename="../src/libsync/owncloudpropagator.cpp" line="81"/>
        <source>; Restoration Failed: </source>
        <translation>; 恢复失败：</translation>
    </message>
    <message>
        <location filename="../src/libsync/owncloudpropagator.cpp" line="104"/>
        <source>Continue blacklisting: </source>
        <translation>继续排除：</translation>
    </message>
    <message>
        <location filename="../src/libsync/owncloudpropagator.cpp" line="200"/>
        <source>A file or directory was removed from a read only share, but restoring failed: %1</source>
        <translation>文件（夹）移除了只读共享，但恢复失败：%1</translation>
    </message>
</context>
<context>
    <name>OCC::PropagateLocalMkdir</name>
    <message>
        <location filename="../src/libsync/propagatorjobs.cpp" line="116"/>
        <source>Attention, possible case sensitivity clash with %1</source>
        <translation>小心！%1 的文件名可能有大小写冲突</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagatorjobs.cpp" line="121"/>
        <source>could not create directory %1</source>
        <translation>不能创建文件夹 %1</translation>
    </message>
</context>
<context>
    <name>OCC::PropagateLocalRemove</name>
    <message>
        <location filename="../src/libsync/propagatorjobs.cpp" line="57"/>
        <source>Error removing &apos;%1&apos;: %2; </source>
        <translation>移除 %1 时出错：%2;</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagatorjobs.cpp" line="68"/>
        <source>Could not remove directory &apos;%1&apos;; </source>
        <translation>不能删除文件夹 %1</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagatorjobs.cpp" line="83"/>
        <source>Could not remove %1 because of a local file name clash</source>
        <translation>由于本地文件名冲突，不能删除 %1</translation>
    </message>
</context>
<context>
    <name>OCC::PropagateLocalRename</name>
    <message>
        <location filename="../src/libsync/propagatorjobs.cpp" line="148"/>
        <source>File %1 can not be renamed to %2 because of a local file name clash</source>
        <translation>由于本地文件名冲突，文件 %1 无法更名为 %2</translation>
    </message>
</context>
<context>
    <name>OCC::PropagateRemoteDelete</name>
    <message>
        <location filename="../src/libsync/propagateremotedelete.cpp" line="87"/>
        <source>The file has been removed from a read only share. It was restored.</source>
        <translation>文件已经移除只读共享，并已经恢复。</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagateremotedelete.cpp" line="103"/>
        <source>Wrong HTTP code returned by server. Expected 204, but recieved &quot;%1 %2&quot;.</source>
        <translation>服务器返回的 HTTP 状态错误，应返回 204，但返回的是“%1 %2”。</translation>
    </message>
</context>
<context>
    <name>OCC::PropagateRemoteMkdir</name>
    <message>
        <location filename="../src/libsync/propagateremotemkdir.cpp" line="67"/>
        <source>Wrong HTTP code returned by server. Expected 201, but recieved &quot;%1 %2&quot;.</source>
        <translation>服务器返回的 HTTP 状态错误，应返回 201，但返回的是“%1 %2”。</translation>
    </message>
</context>
<context>
    <name>OCC::PropagateRemoteMove</name>
    <message>
        <location filename="../src/libsync/propagateremotemove.cpp" line="73"/>
        <source>This folder must not be renamed. It is renamed back to its original name.</source>
        <translation>文件无法更名，已经恢复为原文件名。</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagateremotemove.cpp" line="75"/>
        <source>This folder must not be renamed. Please name it back to Shared.</source>
        <translation>文件无法更名，请改回“Shared”。</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagateremotemove.cpp" line="111"/>
        <source>The file was renamed but is part of a read only share. The original file was restored.</source>
        <translation>文件已经更名，但这是某个只读分享的一部分，原文件已经恢复。</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagateremotemove.cpp" line="127"/>
        <source>Wrong HTTP code returned by server. Expected 201, but recieved &quot;%1 %2&quot;.</source>
        <translation>服务器返回的 HTTP 状态错误，应返回 201，但返回的是“%1 %2”。</translation>
    </message>
</context>
<context>
    <name>OCC::PropagateUploadFileLegacy</name>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="243"/>
        <location filename="../src/libsync/propagator_legacy.cpp" line="302"/>
        <source>Local file changed during sync, syncing once it arrived completely</source>
        <translation>本地文件在同步时已修改，完成后会再次同步</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="246"/>
        <source>Sync was aborted by user.</source>
        <translation>同步被用户撤销。</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="252"/>
        <source>The file was edited locally but is part of a read only share. It is restored and your edit is in the conflict file.</source>
        <translation>文件已经在本地修改，但这是某个只读分享的一部分，原文件已经恢复。您的修改已保存在冲突文件中。</translation>
    </message>
</context>
<context>
    <name>OCC::PropagateUploadFileQNAM</name>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="156"/>
        <source>File Removed</source>
        <translation>已移除文件</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="171"/>
        <location filename="../src/libsync/propagateupload.cpp" line="510"/>
        <source>Local file changed during sync.</source>
        <translation>本地文件在同步时已修改。</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="438"/>
        <source>The file was edited locally but is part of a read only share. It is restored and your edit is in the conflict file.</source>
        <translation>文件已经在本地修改，但这是某个只读分享的一部分，原文件已经恢复。您的修改已保存在冲突文件中。</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="468"/>
        <source>Poll URL missing</source>
        <translation>缺少轮询 URL</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="493"/>
        <source>The local file was removed during sync.</source>
        <translation>本地文件在同步时已删除。</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="525"/>
        <source>The server did not acknowledge the last chunk. (No e-tag were present)</source>
        <translation>服务器找不到上一分块。（找不到 E-tag）</translation>
    </message>
</context>
<context>
    <name>OCC::ProtocolWidget</name>
    <message>
        <location filename="../src/gui/protocolwidget.ui" line="14"/>
        <source>Form</source>
        <translation>窗体</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.ui" line="20"/>
        <source>Sync Activity</source>
        <translation>同步活动</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.ui" line="49"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.ui" line="54"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="50"/>
        <source>Time</source>
        <translation>时间</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="51"/>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="52"/>
        <source>Folder</source>
        <translation>文件夹</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="53"/>
        <source>Action</source>
        <translation>动作</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="54"/>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="68"/>
        <source>Retry Sync</source>
        <translation>重试同步</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="72"/>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="73"/>
        <source>Copy the activity list to the clipboard.</source>
        <translation>复制动态列表到剪贴板。</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="118"/>
        <source>Copied to clipboard</source>
        <translation>复制到剪贴板</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="118"/>
        <source>The sync status has been copied to the clipboard.</source>
        <translation>同步状态已经复制到剪贴板。</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="262"/>
        <source>Currently no files are ignored because of previous errors and no downloads are in progress.</source>
        <translation>没有文件因上次错误而被忽略，没有下载正在进行。</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/gui/protocolwidget.cpp" line="265"/>
        <source>%n files are ignored because of previous errors.
</source>
        <translation><numerusform>由于上次错误， %n 个文件被忽略。
</numerusform></translation>
    </message>
    <message numerus="yes">
        <location filename="../src/gui/protocolwidget.cpp" line="266"/>
        <source>%n files are partially downloaded.
</source>
        <translation><numerusform>%n 个文件被部分下载。
</numerusform></translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="267"/>
        <source>Try to sync these again.</source>
        <translation>试试重新同步这些内容。</translation>
    </message>
</context>
<context>
    <name>OCC::SelectiveSyncDialog</name>
    <message>
        <location filename="../src/gui/selectivesyncdialog.cpp" line="306"/>
        <source>Unchecked folders will be &lt;b&gt;removed&lt;/b&gt; from your local file system and will not be synchronized to this computer anymore</source>
        <translation>取消选中的文件夹将会从本地&lt;b&gt;删除&lt;/b&gt;，并不再同步到这台电脑上。</translation>
    </message>
    <message>
        <location filename="../src/gui/selectivesyncdialog.cpp" line="318"/>
        <source>Choose What to Sync: Select remote subfolders you wish to synchronize.</source>
        <translation>选择同步内容（选中需同步的远程子文件夹）</translation>
    </message>
    <message>
        <location filename="../src/gui/selectivesyncdialog.cpp" line="319"/>
        <source>Choose What to Sync: Deselect remote subfolders you do not wish to synchronize.</source>
        <translation>选择同步内容（取消选中不需同步的远程子文件夹）</translation>
    </message>
    <message>
        <location filename="../src/gui/selectivesyncdialog.cpp" line="325"/>
        <source>Choose What to Sync</source>
        <translation>选择同步内容</translation>
    </message>
</context>
<context>
    <name>OCC::SelectiveSyncTreeView</name>
    <message>
        <location filename="../src/gui/selectivesyncdialog.cpp" line="36"/>
        <source>Loading ...</source>
        <translation>加载中...</translation>
    </message>
    <message>
        <location filename="../src/gui/selectivesyncdialog.cpp" line="47"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="../src/gui/selectivesyncdialog.cpp" line="48"/>
        <source>Size</source>
        <translation>大小</translation>
    </message>
</context>
<context>
    <name>OCC::SettingsDialog</name>
    <message>
        <location filename="../src/gui/settingsdialog.ui" line="14"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialog.cpp" line="72"/>
        <source>Account</source>
        <translation>账户</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialog.cpp" line="77"/>
        <source>Activity</source>
        <translation>动态</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialog.cpp" line="83"/>
        <source>General</source>
        <translation>常规</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialog.cpp" line="89"/>
        <source>Network</source>
        <translation>网络</translation>
    </message>
</context>
<context>
    <name>OCC::SettingsDialogMac</name>
    <message>
        <location filename="../src/gui/settingsdialogmac.cpp" line="63"/>
        <source>%1</source>
        <translation>%1</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialogmac.cpp" line="67"/>
        <source>Account</source>
        <translation>账户</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialogmac.cpp" line="71"/>
        <source>Activity</source>
        <translation>动态</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialogmac.cpp" line="75"/>
        <source>General</source>
        <translation>常规</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialogmac.cpp" line="79"/>
        <source>Network</source>
        <translation>网络</translation>
    </message>
</context>
<context>
    <name>OCC::ShareDialog</name>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="14"/>
        <source>Share NewDocument.odt</source>
        <translation>分享 NewDocument.odt</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="26"/>
        <source>Share Info</source>
        <translation>分享信息</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="34"/>
        <location filename="../src/gui/sharedialog.ui" line="177"/>
        <source>TextLabel</source>
        <translation>文本标签</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="53"/>
        <source>share label</source>
        <translation>分享标签</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="75"/>
        <source>OwnCloud Path:</source>
        <translation>OwnCloud 地址：</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="89"/>
        <source>Share link</source>
        <translation>分享链接</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="127"/>
        <source>Set password</source>
        <translation>设置密码</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="149"/>
        <source>Set expiry date</source>
        <translation>设置有效期</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="67"/>
        <location filename="../src/gui/sharedialog.cpp" line="461"/>
        <source>%1 path: %2</source>
        <translation>%1 路径：%2</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="68"/>
        <source>%1 Sharing</source>
        <translation>%1 分享</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="141"/>
        <source>Password Protected</source>
        <translation>密码保护</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="299"/>
        <source>Choose a password for the public link</source>
        <translation>为共享链接设置密码</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="351"/>
        <source>OCS API error code: %1</source>
        <translation>OCS API 错误代码：%1</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="374"/>
        <source>There is no sync folder configured.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="386"/>
        <source>Can not find an folder to upload to.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="393"/>
        <source>Sharing of external directories is not yet working.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="408"/>
        <source>A sync file with the same name exists. The file can not be registered to sync.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="420"/>
        <source>Waiting to upload...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="422"/>
        <source>Unable to register in sync space.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="453"/>
        <source>The file can not be synced.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="463"/>
        <source>Sync of registered file was not successful yet.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::ShibbolethCredentials</name>
    <message>
        <location filename="../src/libsync/creds/shibbolethcredentials.cpp" line="291"/>
        <source>Login Error</source>
        <translation>登录错误</translation>
    </message>
    <message>
        <location filename="../src/libsync/creds/shibbolethcredentials.cpp" line="291"/>
        <source>You must sign in as user %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::ShibbolethWebView</name>
    <message>
        <location filename="../src/libsync/creds/shibboleth/shibbolethwebview.cpp" line="55"/>
        <source>%1 - Authenticate</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/creds/shibboleth/shibbolethwebview.cpp" line="61"/>
        <source>Reauthentication required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/creds/shibboleth/shibbolethwebview.cpp" line="61"/>
        <source>Your session has expired. You need to re-login to continue to use the client.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/creds/shibboleth/shibbolethwebview.cpp" line="108"/>
        <source>%1 - %2</source>
        <translation>%1 - %2</translation>
    </message>
</context>
<context>
    <name>OCC::SocketApi</name>
    <message>
        <location filename="../src/gui/socketapi.cpp" line="431"/>
        <source>Share with %1</source>
        <comment>parameter is ownCloud</comment>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::SslButton</name>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="97"/>
        <source>&lt;h3&gt;Certificate Details&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;证书信息&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="100"/>
        <source>Common Name (CN):</source>
        <translation>常用名 (CN)：</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="101"/>
        <source>Subject Alternative Names:</source>
        <translation>主体备用名称：</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="103"/>
        <source>Organization (O):</source>
        <translation>组织 (O)：</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="104"/>
        <source>Organizational Unit (OU):</source>
        <translation>单位 (OU)：</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="105"/>
        <source>State/Province:</source>
        <translation>州/省：</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="106"/>
        <source>Country:</source>
        <translation>国家：</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="107"/>
        <source>Serial:</source>
        <translation>序列号：</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="110"/>
        <source>&lt;h3&gt;Issuer&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;颁发者&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="113"/>
        <source>Issuer:</source>
        <translation>颁发者：</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="114"/>
        <source>Issued on:</source>
        <translation>颁发于：</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="115"/>
        <source>Expires on:</source>
        <translation>过期于：</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="118"/>
        <source>&lt;h3&gt;Fingerprints&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;证书指纹&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="122"/>
        <source>MD 5:</source>
        <translation>MD 5：</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="124"/>
        <source>SHA-256:</source>
        <translation>SHA-256：</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="126"/>
        <source>SHA-1:</source>
        <translation>SHA-1：</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="130"/>
        <source>&lt;p&gt;&lt;b&gt;Note:&lt;/b&gt; This certificate was manually approved&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;注意：&lt;/b&gt;此证书经手动批准&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="150"/>
        <source>%1 (self-signed)</source>
        <translation>%1 (自签署)</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="152"/>
        <source>%1</source>
        <translation>%1</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="189"/>
        <source>This connection is encrypted using %1 bit %2.
</source>
        <translation>此连接通过 %1 位的 %2 加密。
</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="192"/>
        <source>Certificate information:</source>
        <translation>证书信息：</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="221"/>
        <source>This connection is NOT secure as it is not encrypted.
</source>
        <translation>此连接未经过加密。
</translation>
    </message>
</context>
<context>
    <name>OCC::SslErrorDialog</name>
    <message>
        <location filename="../src/gui/sslerrordialog.ui" line="14"/>
        <source>Form</source>
        <translation>窗体</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.ui" line="25"/>
        <source>Trust this certificate anyway</source>
        <translation>总是信任该证书</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.ui" line="44"/>
        <location filename="../src/gui/sslerrordialog.cpp" line="65"/>
        <source>SSL Connection</source>
        <translation>SSL链接</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="134"/>
        <source>Warnings about current SSL Connection:</source>
        <translation>当前 SSL 连接的警告：</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="169"/>
        <source>with Certificate %1</source>
        <translation>使用证书 %1</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="177"/>
        <location filename="../src/gui/sslerrordialog.cpp" line="178"/>
        <location filename="../src/gui/sslerrordialog.cpp" line="179"/>
        <source>&amp;lt;not specified&amp;gt;</source>
        <translation>&amp;lt;未指定&amp;gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="180"/>
        <location filename="../src/gui/sslerrordialog.cpp" line="200"/>
        <source>Organization: %1</source>
        <translation>组织：%1</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="181"/>
        <location filename="../src/gui/sslerrordialog.cpp" line="201"/>
        <source>Unit: %1</source>
        <translation>单位：%1</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="182"/>
        <location filename="../src/gui/sslerrordialog.cpp" line="202"/>
        <source>Country: %1</source>
        <translation>国家: %1</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="189"/>
        <source>Fingerprint (MD5): &lt;tt&gt;%1&lt;/tt&gt;</source>
        <translation>MD5指纹: &lt;tt&gt;%1&lt;/tt&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="190"/>
        <source>Fingerprint (SHA1): &lt;tt&gt;%1&lt;/tt&gt;</source>
        <translation>SHA1指纹: &lt;tt&gt;%1&lt;/tt&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="192"/>
        <source>Effective Date: %1</source>
        <translation>有效日期：%1</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="193"/>
        <source>Expiration Date: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="197"/>
        <source>Issuer: %1</source>
        <translation>签发人：%1</translation>
    </message>
</context>
<context>
    <name>OCC::SyncEngine</name>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="92"/>
        <source>Success.</source>
        <translation>成功。</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="95"/>
        <source>CSync failed to load or create the journal file. Make sure you have read and write permissions in the local sync directory.</source>
        <translation>Csync同步失败，请确定是否有本地同步目录的读写权</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="99"/>
        <source>CSync failed to load the journal file. The journal file is corrupted.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="102"/>
        <source>&lt;p&gt;The %1 plugin for csync could not be loaded.&lt;br/&gt;Please verify the installation!&lt;/p&gt;</source>
        <translation>&lt;p&gt;csync 的 %1 插件不能加载。&lt;br/&gt;请校验安装！&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="105"/>
        <source>CSync got an error while processing internal trees.</source>
        <translation>CSync 在处理内部文件树时出错。</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="108"/>
        <source>CSync failed to reserve memory.</source>
        <translation>CSync 失败，内存不足。</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="111"/>
        <source>CSync fatal parameter error.</source>
        <translation>CSync 致命参数错误。</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="114"/>
        <source>CSync processing step update failed.</source>
        <translation>CSync 处理步骤更新失败。</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="117"/>
        <source>CSync processing step reconcile failed.</source>
        <translation>CSync 处理步骤调和失败。</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="120"/>
        <source>CSync could not authenticate at the proxy.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="123"/>
        <source>CSync failed to lookup proxy or server.</source>
        <translation>CSync 无法查询代理或服务器。</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="126"/>
        <source>CSync failed to authenticate at the %1 server.</source>
        <translation>CSync 于 %1 服务器认证失败。</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="129"/>
        <source>CSync failed to connect to the network.</source>
        <translation>CSync 联网失败。</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="132"/>
        <source>A network connection timeout happened.</source>
        <translation>网络连接超时。</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="135"/>
        <source>A HTTP transmission error happened.</source>
        <translation>HTTP 传输错误。</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="138"/>
        <source>CSync failed due to not handled permission deniend.</source>
        <translation>出于未处理的权限拒绝，CSync 失败。</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="141"/>
        <source>CSync failed to access </source>
        <translation>访问 CSync 失败</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="144"/>
        <source>CSync tried to create a directory that already exists.</source>
        <translation>CSync 尝试创建了已有的文件夹。</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="147"/>
        <source>CSync: No space on %1 server available.</source>
        <translation>CSync：%1 服务器空间已满。</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="150"/>
        <source>CSync unspecified error.</source>
        <translation>CSync 未定义错误。</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="153"/>
        <source>Aborted by the user</source>
        <translation>用户撤销</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="156"/>
        <source>The mounted directory is temporarily not available on the server</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="159"/>
        <source>An error opening a directory happened</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="162"/>
        <source>An internal error number %1 happened.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="217"/>
        <source>The item is not synced because of previous errors: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="340"/>
        <source>Symbolic links are not supported in syncing.</source>
        <translation>符号链接不被同步支持。</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="343"/>
        <source>Hard links are not supported in syncing.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="346"/>
        <source>File is listed on the ignore list.</source>
        <translation>文件在忽略列表中。</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="349"/>
        <source>File contains invalid characters that can not be synced cross platform.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="366"/>
        <source>Filename encoding is not valid</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="567"/>
        <source>Unable to initialize a sync journal.</source>
        <translation>无法初始化同步日志</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="648"/>
        <source>Cannot open the sync journal</source>
        <translation>无法打开同步日志</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="895"/>
        <location filename="../src/libsync/syncengine.cpp" line="902"/>
        <source>Ignored because of the &quot;choose what to sync&quot; blacklist</source>
        <translation>已忽略（“选择同步内容”黑名单）</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="920"/>
        <source>Not allowed because you don&apos;t have permission to add sub-directories in that directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="926"/>
        <source>Not allowed because you don&apos;t have permission to add parent directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="933"/>
        <source>Not allowed because you don&apos;t have permission to add files in that directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="953"/>
        <source>Not allowed to upload this file because it is read-only on the server, restoring</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="970"/>
        <location filename="../src/libsync/syncengine.cpp" line="990"/>
        <source>Not allowed to remove, restoring</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="1003"/>
        <source>Local files and share folder removed.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="1058"/>
        <source>Move not allowed, item restored</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="1067"/>
        <source>Move not allowed because %1 is read-only</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="1068"/>
        <source>the destination</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="1068"/>
        <source>the source</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::Systray</name>
    <message>
        <location filename="../src/gui/systray.cpp" line="49"/>
        <source>%1: %2</source>
        <translation>%1: %2</translation>
    </message>
</context>
<context>
    <name>OCC::Theme</name>
    <message>
        <location filename="../src/libsync/theme.cpp" line="233"/>
        <source>&lt;p&gt;Version %1. For more information please visit &lt;a href=&apos;%2&apos;&gt;%3&lt;/a&gt;.&lt;/p&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="237"/>
        <source>&lt;p&gt;Copyright ownCloud, Incorporated&lt;/p&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="238"/>
        <source>&lt;p&gt;Distributed by %1 and licensed under the GNU General Public License (GPL) Version 2.0.&lt;br/&gt;%2 and the %2 logo are registered trademarks of %1 in the United States, other countries, or both.&lt;/p&gt;</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::ownCloudGui</name>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="221"/>
        <source>Please sign in</source>
        <translation>请登录</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="226"/>
        <source>Disconnected from server</source>
        <translation>已从服务器断开</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="259"/>
        <source>Folder %1: %2</source>
        <translation>文件夹 %1: %2</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="264"/>
        <source>No sync folders configured.</source>
        <translation>没有已配置的同步文件夹。</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="274"/>
        <source>There are no sync folders configured.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="295"/>
        <source>None.</source>
        <translation>无。</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="299"/>
        <source>Recent Changes</source>
        <translation>最近修改</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="316"/>
        <source>Open %1 folder</source>
        <translation>打开 %1 目录</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="326"/>
        <source>Managed Folders:</source>
        <translation>管理的文件夹：</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="335"/>
        <source>Open folder &apos;%1&apos;</source>
        <translation>打开文件夹“%1”</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="412"/>
        <source>Open %1 in browser</source>
        <translation>在浏览器中打开%1</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="414"/>
        <source>Calculating quota...</source>
        <translation>计算配额....</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="416"/>
        <source>Unknown status</source>
        <translation>未知状态</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="418"/>
        <source>Settings...</source>
        <translation>设置...</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="419"/>
        <source>Details...</source>
        <translation>细节...</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="424"/>
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="426"/>
        <source>Quit %1</source>
        <translation>退出 %1</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="429"/>
        <source>Sign in...</source>
        <translation>登录...</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="431"/>
        <source>Sign out</source>
        <translation>注销</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="435"/>
        <source>Crash now</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="446"/>
        <source>Quota n/a</source>
        <translation>配额无限制</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="453"/>
        <source>%1% of %2 in use</source>
        <translation>已使用 %2，总计 %1%</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="465"/>
        <source>No items synced recently</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="477"/>
        <source>Discovering &apos;%1&apos;</source>
        <translation>正在发现 &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="482"/>
        <source>Syncing %1 of %2  (%3 left)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="487"/>
        <source>Syncing %1 (%2 left)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="507"/>
        <source>%1 (%2, %3)</source>
        <translation>%1 (%2, %3)</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="536"/>
        <source>Up to date</source>
        <translation>更新</translation>
    </message>
</context>
<context>
    <name>OCC::ownCloudTheme</name>
    <message utf8="true">
        <location filename="../src/libsync/owncloudtheme.cpp" line="48"/>
        <source>&lt;p&gt;Version %2. For more information visit &lt;a href=&quot;%3&quot;&gt;%4&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;small&gt;By Klaas Freitag, Daniel Molkentin, Jan-Christoph Borchardt, Olivier Goffart, Markus Götz and others.&lt;/small&gt;&lt;/p&gt;&lt;p&gt;Copyright ownCloud, Inc.&lt;/p&gt;&lt;p&gt;Licensed under the GNU General Public License (GPL) Version 2.0&lt;br/&gt;ownCloud and the ownCloud Logo are registered trademarks of ownCloud, Inc. in the United States, other countries, or both.&lt;/p&gt;</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OwncloudAdvancedSetupPage</name>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="20"/>
        <source>Form</source>
        <translation>窗体</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="32"/>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="78"/>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="115"/>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="234"/>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="272"/>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="299"/>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="322"/>
        <source>TextLabel</source>
        <translation>文本标签</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="88"/>
        <source>Server</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="265"/>
        <source>Choose what to sync</source>
        <translation>选择同步内容</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="131"/>
        <source>&amp;Local Folder</source>
        <translation>本地文件夹 (&amp;L)</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="174"/>
        <source>&amp;Start a clean sync (Erases the local folder!)</source>
        <translation>开始全新同步（将清空本地文件夹！） (&amp;S)</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="209"/>
        <source>pbSelectLocalFolder</source>
        <translation>pbSelectLocalFolder</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="161"/>
        <source>&amp;Keep local data</source>
        <translation>保留本地数据 (&amp;K)</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="171"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If this box is checked, existing content in the local directory will be erased to start a clean sync from the server.&lt;/p&gt;&lt;p&gt;Do not check this if the local content should be uploaded to the servers directory.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;当该选项被勾选，当前目录的内容将被删除，并开始同步服务器内容。&lt;/p&gt;&lt;p&gt;如果本地内容要被上传到服务器，不要勾选该选项。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="224"/>
        <source>S&amp;ync everything from server</source>
        <translation>同步服务器的所有内容 (&amp;S)</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="306"/>
        <source>Status message</source>
        <translation>状态信息</translation>
    </message>
</context>
<context>
    <name>OwncloudConnectionMethodDialog</name>
    <message>
        <location filename="../src/gui/wizard/owncloudconnectionmethoddialog.ui" line="14"/>
        <source>Connection failed</source>
        <translation>连接失败</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudconnectionmethoddialog.ui" line="43"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Failed to connect to the secure server address specified. How do you wish to proceed?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudconnectionmethoddialog.ui" line="55"/>
        <source>Select a different URL</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudconnectionmethoddialog.ui" line="62"/>
        <source>Retry unencrypted over HTTP (insecure)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudconnectionmethoddialog.ui" line="69"/>
        <source>Configure client-side TLS certificate</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudconnectionmethoddialog.cpp" line="18"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Failed to connect to the secure server address &lt;em&gt;%1&lt;/em&gt;. How do you wish to proceed?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OwncloudHttpCredsPage</name>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.ui" line="14"/>
        <source>Form</source>
        <translation>窗体</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.ui" line="38"/>
        <source>&amp;Username</source>
        <translation>用户名 (&amp;U)</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.ui" line="48"/>
        <source>&amp;Password</source>
        <translation>密码 (&amp;P)</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.ui" line="58"/>
        <source>Error Label</source>
        <translation>错误标签</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.ui" line="109"/>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.ui" line="122"/>
        <source>TextLabel</source>
        <translation>文本标签</translation>
    </message>
</context>
<context>
    <name>OwncloudSetupPage</name>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="14"/>
        <location filename="../src/gui/wizard/owncloudsetupnocredspage.ui" line="20"/>
        <source>Form</source>
        <translation>窗体</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="20"/>
        <source>Server &amp;address:</source>
        <translation>服务器地址 (&amp;A)：</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="36"/>
        <location filename="../src/gui/owncloudsetuppage.ui" line="129"/>
        <location filename="../src/gui/owncloudsetuppage.ui" line="156"/>
        <location filename="../src/gui/wizard/owncloudsetupnocredspage.ui" line="32"/>
        <location filename="../src/gui/wizard/owncloudsetupnocredspage.ui" line="187"/>
        <source>TextLabel</source>
        <translation>文本标签</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="47"/>
        <source>Use &amp;secure connection</source>
        <translation>使用安全连接 (&amp;S)</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="60"/>
        <source>CheckBox</source>
        <translation>复选框</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="75"/>
        <source>&amp;Username:</source>
        <translation>用户名 (&amp;U)：</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="85"/>
        <source>Enter the ownCloud username.</source>
        <translation>输入 ownCloud 用户名。</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="92"/>
        <source>&amp;Password:</source>
        <translation>密码 (&amp;P)：</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="102"/>
        <source>Enter the ownCloud password.</source>
        <translation>输入ownCloud密码</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="117"/>
        <source>Do not allow the local storage of the password.</source>
        <translation>不允许本地存储密码。</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="120"/>
        <source>&amp;Do not store password on local machine</source>
        <translation>不要在本地计算机上存储密码 (&amp;D)</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="140"/>
        <source>https://</source>
        <translation>https://</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="147"/>
        <source>Enter the url of the ownCloud you want to connect to (without http or https).</source>
        <translation>输入您想要连接到的 ownCloud 网址 (不带 http 或 https)。</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetupnocredspage.ui" line="83"/>
        <source>Server &amp;Address</source>
        <translation>服务器地址 (&amp;A)</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetupnocredspage.ui" line="99"/>
        <source>https://...</source>
        <translation>https://...</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetupnocredspage.ui" line="157"/>
        <source>Error Label</source>
        <translation>错误标签</translation>
    </message>
</context>
<context>
    <name>OwncloudWizardResultPage</name>
    <message>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.ui" line="14"/>
        <source>Form</source>
        <translation>窗体</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.ui" line="20"/>
        <source>TextLabel</source>
        <translation>文本标签</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.ui" line="163"/>
        <source>Your entire account is synced to the local folder </source>
        <translation>您的整个账户将被同步到本地文件夹</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.ui" line="98"/>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.ui" line="120"/>
        <source>PushButton</source>
        <translation>按钮</translation>
    </message>
</context>
<context>
    <name>Utility</name>
    <message>
        <location filename="../src/libsync/utility.cpp" line="113"/>
        <source>%L1 TiB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/utility.cpp" line="116"/>
        <source>%L1 GiB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/utility.cpp" line="119"/>
        <source>%L1 MiB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/utility.cpp" line="122"/>
        <source>%L1 KiB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/utility.cpp" line="125"/>
        <source>%L1 B</source>
        <translation>%L1 B</translation>
    </message>
</context>
<context>
    <name>main.cpp</name>
    <message>
        <location filename="../src/gui/main.cpp" line="45"/>
        <source>System Tray not available</source>
        <translation>系统托盘不可用</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="46"/>
        <source>%1 requires on a working system tray. If you are running XFCE, please follow &lt;a href=&quot;http://docs.xfce.org/xfce/xfce4-panel/systray&quot;&gt;these instructions&lt;/a&gt;. Otherwise, please install a system tray application such as &apos;trayer&apos; and try again.</source>
        <translation>%1 依赖于系统托盘程序。如果你在运行 XFCE，请按 &lt;a href=&quot;http://docs.xfce.org/xfce/xfce4-panel/systray&quot;&gt;这个指南（英文）&lt;/a&gt; 来设置。否则，请安装一个系统托盘程序，比如 trayer，然后再试。</translation>
    </message>
</context>
<context>
    <name>ownCloudTheme::about()</name>
    <message>
        <location filename="../src/libsync/theme.cpp" line="220"/>
        <source>&lt;p&gt;&lt;small&gt;Built from Git revision &lt;a href=&quot;%1&quot;&gt;%2&lt;/a&gt; on %3, %4 using Qt %5.&lt;/small&gt;&lt;/p&gt;</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>progress</name>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="32"/>
        <source>Downloaded</source>
        <translation>已下载</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="34"/>
        <source>Uploaded</source>
        <translation>已上传</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="37"/>
        <source>Deleted</source>
        <translation>已删除</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="40"/>
        <source>Moved to %1</source>
        <translation>已移动到 %1</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="42"/>
        <source>Ignored</source>
        <translation>已忽略</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="44"/>
        <source>Filesystem access error</source>
        <translation>文件系统访问错误</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="46"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="49"/>
        <location filename="../src/libsync/progressdispatcher.cpp" line="52"/>
        <source>Unknown</source>
        <translation>未知</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="62"/>
        <source>downloading</source>
        <translation>正在下载</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="64"/>
        <source>uploading</source>
        <translation>正在上传</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="66"/>
        <source>deleting</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="69"/>
        <source>moving</source>
        <translation>移动</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="71"/>
        <source>ignoring</source>
        <translation>忽略</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="73"/>
        <location filename="../src/libsync/progressdispatcher.cpp" line="75"/>
        <source>error</source>
        <translation>错误</translation>
    </message>
</context>
<context>
    <name>theme</name>
    <message>
        <location filename="../src/libsync/theme.cpp" line="54"/>
        <source>Status undefined</source>
        <translation>状态未定义</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="57"/>
        <source>Waiting to start sync</source>
        <translation>等待同步启动</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="60"/>
        <source>Sync is running</source>
        <translation>同步运行中</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="63"/>
        <source>Sync Success</source>
        <translation>同步成功</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="66"/>
        <source>Sync Success, some files were ignored.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="69"/>
        <source>Sync Error</source>
        <translation>同步错误</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="72"/>
        <source>Setup Error</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="75"/>
        <source>Preparing to sync</source>
        <translation>正在准备同步</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="78"/>
        <source>Aborting...</source>
        <translation>正在撤销...</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="81"/>
        <source>Sync is paused</source>
        <translation>同步被暂停</translation>
    </message>
</context>
</TS>