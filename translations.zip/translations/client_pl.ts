<?xml version="1.0" ?><!DOCTYPE TS><TS language="pl" version="2.0">
<context>
    <name>FolderWizardSourcePage</name>
    <message>
        <location filename="../src/gui/folderwizardsourcepage.ui" line="14"/>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardsourcepage.ui" line="33"/>
        <source>Pick a local folder on your computer to sync</source>
        <translation>Wybierz folder lokalny na komputerze do synchronizacji</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardsourcepage.ui" line="44"/>
        <source>&amp;Choose...</source>
        <translation>&amp;Wybierz...</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardsourcepage.ui" line="55"/>
        <source>&amp;Directory alias name:</source>
        <translation>&amp;Nazwa aliasu katalogu:</translation>
    </message>
</context>
<context>
    <name>FolderWizardTargetPage</name>
    <message>
        <location filename="../src/gui/folderwizardtargetpage.ui" line="14"/>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardtargetpage.ui" line="128"/>
        <source>Select a remote destination folder</source>
        <translation>Wybierz zdalny folder docelowy</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardtargetpage.ui" line="140"/>
        <source>Create Folder</source>
        <translation>Utwórz katalog</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardtargetpage.ui" line="160"/>
        <source>Refresh</source>
        <translation>Odśwież</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardtargetpage.ui" line="174"/>
        <source>Folders</source>
        <translation>Katalogi</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizardtargetpage.ui" line="107"/>
        <source>TextLabel</source>
        <translation>Etykieta tekstowa</translation>
    </message>
</context>
<context>
    <name>OCC::AccountSettings</name>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="14"/>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="20"/>
        <source>Account to Synchronize</source>
        <translation>Konto do synchronizacji</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="41"/>
        <source>Connected with &lt;server&gt; as &lt;user&gt;</source>
        <translation>Połączony z &lt;server&gt; jako &lt;user&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="55"/>
        <source>Add Folder...</source>
        <translation>Dodaj katalog...</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="62"/>
        <location filename="../src/gui/accountsettings.cpp" line="167"/>
        <source>Pause</source>
        <translation>Wstrzymaj</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="69"/>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="76"/>
        <source>Choose What to Sync</source>
        <translation>Wybierz co synchronizować</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="101"/>
        <source>Storage Usage</source>
        <translation>Użycie zasobów</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="123"/>
        <source>Retrieving usage information...</source>
        <translation>Pobieranie informacji o użyciu</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="130"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; Some folders, including network mounted or shared folders, might have different limits.</source>
        <translation>&lt;b&gt;Uwaga:&lt;/b&gt; Niektóre foldery, włączając podłączone w sieci lub współdzielone mogą mieć różne limity.</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="143"/>
        <source>Account Maintenance</source>
        <translation>Utrzymanie Konta.</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="152"/>
        <source>Edit Ignored Files</source>
        <translation>Edytuj pliki ignorowane</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.ui" line="159"/>
        <source>Modify Account</source>
        <translation>Zmień Konto</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="111"/>
        <source>No account configured.</source>
        <translation>Brak skonfigurowanych kont.</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="169"/>
        <source>Resume</source>
        <translation>Wznów</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="338"/>
        <source>Confirm Folder Remove</source>
        <translation>Potwierdź usunięcie katalogu</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="339"/>
        <source>&lt;p&gt;Do you really want to stop syncing the folder &lt;i&gt;%1&lt;/i&gt;?&lt;/p&gt;&lt;p&gt;&lt;b&gt;Note:&lt;/b&gt; This will not remove the files from your client.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Czy naprawdę chcesz przerwać synchronizację folderu &lt;i&gt;%1&lt;/i&gt;?&lt;/p&gt;&lt;p&gt;&lt;b&gt;Uwaga:&lt;/b&gt; Ta czynność nie usunie plików z klienta.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="375"/>
        <source>Confirm Folder Reset</source>
        <translation>Potwierdź reset folderu </translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="376"/>
        <source>&lt;p&gt;Do you really want to reset folder &lt;i&gt;%1&lt;/i&gt; and rebuild your client database?&lt;/p&gt;&lt;p&gt;&lt;b&gt;Note:&lt;/b&gt; This function is designed for maintenance purposes only. No files will be removed, but this can cause significant data traffic and take several minutes or hours to complete, depending on the size of the folder. Only use this option if advised by your administrator.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Czy rzeczywiście chcesz zresetować folder &lt;i&gt;%1&lt;/i&gt; i przebudować bazę klientów?&lt;/p&gt;&lt;p&gt;&lt;b&gt;Uwaga:&lt;/b&gt; Ta funkcja została przewidziana wyłącznie do czynności technicznych. Nie zostaną usunięte żadne pliki, ale może to spowodować znaczący wzrost ruchu sieciowego i potrwać kilka minut lub godzin, w zależności od rozmiaru folderu. Używaj tej opcji wyłącznie, jeśli Twój administrator doradził Ci takie działanie.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="486"/>
        <source>Sync Running</source>
        <translation>Synchronizacja uruchomiona</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="487"/>
        <source>The syncing operation is running.&lt;br/&gt;Do you want to terminate it?</source>
        <translation>Operacja synchronizacji jest uruchomiona.&lt;br&gt;Czy chcesz ją zakończyć?</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="610"/>
        <source>Discovering &apos;%1&apos;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="650"/>
        <source>%1 %2 (%3 of %4) %5 left at a rate of %6/s</source>
        <extracomment>Example text: &quot;uploading foobar.png (1MB of 2MB) time left 2 minutes at a rate of 24Kb/s&quot;</extracomment>
        <translation>%1 %2 (%3 z %4) %5 pozostało z %6/s</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="656"/>
        <source>%1 %2 (%3 of %4)</source>
        <extracomment>Example text: &quot;uploading foobar.png (2MB of 2MB)&quot;</extracomment>
        <translation>%1 %2 (%3 z %4)</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="660"/>
        <source>%1 %2</source>
        <extracomment>Example text: &quot;uploading foobar.png&quot;</extracomment>
        <translation>%1 %2</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="675"/>
        <source>%1 of %2, file %3 of %4
Total time left %5</source>
        <translation>%1 z %2, plik %3 z %4
Pozostało czasu %5</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="681"/>
        <source>file %1 of %2</source>
        <translation>plik %1 z %2</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="769"/>
        <source>%1 (%3%) of %2 server space in use.</source>
        <translation>%1 (%3%) z %2 przestrzeni na serwerze w użyciu.</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="773"/>
        <source>Currently there is no storage usage information available.</source>
        <translation>Obecnie nie ma dostępnych informacji o wykorzystaniu pamięci masowej.</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="806"/>
        <source>Connected to &lt;a href=&quot;%1&quot;&gt;%2&lt;/a&gt;.</source>
        <translation>Podłączony do &lt;a href=&quot;%1&quot;&gt;%2&lt;/a&gt;.</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="809"/>
        <source>Connected to &lt;a href=&quot;%1&quot;&gt;%2&lt;/a&gt; as &lt;i&gt;%3&lt;/i&gt;.</source>
        <translation>Podłączony do &lt;a href=&quot;%1&quot;&gt;%2&lt;/a&gt; jako &lt;i&gt;%3&lt;/i&gt;.</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="813"/>
        <source>No connection to %1 at &lt;a href=&quot;%2&quot;&gt;%3&lt;/a&gt;.</source>
        <translation>Brak połączenia do %1 na &lt;a href=&quot;%2&quot;&gt;%3&lt;/a&gt;.</translation>
    </message>
    <message>
        <location filename="../src/gui/accountsettings.cpp" line="820"/>
        <source>No %1 connection configured.</source>
        <translation>Połączenie %1 nie skonfigurowane.</translation>
    </message>
</context>
<context>
    <name>OCC::AddCertificateDialog</name>
    <message>
        <location filename="../src/gui/addcertificatedialog.ui" line="17"/>
        <source>SSL client certificate authentication</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/addcertificatedialog.ui" line="23"/>
        <source>This server probably requires a SSL client certificate.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/addcertificatedialog.ui" line="35"/>
        <source>Certificate :</source>
        <translation>Certyfikat:</translation>
    </message>
    <message>
        <location filename="../src/gui/addcertificatedialog.ui" line="51"/>
        <source>Browse...</source>
        <translation>Przeglądaj...</translation>
    </message>
    <message>
        <location filename="../src/gui/addcertificatedialog.ui" line="60"/>
        <source>Certificate password :</source>
        <translation>Hasło certyfikatu:</translation>
    </message>
    <message>
        <location filename="../src/gui/addcertificatedialog.cpp" line="23"/>
        <source>Select a certificate</source>
        <translation>Wybierz certyfikat:</translation>
    </message>
    <message>
        <location filename="../src/gui/addcertificatedialog.cpp" line="23"/>
        <source>Certificate files (*.p12 *.pfx)</source>
        <translation>Pliki certyfikatu (*.p12 *.pfx)</translation>
    </message>
</context>
<context>
    <name>OCC::AuthenticationDialog</name>
    <message>
        <location filename="../src/libsync/authenticationdialog.cpp" line="29"/>
        <source>Authentication Required</source>
        <translation>Wymagana autoryzacja</translation>
    </message>
    <message>
        <location filename="../src/libsync/authenticationdialog.cpp" line="31"/>
        <source>Enter username and password for &apos;%1&apos; at %2.</source>
        <translation>Wprowadź użytkwownika i hasło dla &apos;%1&apos; w %2.</translation>
    </message>
    <message>
        <location filename="../src/libsync/authenticationdialog.cpp" line="35"/>
        <source>&amp;User:</source>
        <translation>&amp;Użytkownik:</translation>
    </message>
    <message>
        <location filename="../src/libsync/authenticationdialog.cpp" line="36"/>
        <source>&amp;Password:</source>
        <translation>&amp;Hasło</translation>
    </message>
</context>
<context>
    <name>OCC::ConnectionValidator</name>
    <message>
        <location filename="../src/libsync/connectionvalidator.cpp" line="63"/>
        <source>No ownCloud account configured</source>
        <translation>Nie skonfigurowano konta ownCloud</translation>
    </message>
    <message>
        <location filename="../src/libsync/connectionvalidator.cpp" line="86"/>
        <source>The configured server for this client is too old</source>
        <translation>Konfigurowany serwer dla tego klienta jest za stary</translation>
    </message>
    <message>
        <location filename="../src/libsync/connectionvalidator.cpp" line="87"/>
        <source>Please update to the latest server and restart the client.</source>
        <translation>Proszę zaaktualizować serwer do najnowszej wersji i zrestartować klienta.</translation>
    </message>
    <message>
        <location filename="../src/libsync/connectionvalidator.cpp" line="106"/>
        <location filename="../src/libsync/connectionvalidator.cpp" line="113"/>
        <source>Unable to connect to %1</source>
        <translation>Nie mogę połączyć się do %1</translation>
    </message>
    <message>
        <location filename="../src/libsync/connectionvalidator.cpp" line="114"/>
        <source>timeout</source>
        <translation>wygaśnięcie</translation>
    </message>
    <message>
        <location filename="../src/libsync/connectionvalidator.cpp" line="147"/>
        <source>The provided credentials are not correct</source>
        <translation>Podane dane logowania są nieprawidłowe</translation>
    </message>
</context>
<context>
    <name>OCC::DeleteJob</name>
    <message>
        <location filename="../src/libsync/propagateremotedelete.cpp" line="41"/>
        <source>Connection timed out</source>
        <translation>Przekroczono czas odpowiedzi</translation>
    </message>
</context>
<context>
    <name>OCC::Folder</name>
    <message>
        <location filename="../src/gui/folder.cpp" line="107"/>
        <source>Unable to create csync-context</source>
        <translation>Nie można utworzyć kontekstu csync</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="162"/>
        <source>Local folder %1 does not exist.</source>
        <translation>Folder lokalny %1 nie istnieje.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="165"/>
        <source>%1 should be a directory but is not.</source>
        <translation>%1 powinien być katalogiem, ale nie jest.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="168"/>
        <source>%1 is not readable.</source>
        <translation>%1 jest nie do odczytu.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="359"/>
        <source>%1: %2</source>
        <translation>%1: %2</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="459"/>
        <source>%1 and %2 other files have been removed.</source>
        <comment>%1 names a file.</comment>
        <translation>%1 i %2 inne pliki zostały usunięte.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="461"/>
        <source>%1 has been removed.</source>
        <comment>%1 names a file.</comment>
        <translation>%1 został usunięty.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="466"/>
        <source>%1 and %2 other files have been downloaded.</source>
        <comment>%1 names a file.</comment>
        <translation>%1 i %2 pozostałe pliki zostały ściągnięte.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="468"/>
        <source>%1 has been downloaded.</source>
        <comment>%1 names a file.</comment>
        <translation>%1 został ściągnięty.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="473"/>
        <source>%1 and %2 other files have been updated.</source>
        <translation>%1 i %2 inne pliki zostały zaktualizowane.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="475"/>
        <source>%1 has been updated.</source>
        <comment>%1 names a file.</comment>
        <translation>%1 został uaktualniony.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="480"/>
        <source>%1 has been renamed to %2 and %3 other files have been renamed.</source>
        <translation>%1 zmienił nazwę na %2 i %3 inne pliki mają zmienione nazwy.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="482"/>
        <source>%1 has been renamed to %2.</source>
        <comment>%1 and %2 name files.</comment>
        <translation>%1 zmienił nazwę na %2.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="487"/>
        <source>%1 has been moved to %2 and %3 other files have been moved.</source>
        <translation>%1 został zmieniony na %2 i  %3 inne pliku zostały przeniesione.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="489"/>
        <source>%1 has been moved to %2.</source>
        <translation>%1 został przeniesiony do %2.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="494"/>
        <source>%1 and %2 other files could not be synced due to errors. See the log for details.</source>
        <comment>%1 names a file.</comment>
        <translation>%1 i %2 inne pliki nie mogą zostać zsynchronizowane z powodu błędów. Zobacz szczegóły w logu.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="496"/>
        <source>%1 could not be synced due to an error. See the log for details.</source>
        <translation>%1 nie może zostać zsynchronizowany z powodu błędu. Zobacz szczegóły w logu.</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="504"/>
        <source>Sync Activity</source>
        <translation>Aktywności synchronizacji</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="782"/>
        <source>Could not read system exclude file</source>
        <translation>Nie można przeczytać pliku wyłączeń</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="1002"/>
        <source>This sync would remove all the files in the sync folder '%1'.
This might be because the folder was silently reconfigured, or that all the file were manually removed.
Are you sure you want to perform this operation?</source>
        <translation>Ta synchronizacja usunie wszystkie pliku z lokalnego folderu synchronizacji &apos;%1&apos;.
Mogło się tak zdarzyć z powodu niezauważonej rekonfiguracji folderu, lub też wszystkie pliki zostały ręcznie usunięte.
Czy jesteś pewien/pewna, że chcesz wykonać tę operację?</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="1006"/>
        <source>Remove All Files?</source>
        <translation>Usunąć wszystkie pliki?</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="1008"/>
        <source>Remove all files</source>
        <translation>Usuń wszystkie pliki</translation>
    </message>
    <message>
        <location filename="../src/gui/folder.cpp" line="1009"/>
        <source>Keep files</source>
        <translation>Pozostaw pliki</translation>
    </message>
</context>
<context>
    <name>OCC::FolderMan</name>
    <message>
        <location filename="../src/gui/folderman.cpp" line="232"/>
        <source>Could not reset folder state</source>
        <translation>Nie udało się zresetować stanu folderu</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="233"/>
        <source>An old sync journal &apos;%1&apos; was found, but could not be removed. Please make sure that no application is currently using it.</source>
        <translation>Stary sync journal &apos;%1&apos; został znaleziony, lecz nie mógł być usunięty. Proszę się upewnić, że żaden program go obecnie nie używa.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1021"/>
        <source>Undefined State.</source>
        <translation>Niezdefiniowany stan</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1024"/>
        <source>Waits to start syncing.</source>
        <translation>Czekają na uruchomienie synchronizacji.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1027"/>
        <source>Preparing for sync.</source>
        <translation>Przygotowuję do synchronizacji</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1030"/>
        <source>Sync is running.</source>
        <translation>Synchronizacja w toku</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1033"/>
        <source>Last Sync was successful.</source>
        <translation>Ostatnia synchronizacja zakończona powodzeniem.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1038"/>
        <source>Last Sync was successful, but with warnings on individual files.</source>
        <translation>Ostatnia synchronizacja udana, ale istnieją ostrzeżenia z pojedynczymi plikami.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1041"/>
        <source>Setup Error.</source>
        <translation>Błąd ustawień.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1044"/>
        <source>User Abort.</source>
        <translation>Użytkownik anulował.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1047"/>
        <source>Sync is paused.</source>
        <translation>Synchronizacja wstrzymana</translation>
    </message>
    <message>
        <location filename="../src/gui/folderman.cpp" line="1053"/>
        <source>%1 (Sync is paused)</source>
        <translation> %1 (Synchronizacja jest zatrzymana)</translation>
    </message>
</context>
<context>
    <name>OCC::FolderStatusDelegate</name>
    <message>
        <location filename="../src/gui/folderstatusmodel.cpp" line="95"/>
        <location filename="../src/gui/folderstatusmodel.cpp" line="264"/>
        <source>File</source>
        <translation>Plik</translation>
    </message>
    <message>
        <location filename="../src/gui/folderstatusmodel.cpp" line="218"/>
        <source>Syncing all files in your account with</source>
        <translation>Synchronizacja wszystkich plików na koncie z</translation>
    </message>
    <message>
        <location filename="../src/gui/folderstatusmodel.cpp" line="221"/>
        <source>Remote path: %1</source>
        <translation>Zdalna ścieżka: %1</translation>
    </message>
</context>
<context>
    <name>OCC::FolderWizard</name>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="502"/>
        <location filename="../src/gui/folderwizard.cpp" line="504"/>
        <source>Add Folder</source>
        <translation>Dodaj folder</translation>
    </message>
</context>
<context>
    <name>OCC::FolderWizardLocalPath</name>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="63"/>
        <source>Click to select a local folder to sync.</source>
        <translation>Kliknij, aby wybrać folder lokalny do synchronizacji.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="67"/>
        <source>Enter the path to the local folder.</source>
        <translation>Wpisz ścieżkę do folderu lokalnego.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="71"/>
        <source>The directory alias is a descriptive name for this sync connection.</source>
        <translation>Alias katalogu jest nazwą opisową dla tego połączenia synchronizacji.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="100"/>
        <source>No valid local folder selected!</source>
        <translation>Nie wybrano poprawnego lokalnego katalogu!</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="105"/>
        <source>You have no permission to write to the selected folder!</source>
        <translation>Nie masz uprawnień, aby zapisywać w tym  katalogu!</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="129"/>
        <source>The local path %1 is already an upload folder. Please pick another one!</source>
        <translation>Ścieżka lokalna %1 już istnieje w  zdalnym folderze. Proszę wybrać inną!</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="134"/>
        <source>An already configured folder is contained in the current entry.</source>
        <translation>Folder jest już skonfigurowany w bieżącym wpisie.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="141"/>
        <source>The selected folder is a symbolic link. An already configured folder is contained in the folder this link is pointing to.</source>
        <translation>Zaznaczony folder jest linkiem symbolicznym. Skonfigurowany folder jest tym, na który wskazuje ten link.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="148"/>
        <source>An already configured folder contains the currently entered folder.</source>
        <translation>Folder już skonfigurowany zawiera katalogi aktualnie wprowadzone.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="154"/>
        <source>The selected folder is a symbolic link. An already configured folder is the parent of the current selected contains the folder this link is pointing to.</source>
        <translation>Zaznaczony folder jest linkiem symbolicznym. Skonfigurowany już folder jest nadrzędnym w stosunku do folderu na który wskazuje ten link.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="167"/>
        <source>The alias can not be empty. Please provide a descriptive alias word.</source>
        <translation>Alias nie może być pusty. Proszę wprowadzić alias.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="178"/>
        <source>The alias &lt;i&gt;%1&lt;/i&gt; is already in use. Please pick another alias.</source>
        <translation>Alias &lt;i&gt;%1&lt;/i&gt; jest już używany. Wprowadź inny alias.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="211"/>
        <source>Select the source folder</source>
        <translation>Wybierz katalog źródłowy</translation>
    </message>
</context>
<context>
    <name>OCC::FolderWizardRemotePath</name>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="258"/>
        <source>Create Remote Folder</source>
        <translation>Dodaj zdalny katalog</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="259"/>
        <source>Enter the name of the new folder to be created below &apos;%1&apos;:</source>
        <translation>Wpisz nazwę dla nowego katalogu, utworzonego poniżej &apos;%1&apos;:</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="288"/>
        <source>Folder was successfully created on %1.</source>
        <translation>Folder został utworzony pomyślnie na %1</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="296"/>
        <source>Failed to create the folder on %1. Please check manually.</source>
        <translation>Nie udało się utworzyć folderu na %1. Proszę sprawdzić ręcznie.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="345"/>
        <source>Choose this to sync the entire account</source>
        <translation>Wybierz to, aby zsynchronizować całe konto</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="400"/>
        <source>This folder is already being synced.</source>
        <translation>Ten katalog jest już synchronizowany.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="402"/>
        <source>You are already syncing &lt;i&gt;%1&lt;/i&gt;, which is a parent folder of &lt;i&gt;%2&lt;/i&gt;.</source>
        <translation>Synchronizujesz już &lt;i&gt;%1&lt;/i&gt;, który jest folderem nadrzędnym &lt;i&gt;%2&lt;/i&gt;.</translation>
    </message>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="406"/>
        <source>You are already syncing all your files. Syncing another folder is &lt;b&gt;not&lt;/b&gt; supported. If you want to sync multiple folders, please remove the currently configured root folder sync.</source>
        <translation>Już aktualizujesz wszystkie pliku. Synchronizacja innego folderu &lt;b&gt;nie&lt;/b&gt; jest wspierana. Jeśli chcesz synchronizować wiele folderów, proszę usuń aktualnie skonfigurowaną synchronizację folderu głównego.</translation>
    </message>
</context>
<context>
    <name>OCC::FolderWizardSelectiveSync</name>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="444"/>
        <source>Choose What to Sync: You can optionally deselect remote subfolders you do not wish to synchronize.</source>
        <translation>Wybierz co synchronizować: Możesz opcjonalnie odznaczyć podkatalogi, których nie chcesz synchronizować.</translation>
    </message>
</context>
<context>
    <name>OCC::FormatWarningsWizardPage</name>
    <message>
        <location filename="../src/gui/folderwizard.cpp" line="45"/>
        <location filename="../src/gui/folderwizard.cpp" line="47"/>
        <source>&lt;b&gt;Warning:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Ostrzeżenie:&lt;/b&gt; </translation>
    </message>
</context>
<context>
    <name>OCC::GETFileJob</name>
    <message>
        <location filename="../src/libsync/propagatedownload.cpp" line="122"/>
        <source>No E-Tag received from server, check Proxy/Gateway</source>
        <translation>Nie otrzymano E-Tag z serwera, sprawdź Proxy/Bramę</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagatedownload.cpp" line="129"/>
        <source>We received a different E-Tag for resuming. Retrying next time.</source>
        <translation>Otrzymaliśmy inny E-Tag wznowienia. Spróbuje ponownie następnym razem.</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagatedownload.cpp" line="156"/>
        <source>Server returned wrong content-range</source>
        <translation>Serwer zwrócił błędną zakres zawartości</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagatedownload.cpp" line="257"/>
        <source>Connection Timeout</source>
        <translation>Limit czasu połączenia</translation>
    </message>
</context>
<context>
    <name>OCC::GeneralSettings</name>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="14"/>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="20"/>
        <source>General Settings</source>
        <translation>Ustawienia ogólne</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="26"/>
        <source>Launch on System Startup</source>
        <translation>Uruchamiaj razem z systemem</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="33"/>
        <source>Show Desktop Notifications</source>
        <translation>Pokaż powiadomienia na pulpicie</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="40"/>
        <source>Use Monochrome Icons</source>
        <translation>Użyj monochromicznych ikon</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="47"/>
        <source>Show crash reporter</source>
        <translation>Pokaż raport awarii</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="57"/>
        <location filename="../src/gui/generalsettings.ui" line="63"/>
        <source>About</source>
        <translation>O aplikacji</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="73"/>
        <source>Updates</source>
        <translation>Aktualizacje</translation>
    </message>
    <message>
        <location filename="../src/gui/generalsettings.ui" line="98"/>
        <source>&amp;Restart &amp;&amp; Update</source>
        <translation>&amp;Zrestartuj &amp;&amp; Aktualizuj</translation>
    </message>
</context>
<context>
    <name>OCC::HttpCredentialsGui</name>
    <message>
        <location filename="../src/libsync/creds/httpcredentials.cpp" line="400"/>
        <source>Enter Password</source>
        <translation>Wprowadź hasło</translation>
    </message>
    <message>
        <location filename="../src/libsync/creds/httpcredentials.cpp" line="401"/>
        <source>Please enter %1 password for user &apos;%2&apos;:</source>
        <translation>Proszę podać hasło %1 dla użytkownika &apos;%2&apos;:</translation>
    </message>
</context>
<context>
    <name>OCC::IgnoreListEditor</name>
    <message>
        <location filename="../src/gui/ignorelisteditor.ui" line="14"/>
        <source>Ignored Files Editor</source>
        <translation>Edytor ignorowanych plików</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.ui" line="53"/>
        <source>Add</source>
        <translation>Dodaj</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.ui" line="63"/>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="35"/>
        <source>Files or directories matching a pattern will not be synchronized.

Checked items will also be deleted if they prevent a directory from being removed. This is useful for meta data.</source>
        <translation>Pliki lub katalogi zgodne ze wzorem nie będą zsynchronizowane.

Zaznaczone przedmioty także będą usunięte, jeżeli będą przeszkadzać w usunięciu katalogu. Jest to przydatne dla meta data.</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="97"/>
        <source>Could not open file</source>
        <translation>Nie można otworzyć plików</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="98"/>
        <source>Cannot write changes to &apos;%1&apos;.</source>
        <translation>Nie mogę zapisać zmian do &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="105"/>
        <source>Add Ignore Pattern</source>
        <translation>Dodaj ignorowany</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="106"/>
        <source>Add a new ignore pattern:</source>
        <translation>Dodaj nowy ignorowany:</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="128"/>
        <source>Edit Ignore Pattern</source>
        <translation>Edytuj ignorowane</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="129"/>
        <source>Edit ignore pattern:</source>
        <translation>Edytuj ignorowane:</translation>
    </message>
    <message>
        <location filename="../src/gui/ignorelisteditor.cpp" line="140"/>
        <source>This entry is provided by the system at &apos;%1&apos; and cannot be modified in this view.</source>
        <translation>Ten wpis jest podawany przez system w &apos;%1&apos; i nie może być zmieniony w tym widoku.</translation>
    </message>
</context>
<context>
    <name>OCC::LogBrowser</name>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="59"/>
        <source>Log Output</source>
        <translation>Treść dziennika</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="71"/>
        <source>&amp;Search: </source>
        <translation>&amp;Szukaj: </translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="79"/>
        <source>&amp;Find</source>
        <translation>&amp;Znajdź</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="97"/>
        <source>Clear</source>
        <translation>Wyczyść</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="98"/>
        <source>Clear the log display.</source>
        <translation>Wyczyść wyświetlane dzienniki.</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="104"/>
        <source>S&amp;ave</source>
        <translation>Z&amp;apisz</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="105"/>
        <source>Save the log file to a file on disk for debugging.</source>
        <translation>Zapisz plik dziennika do pliku na dysku w celu debugowania.</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="184"/>
        <source>Save log file</source>
        <translation>Zapisz plik dziennika</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="194"/>
        <source>Error</source>
        <translation>Błąd</translation>
    </message>
    <message>
        <location filename="../src/gui/logbrowser.cpp" line="194"/>
        <source>Could not write to log file </source>
        <translation>Nie można zapisać w pliku dziennika</translation>
    </message>
</context>
<context>
    <name>OCC::Logger</name>
    <message>
        <location filename="../src/libsync/logger.cpp" line="148"/>
        <source>Error</source>
        <translation>Błąd</translation>
    </message>
    <message>
        <location filename="../src/libsync/logger.cpp" line="149"/>
        <source>&lt;nobr&gt;File &apos;%1&apos;&lt;br/&gt;cannot be opened for writing.&lt;br/&gt;&lt;br/&gt;The log output can &lt;b&gt;not&lt;/b&gt; be saved!&lt;/nobr&gt;</source>
        <translation>&lt;nobr&gt;Plik &apos;%1&apos;&lt;br&gt;nie może zostać otwarty do zapisu.&lt;br/&gt;&lt;br/&gt;Dane wyjściowe dziennika &lt;b&gt;nie&lt;/b&gt; mogą być zapisane!&lt;/nobr&gt;</translation>
    </message>
</context>
<context>
    <name>OCC::MoveJob</name>
    <message>
        <location filename="../src/libsync/propagateremotemove.cpp" line="45"/>
        <source>Connection timed out</source>
        <translation>Przekroczono czas odpowiedzi</translation>
    </message>
</context>
<context>
    <name>OCC::NSISUpdater</name>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="256"/>
        <source>New Version Available</source>
        <translation>Nowa wersja dostępna</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="262"/>
        <source>&lt;p&gt;A new version of the %1 Client is available.&lt;/p&gt;&lt;p&gt;&lt;b&gt;%2&lt;/b&gt; is available for download. The installed version is %3.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Nowa wersja klienta %1 jest dostępna.&lt;/p&gt;&lt;p&gt;&lt;b&gt;%2&lt;/b&gt;jest dostępna do pobrania. Zainstalowana wersja to %3.&lt;p&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="275"/>
        <source>Skip this version</source>
        <translation>Pomiń tą wersję</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="276"/>
        <source>Skip this time</source>
        <translation>Pomiń tym razem</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="277"/>
        <source>Get update</source>
        <translation>Uaktualnij</translation>
    </message>
</context>
<context>
    <name>OCC::NetworkSettings</name>
    <message>
        <location filename="../src/gui/networksettings.ui" line="14"/>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="23"/>
        <source>Proxy Settings</source>
        <translation>Ustawienia proxy</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="29"/>
        <source>No Proxy</source>
        <translation>bez proxy</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="42"/>
        <source>Use system proxy</source>
        <translation>Użyj proxy</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="52"/>
        <source>Specify proxy manually as</source>
        <translation>Określ serwer proxy ręcznie jako</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="80"/>
        <source>Host</source>
        <translation>Host</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="100"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="134"/>
        <source>Proxy server requires authentication</source>
        <translation>Serwer proxy wymaga uwierzytelnienia</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="190"/>
        <source>Download Bandwidth</source>
        <translation>Przepustowość pobierania</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="196"/>
        <location filename="../src/gui/networksettings.ui" line="278"/>
        <source>Limit to</source>
        <translation>Limit do</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="218"/>
        <location filename="../src/gui/networksettings.ui" line="320"/>
        <source>KBytes/s</source>
        <translation>KBajtów/s</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="227"/>
        <location filename="../src/gui/networksettings.ui" line="295"/>
        <source>No limit</source>
        <translation>Brak limitu</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="272"/>
        <source>Upload Bandwidth</source>
        <translation>Przepustowość wysyłania</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.ui" line="285"/>
        <source>Limit automatically</source>
        <translation>Limit automatyczniy</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.cpp" line="34"/>
        <source>Hostname of proxy server</source>
        <translation>Nazwa hosta serwera proxy</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.cpp" line="35"/>
        <source>Username for proxy server</source>
        <translation>Nazwa użytkownika serwera proxy</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.cpp" line="36"/>
        <source>Password for proxy server</source>
        <translation>Hasło użytkownika serwera proxy</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.cpp" line="38"/>
        <source>HTTP(S) proxy</source>
        <translation>HTTP(S) proxy</translation>
    </message>
    <message>
        <location filename="../src/gui/networksettings.cpp" line="39"/>
        <source>SOCKS5 proxy</source>
        <translation>SOCKS5 proxy</translation>
    </message>
</context>
<context>
    <name>OCC::OCUpdater</name>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="55"/>
        <source>New Update Ready</source>
        <translation>Nowe aktualizacje gotowe</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="56"/>
        <source>A new update is about to be installed. The updater may ask
for additional privileges during the process.</source>
        <translation>Nowa aktualizacja ma zostać zainstalowana. Instalator może 
poprosić o dodatkowe uprawnienia podczas tego procesu.</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="77"/>
        <source>Downloading version %1. Please wait...</source>
        <translation>Pobieranie wersji %1. Proszę czekać...</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="79"/>
        <source>Version %1 available. Restart application to start the update.</source>
        <translation>Wersja %1 jest dostępna. Uruchom ponownie aplikację aby uruchomić aktualizację.</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="81"/>
        <source>Could not download update. Please click &lt;a href=&apos;%1&apos;&gt;here&lt;/a&gt; to download the update manually.</source>
        <translation>Nie można pobrać aktualizacji. Proszę kliknąć &lt;a href=&apos;%1&apos;&gt;tutaj&lt;/a&gt;, aby ściągnąć aktualizację ręcznie</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="83"/>
        <source>Could not check for new updates.</source>
        <translation>Nie można sprawdzić dostępności nowych aktualizacji.</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="85"/>
        <source>New version %1 available. Please use the system&apos;s update tool to install it.</source>
        <translation>Nowa wersja %1 jest dostępna. Aby ją zainstalować, użyj systemowego narzędzia do aktualizacji.</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="87"/>
        <source>Checking update server...</source>
        <translation>Sprawdzanie aktualizacji serwera...</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="89"/>
        <source>Update status is unknown: Did not check for new updates.</source>
        <translation>Status aktualizacji nieznany. Nie sprawdzono nowych aktualizacji.</translation>
    </message>
    <message>
        <location filename="../src/gui/updater/ocupdater.cpp" line="93"/>
        <source>No updates available. Your installation is at the latest version.</source>
        <translation>Brak dostępnych aktualizacji. Twoja instalacja jest w najnowszej wersji.</translation>
    </message>
</context>
<context>
    <name>OCC::OwncloudAdvancedSetupPage</name>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="50"/>
        <source>Connect to %1</source>
        <translation>Podłącz do %1</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="51"/>
        <source>Setup local folder options</source>
        <translation>Ustawienia opcji lokalnych katalogów</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="60"/>
        <source>Connect...</source>
        <translation>Połącz...</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="135"/>
        <source>%1 folder &apos;%2&apos; is synced to local folder &apos;%3&apos;</source>
        <translation>%1 katalog &apos;%2&apos; jest zsynchronizowany do katalogu lokalnego &apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="141"/>
        <source>&lt;p&gt;&lt;small&gt;&lt;strong&gt;Warning:&lt;/strong&gt; You currently have multiple folders configured. If you continue with the current settings, the folder configurations will be discarded and a single root folder sync will be created!&lt;/small&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;small&gt;&lt;strong&gt;Uwaga:&lt;/strong&gt; Masz obecnie skonfigurowane wielokrotne katalogi . Jeśli będziesz kontynuować z obecnymi ustawieniami, konfiguracje katalogów będą odrzucone i pojedyncza synchronizacja głównego katalogu będzie utworzona!&lt;/small&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="148"/>
        <source>&lt;p&gt;&lt;small&gt;&lt;strong&gt;Warning:&lt;/strong&gt; The local directory is not empty. Pick a resolution!&lt;/small&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;small&gt;&lt;strong&gt;Uwaga:&lt;/strong&gt; Lokalny katalog nie jest pusty. Wybierz rozważnie!&lt;/small&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="265"/>
        <source>Local Sync Folder</source>
        <translation>Folder lokalnej synchronizacji</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="278"/>
        <source>Update advanced setup</source>
        <translation>Zaktualizuj zaawansowane ustawienia</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="297"/>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.cpp" line="318"/>
        <source>(%1)</source>
        <translation>(%1)</translation>
    </message>
</context>
<context>
    <name>OCC::OwncloudHttpCredsPage</name>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.cpp" line="46"/>
        <source>Connect to %1</source>
        <translation>Podłącz do %1</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.cpp" line="47"/>
        <source>Enter user credentials</source>
        <translation>Wprowadź poświadczenia użytkownika</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.cpp" line="164"/>
        <source>Update user credentials</source>
        <translation>Zaktualizuj poświadczenia uzytkownika</translation>
    </message>
</context>
<context>
    <name>OCC::OwncloudSetupPage</name>
    <message>
        <location filename="../src/gui/wizard/owncloudsetuppage.cpp" line="50"/>
        <source>Connect to %1</source>
        <translation>Podłącz do %1</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetuppage.cpp" line="51"/>
        <source>Setup %1 server</source>
        <translation>Ustaw serwer %1</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetuppage.cpp" line="120"/>
        <source>This url is NOT secure as it is not encrypted.
It is not advisable to use it.</source>
        <translation>Ten adres url NIE jest bezpieczny, ponieważ jest nieszyfrowany.
Niezalecane jest jego użycie.</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetuppage.cpp" line="124"/>
        <source>This url is secure. You can use it.</source>
        <translation>Ten adres url jest bezpieczny. Można go użyć.</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetuppage.cpp" line="163"/>
        <source>&amp;Next &gt;</source>
        <translation>Następny</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetuppage.cpp" line="295"/>
        <source>Update %1 server</source>
        <translation>Zaktualizuj serwer %1</translation>
    </message>
</context>
<context>
    <name>OCC::OwncloudSetupWizard</name>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="161"/>
        <source>&lt;font color=&quot;green&quot;&gt;Successfully connected to %1: %2 version %3 (%4)&lt;/font&gt;&lt;br/&gt;&lt;br/&gt;</source>
        <translation>&lt;font color=&quot;green&quot;&gt;Udane połączenie z %1: %2 wersja %3 (%4)&lt;/font&gt;&lt;br/&gt;&lt;br/&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="185"/>
        <source>Failed to connect to %1 at %2:&lt;br/&gt;%3</source>
        <translation>Nie udało się połączyć do %1 w %2:&lt;br/&gt;%3</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="193"/>
        <source>Timeout while trying to connect to %1 at %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="204"/>
        <source>Trying to connect to %1 at %2...</source>
        <translation>Próba połączenia z %1 w %2...</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="253"/>
        <source>Access forbidden by server. To verify that you have proper access, &lt;a href=&quot;%1&quot;&gt;click here&lt;/a&gt; to access the service with your browser.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="275"/>
        <source>Local sync folder %1 already exists, setting it up for sync.&lt;br/&gt;&lt;br/&gt;</source>
        <translation>Lokalny folder synchronizacji %1 już istnieje. Ustawiam go do synchronizacji.&lt;br/&gt;&lt;br/&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="277"/>
        <source>Creating local sync folder %1... </source>
        <translation>Tworzenie lokalnego folderu synchronizowanego %1...</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="281"/>
        <source>ok</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="283"/>
        <source>failed.</source>
        <translation>Błąd.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="285"/>
        <source>Could not create local folder %1</source>
        <translation>Nie udało się utworzyć lokalnego folderu %1</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="310"/>
        <source>No remote folder specified!</source>
        <translation>Nie określono folderu zdalnego!</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="316"/>
        <source>Error: %1</source>
        <translation>Błąd: %1</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="329"/>
        <source>creating folder on ownCloud: %1</source>
        <translation>tworzę folder na ownCloud: %1</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="345"/>
        <source>Remote folder %1 created successfully.</source>
        <translation>Zdalny folder %1 został utworzony pomyślnie.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="347"/>
        <source>The remote folder %1 already exists. Connecting it for syncing.</source>
        <translation>Zdalny folder %1 już istnieje. Podłączam go do synchronizowania.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="349"/>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="351"/>
        <source>The folder creation resulted in HTTP error code %1</source>
        <translation>Tworzenie folderu spowodowało kod błędu HTTP %1</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="353"/>
        <source>The remote folder creation failed because the provided credentials are wrong!&lt;br/&gt;Please go back and check your credentials.&lt;/p&gt;</source>
        <translation>Nie udało się utworzyć zdalnego folderu ponieważ podane dane dostępowe są nieprawidłowe!&lt;br/&gt;Wróć i sprawdź podane dane dostępowe.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="356"/>
        <source>&lt;p&gt;&lt;font color=&quot;red&quot;&gt;Remote folder creation failed probably because the provided credentials are wrong.&lt;/font&gt;&lt;br/&gt;Please go back and check your credentials.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;font color=&quot;red&quot;&gt;Tworzenie folderu zdalnego nie powiodło się. Prawdopodobnie dostarczone poświadczenia są błędne.&lt;/font&gt;&lt;br/&gt;Wróć i sprawdź poświadczenia.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="361"/>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="362"/>
        <source>Remote folder %1 creation failed with error &lt;tt&gt;%2&lt;/tt&gt;.</source>
        <translation>Tworzenie folderu zdalnego %1 nie powiodło się z powodu błędu &lt;tt&gt;%2&lt;/tt&gt;.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="378"/>
        <source>A sync connection from %1 to remote directory %2 was set up.</source>
        <translation>Połączenie synchronizacji z %1 do katalogu zdalnego %2 zostało utworzone.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="383"/>
        <source>Successfully connected to %1!</source>
        <translation>Udane połączenie z %1!</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="390"/>
        <source>Connection to %1 could not be established. Please check again.</source>
        <translation>Połączenie z %1 nie może być nawiązane. Sprawdź ponownie.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="403"/>
        <source>Folder rename failed</source>
        <translation>Zmiana nazwy folderu nie powiodła się</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="404"/>
        <source>Can&apos;t remove and back up the folder because the folder or a file in it is open in another program. Please close the folder or file and hit retry or cancel the setup.</source>
        <translation>Nie można usunąć i zarchiwizować folderu ponieważ znajdujący się w nim plik lub folder jest otwarty przez inny program. Proszę zamknąć folder lub plik albo kliknąć ponów lub anuluj setup.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetupwizard.cpp" line="450"/>
        <source>&lt;font color=&quot;green&quot;&gt;&lt;b&gt;Local sync folder %1 successfully created!&lt;/b&gt;&lt;/font&gt;</source>
        <translation>&lt;font color=&quot;green&quot;&gt;&lt;b&gt;Utworzenie lokalnego folderu synchronizowanego %1 zakończone pomyślnie!&lt;/b&gt;&lt;/font&gt;</translation>
    </message>
</context>
<context>
    <name>OCC::OwncloudWizard</name>
    <message>
        <location filename="../src/gui/wizard/owncloudwizard.cpp" line="74"/>
        <source>%1 Connection Wizard</source>
        <translation>%1 Kreator połączeń</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudwizard.cpp" line="83"/>
        <source>Skip folders configuration</source>
        <translation>Pomiń konfigurację folderów</translation>
    </message>
</context>
<context>
    <name>OCC::OwncloudWizardResultPage</name>
    <message>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.cpp" line="38"/>
        <source>Everything set up!</source>
        <translation>Wszystko skonfigurowane!</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.cpp" line="42"/>
        <source>Open Local Folder</source>
        <translation>Otwórz lokalny folder</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.cpp" line="50"/>
        <source>Open %1 in Browser</source>
        <translation>Otwórz %1 w przeglądarce</translation>
    </message>
</context>
<context>
    <name>OCC::PUTFileJob</name>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="76"/>
        <source>Connection Timeout</source>
        <translation>Limit czasu połączenia</translation>
    </message>
</context>
<context>
    <name>OCC::PollJob</name>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="121"/>
        <source>Invalid JSON reply from the poll URL</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::PropagateDownloadFileLegacy</name>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="435"/>
        <source>Sync was aborted by user.</source>
        <translation>Synchronizacja anulowane przez użytkownika.</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="488"/>
        <source>No E-Tag received from server, check Proxy/Gateway</source>
        <translation>Nie otrzymano E-Tag z serwera, sprawdź Proxy/Bramę</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="494"/>
        <source>We received a different E-Tag for resuming. Retrying next time.</source>
        <translation>Otrzymaliśmy inny E-Tag wznowienia. Spróbuje ponownie następnym razem.</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="516"/>
        <source>Server returned wrong content-range</source>
        <translation>Serwer zwrócił błędną zakres zawartości</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="567"/>
        <source>File %1 can not be downloaded because of a local file name clash!</source>
        <translation>Nie można pobrać pliku %1 ze względu na konflikt nazwy pliku lokalnego!</translation>
    </message>
</context>
<context>
    <name>OCC::PropagateDownloadFileQNAM</name>
    <message>
        <location filename="../src/libsync/propagatedownload.cpp" line="271"/>
        <source>File %1 can not be downloaded because of a local file name clash!</source>
        <translation>Nie można pobrać pliku %1 ze względu na konflikt nazwy pliku lokalnego!</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagatedownload.cpp" line="429"/>
        <source>The file could not be downloaded completely.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/propagatedownload.cpp" line="465"/>
        <source>File %1 cannot be saved because of a local file name clash!</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::PropagateItemJob</name>
    <message>
        <location filename="../src/libsync/owncloudpropagator.cpp" line="81"/>
        <source>; Restoration Failed: </source>
        <translation>; Przywracanie nie powiodło się:</translation>
    </message>
    <message>
        <location filename="../src/libsync/owncloudpropagator.cpp" line="104"/>
        <source>Continue blacklisting: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/owncloudpropagator.cpp" line="200"/>
        <source>A file or directory was removed from a read only share, but restoring failed: %1</source>
        <translation>Plik lub katalog został usunięty z udziału z prawem tylko do odczytu, ale przywrócenie nie powiodło się: %1</translation>
    </message>
</context>
<context>
    <name>OCC::PropagateLocalMkdir</name>
    <message>
        <location filename="../src/libsync/propagatorjobs.cpp" line="116"/>
        <source>Attention, possible case sensitivity clash with %1</source>
        <translation>Uwaga, możliwa niezgodność związana z wielością liter w %1</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagatorjobs.cpp" line="121"/>
        <source>could not create directory %1</source>
        <translation>nie można utworzyć katalogu %1</translation>
    </message>
</context>
<context>
    <name>OCC::PropagateLocalRemove</name>
    <message>
        <location filename="../src/libsync/propagatorjobs.cpp" line="57"/>
        <source>Error removing &apos;%1&apos;: %2; </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/propagatorjobs.cpp" line="68"/>
        <source>Could not remove directory &apos;%1&apos;; </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/propagatorjobs.cpp" line="83"/>
        <source>Could not remove %1 because of a local file name clash</source>
        <translation>Nie można usunąć %1 z powodu kolizji z lokalną nazwą pliku</translation>
    </message>
</context>
<context>
    <name>OCC::PropagateLocalRename</name>
    <message>
        <location filename="../src/libsync/propagatorjobs.cpp" line="148"/>
        <source>File %1 can not be renamed to %2 because of a local file name clash</source>
        <translation>Plik %1 nie może być nazwany %2 z powodu kolizji z lokalną nazwą pliku</translation>
    </message>
</context>
<context>
    <name>OCC::PropagateRemoteDelete</name>
    <message>
        <location filename="../src/libsync/propagateremotedelete.cpp" line="87"/>
        <source>The file has been removed from a read only share. It was restored.</source>
        <translation>Plik został usunięty z zasobu z prawem tylko do odczytu. Został przywrócony.</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagateremotedelete.cpp" line="103"/>
        <source>Wrong HTTP code returned by server. Expected 204, but recieved &quot;%1 %2&quot;.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::PropagateRemoteMkdir</name>
    <message>
        <location filename="../src/libsync/propagateremotemkdir.cpp" line="67"/>
        <source>Wrong HTTP code returned by server. Expected 201, but recieved &quot;%1 %2&quot;.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::PropagateRemoteMove</name>
    <message>
        <location filename="../src/libsync/propagateremotemove.cpp" line="73"/>
        <source>This folder must not be renamed. It is renamed back to its original name.</source>
        <translation>Folder ten nie może być zmieniony. Został zmieniony z powrotem do pierwotnej nazwy.</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagateremotemove.cpp" line="75"/>
        <source>This folder must not be renamed. Please name it back to Shared.</source>
        <translation>Nie wolno zmieniać nazwy tego folderu. Proszę zmień nazwę z powrotem na Shared.</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagateremotemove.cpp" line="111"/>
        <source>The file was renamed but is part of a read only share. The original file was restored.</source>
        <translation>Plik był edytowany lokalnie ale jest częścią udziału z prawem tylko do odczytu. Przywrócono oryginalny plik</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagateremotemove.cpp" line="127"/>
        <source>Wrong HTTP code returned by server. Expected 201, but recieved &quot;%1 %2&quot;.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::PropagateUploadFileLegacy</name>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="243"/>
        <location filename="../src/libsync/propagator_legacy.cpp" line="302"/>
        <source>Local file changed during sync, syncing once it arrived completely</source>
        <translation>Lokalny plik zmienił się podczas synchronizacji, synchronizuję ponownie ponieważ dotarł w całości.</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="246"/>
        <source>Sync was aborted by user.</source>
        <translation>Synchronizacja anulowane przez użytkownika.</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagator_legacy.cpp" line="252"/>
        <source>The file was edited locally but is part of a read only share. It is restored and your edit is in the conflict file.</source>
        <translation>Plik był edytowany lokalnie ale jest częścią udziału z prawem tylko do odczytu. Został przywrócony i Twoja edycja jest w pliku konfliktu</translation>
    </message>
</context>
<context>
    <name>OCC::PropagateUploadFileQNAM</name>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="156"/>
        <source>File Removed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="171"/>
        <location filename="../src/libsync/propagateupload.cpp" line="510"/>
        <source>Local file changed during sync.</source>
        <translation>Lokalny plik zmienił się podczas synchronizacji.</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="438"/>
        <source>The file was edited locally but is part of a read only share. It is restored and your edit is in the conflict file.</source>
        <translation>Plik był edytowany lokalnie ale jest częścią udziału z prawem tylko do odczytu. Został przywrócony i Twoja edycja jest w pliku konfliktu</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="468"/>
        <source>Poll URL missing</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="493"/>
        <source>The local file was removed during sync.</source>
        <translation>Pliki lokalny został usunięty podczas synchronizacji.</translation>
    </message>
    <message>
        <location filename="../src/libsync/propagateupload.cpp" line="525"/>
        <source>The server did not acknowledge the last chunk. (No e-tag were present)</source>
        <translation>Serwer nie potwierdził ostatniego łańcucha danych. (Nie było żadnego e-tag-u)</translation>
    </message>
</context>
<context>
    <name>OCC::ProtocolWidget</name>
    <message>
        <location filename="../src/gui/protocolwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.ui" line="20"/>
        <source>Sync Activity</source>
        <translation>Aktywności synchronizacji</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.ui" line="49"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.ui" line="54"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="50"/>
        <source>Time</source>
        <translation>Czas</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="51"/>
        <source>File</source>
        <translation>Plik</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="52"/>
        <source>Folder</source>
        <translation>Folder</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="53"/>
        <source>Action</source>
        <translation>Akcja</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="54"/>
        <source>Size</source>
        <translation>Rozmiar</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="68"/>
        <source>Retry Sync</source>
        <translation>Ponów synchronizację</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="72"/>
        <source>Copy</source>
        <translation>Kopiuj</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="73"/>
        <source>Copy the activity list to the clipboard.</source>
        <translation>Kopiuj listę aktywności do schowka.</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="118"/>
        <source>Copied to clipboard</source>
        <translation>Skopiuj do schowka</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="118"/>
        <source>The sync status has been copied to the clipboard.</source>
        <translation>Status synchronizacji został skopiowany do schowka.</translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="262"/>
        <source>Currently no files are ignored because of previous errors and no downloads are in progress.</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <location filename="../src/gui/protocolwidget.cpp" line="265"/>
        <source>%n files are ignored because of previous errors.
</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message numerus="yes">
        <location filename="../src/gui/protocolwidget.cpp" line="266"/>
        <source>%n files are partially downloaded.
</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <location filename="../src/gui/protocolwidget.cpp" line="267"/>
        <source>Try to sync these again.</source>
        <translation>Spróbuj połączyć się ponownie z tym samym</translation>
    </message>
</context>
<context>
    <name>OCC::SelectiveSyncDialog</name>
    <message>
        <location filename="../src/gui/selectivesyncdialog.cpp" line="306"/>
        <source>Unchecked folders will be &lt;b&gt;removed&lt;/b&gt; from your local file system and will not be synchronized to this computer anymore</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/selectivesyncdialog.cpp" line="318"/>
        <source>Choose What to Sync: Select remote subfolders you wish to synchronize.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/selectivesyncdialog.cpp" line="319"/>
        <source>Choose What to Sync: Deselect remote subfolders you do not wish to synchronize.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/selectivesyncdialog.cpp" line="325"/>
        <source>Choose What to Sync</source>
        <translation>Wybierz co synchronizować</translation>
    </message>
</context>
<context>
    <name>OCC::SelectiveSyncTreeView</name>
    <message>
        <location filename="../src/gui/selectivesyncdialog.cpp" line="36"/>
        <source>Loading ...</source>
        <translation>Wczytuję ...</translation>
    </message>
    <message>
        <location filename="../src/gui/selectivesyncdialog.cpp" line="47"/>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <location filename="../src/gui/selectivesyncdialog.cpp" line="48"/>
        <source>Size</source>
        <translation>Rozmiar</translation>
    </message>
</context>
<context>
    <name>OCC::SettingsDialog</name>
    <message>
        <location filename="../src/gui/settingsdialog.ui" line="14"/>
        <source>Settings</source>
        <translation>Ustawienia</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialog.cpp" line="72"/>
        <source>Account</source>
        <translation>Konto</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialog.cpp" line="77"/>
        <source>Activity</source>
        <translation>Aktywność</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialog.cpp" line="83"/>
        <source>General</source>
        <translation>Ogólne</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialog.cpp" line="89"/>
        <source>Network</source>
        <translation>Sieć</translation>
    </message>
</context>
<context>
    <name>OCC::SettingsDialogMac</name>
    <message>
        <location filename="../src/gui/settingsdialogmac.cpp" line="63"/>
        <source>%1</source>
        <translation>%1</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialogmac.cpp" line="67"/>
        <source>Account</source>
        <translation>Konto</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialogmac.cpp" line="71"/>
        <source>Activity</source>
        <translation>Aktywność</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialogmac.cpp" line="75"/>
        <source>General</source>
        <translation>Ogólne</translation>
    </message>
    <message>
        <location filename="../src/gui/settingsdialogmac.cpp" line="79"/>
        <source>Network</source>
        <translation>Sieć</translation>
    </message>
</context>
<context>
    <name>OCC::ShareDialog</name>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="14"/>
        <source>Share NewDocument.odt</source>
        <translation>Udostępnij NewDocument.odt</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="26"/>
        <source>Share Info</source>
        <translation>Udostępnij informację</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="34"/>
        <location filename="../src/gui/sharedialog.ui" line="177"/>
        <source>TextLabel</source>
        <translation>Etykieta</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="53"/>
        <source>share label</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="75"/>
        <source>OwnCloud Path:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="89"/>
        <source>Share link</source>
        <translation>Udostępnij link</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="127"/>
        <source>Set password</source>
        <translation>Ustaw hasło</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.ui" line="149"/>
        <source>Set expiry date</source>
        <translation>Ustaw datę wygaśnięcia</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="67"/>
        <location filename="../src/gui/sharedialog.cpp" line="461"/>
        <source>%1 path: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="68"/>
        <source>%1 Sharing</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="141"/>
        <source>Password Protected</source>
        <translation>Zabezpieczone hasłem</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="299"/>
        <source>Choose a password for the public link</source>
        <translation>Wybierz hasło dla linku publicznego</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="351"/>
        <source>OCS API error code: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="374"/>
        <source>There is no sync folder configured.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="386"/>
        <source>Can not find an folder to upload to.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="393"/>
        <source>Sharing of external directories is not yet working.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="408"/>
        <source>A sync file with the same name exists. The file can not be registered to sync.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="420"/>
        <source>Waiting to upload...</source>
        <translation>Oczekuję na przesyłanie</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="422"/>
        <source>Unable to register in sync space.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="453"/>
        <source>The file can not be synced.</source>
        <translation>Nie można zsynchronizować pliku</translation>
    </message>
    <message>
        <location filename="../src/gui/sharedialog.cpp" line="463"/>
        <source>Sync of registered file was not successful yet.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::ShibbolethCredentials</name>
    <message>
        <location filename="../src/libsync/creds/shibbolethcredentials.cpp" line="291"/>
        <source>Login Error</source>
        <translation>Błąd logowania</translation>
    </message>
    <message>
        <location filename="../src/libsync/creds/shibbolethcredentials.cpp" line="291"/>
        <source>You must sign in as user %1</source>
        <translation>Musisz zalogować się jako użytkownik %1</translation>
    </message>
</context>
<context>
    <name>OCC::ShibbolethWebView</name>
    <message>
        <location filename="../src/libsync/creds/shibboleth/shibbolethwebview.cpp" line="55"/>
        <source>%1 - Authenticate</source>
        <translation>%1 - Uwierzytelnienia</translation>
    </message>
    <message>
        <location filename="../src/libsync/creds/shibboleth/shibbolethwebview.cpp" line="61"/>
        <source>Reauthentication required</source>
        <translation>Wymagana powtórna autoryzacja</translation>
    </message>
    <message>
        <location filename="../src/libsync/creds/shibboleth/shibbolethwebview.cpp" line="61"/>
        <source>Your session has expired. You need to re-login to continue to use the client.</source>
        <translation>Twoja sesja wygasła. Musisz ponownie się zalogować, aby nadal używać klienta</translation>
    </message>
    <message>
        <location filename="../src/libsync/creds/shibboleth/shibbolethwebview.cpp" line="108"/>
        <source>%1 - %2</source>
        <translation>%1 - %2</translation>
    </message>
</context>
<context>
    <name>OCC::SocketApi</name>
    <message>
        <location filename="../src/gui/socketapi.cpp" line="431"/>
        <source>Share with %1</source>
        <comment>parameter is ownCloud</comment>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::SslButton</name>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="97"/>
        <source>&lt;h3&gt;Certificate Details&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;Szczegóły certyfikatu&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="100"/>
        <source>Common Name (CN):</source>
        <translation>Nazwa (CN):</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="101"/>
        <source>Subject Alternative Names:</source>
        <translation>Alternatywna nazwa tematu:</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="103"/>
        <source>Organization (O):</source>
        <translation>Organizacja (O):</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="104"/>
        <source>Organizational Unit (OU):</source>
        <translation>Jednostka organizacyjna (OU):</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="105"/>
        <source>State/Province:</source>
        <translation>Województwo </translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="106"/>
        <source>Country:</source>
        <translation>Kraj:</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="107"/>
        <source>Serial:</source>
        <translation>Numer seryjny:</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="110"/>
        <source>&lt;h3&gt;Issuer&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;Wystawca&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="113"/>
        <source>Issuer:</source>
        <translation>Emitent:</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="114"/>
        <source>Issued on:</source>
        <translation>Data wydania:</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="115"/>
        <source>Expires on:</source>
        <translation>Wygasa:</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="118"/>
        <source>&lt;h3&gt;Fingerprints&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;Odciski palców&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="122"/>
        <source>MD 5:</source>
        <translation>MD 5:</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="124"/>
        <source>SHA-256:</source>
        <translation>SHA-256:</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="126"/>
        <source>SHA-1:</source>
        <translation>SHA-1:</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="130"/>
        <source>&lt;p&gt;&lt;b&gt;Note:&lt;/b&gt; This certificate was manually approved&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Uwaga:&lt;/b&gt; Ten certyfikat został ręcznie zaakceptowany&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="150"/>
        <source>%1 (self-signed)</source>
        <translation>%1 (własnoręcznie podpisany)</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="152"/>
        <source>%1</source>
        <translation>%1</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="189"/>
        <source>This connection is encrypted using %1 bit %2.
</source>
        <translation>o połączenie jest szyfrowane przy użyciu %1 bit %2.
</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="192"/>
        <source>Certificate information:</source>
        <translation>Informacje Certyfikatu:</translation>
    </message>
    <message>
        <location filename="../src/gui/sslbutton.cpp" line="221"/>
        <source>This connection is NOT secure as it is not encrypted.
</source>
        <translation>To połączenie NIE jest bezpieczne, ponieważ jest nieszyfrowane.
</translation>
    </message>
</context>
<context>
    <name>OCC::SslErrorDialog</name>
    <message>
        <location filename="../src/gui/sslerrordialog.ui" line="14"/>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.ui" line="25"/>
        <source>Trust this certificate anyway</source>
        <translation>Zaufaj temu zaświadczeniu mimo wszystko.</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.ui" line="44"/>
        <location filename="../src/gui/sslerrordialog.cpp" line="65"/>
        <source>SSL Connection</source>
        <translation>Połączenie szyfrowane</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="134"/>
        <source>Warnings about current SSL Connection:</source>
        <translation>Ostrzeżenia dotyczące bieżącego połączenia SSL:</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="169"/>
        <source>with Certificate %1</source>
        <translation>z certyfikatem %1</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="177"/>
        <location filename="../src/gui/sslerrordialog.cpp" line="178"/>
        <location filename="../src/gui/sslerrordialog.cpp" line="179"/>
        <source>&amp;lt;not specified&amp;gt;</source>
        <translation>&amp;lt;nie określono&amp;gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="180"/>
        <location filename="../src/gui/sslerrordialog.cpp" line="200"/>
        <source>Organization: %1</source>
        <translation>Organizacja: %1</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="181"/>
        <location filename="../src/gui/sslerrordialog.cpp" line="201"/>
        <source>Unit: %1</source>
        <translation>Jednostka: %1</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="182"/>
        <location filename="../src/gui/sslerrordialog.cpp" line="202"/>
        <source>Country: %1</source>
        <translation>Kraj: %1</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="189"/>
        <source>Fingerprint (MD5): &lt;tt&gt;%1&lt;/tt&gt;</source>
        <translation>Odcisk (MD5): &lt;tt&gt;%1&lt;/tt&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="190"/>
        <source>Fingerprint (SHA1): &lt;tt&gt;%1&lt;/tt&gt;</source>
        <translation>Odcisk (SHA1): &lt;tt&gt;%1&lt;/tt&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="192"/>
        <source>Effective Date: %1</source>
        <translation>Data wejścia w życie: %1</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="193"/>
        <source>Expiration Date: %1</source>
        <translation>Data wygaśnięcia: %1</translation>
    </message>
    <message>
        <location filename="../src/gui/sslerrordialog.cpp" line="197"/>
        <source>Issuer: %1</source>
        <translation>Wystawca: %1</translation>
    </message>
</context>
<context>
    <name>OCC::SyncEngine</name>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="92"/>
        <source>Success.</source>
        <translation>Sukces.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="95"/>
        <source>CSync failed to load or create the journal file. Make sure you have read and write permissions in the local sync directory.</source>
        <translation>CSync nie powiodło się załadowanie lub utworzenie pliku dziennika. Upewnij się, że masz prawa do odczytu i zapisu do lokalnego katalogu synchronizacji.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="99"/>
        <source>CSync failed to load the journal file. The journal file is corrupted.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="102"/>
        <source>&lt;p&gt;The %1 plugin for csync could not be loaded.&lt;br/&gt;Please verify the installation!&lt;/p&gt;</source>
        <translation>&lt;p&gt;Wtyczka %1 do csync nie może być załadowana.&lt;br/&gt;Sprawdź poprawność instalacji!&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="105"/>
        <source>CSync got an error while processing internal trees.</source>
        <translation>CSync napotkał błąd podczas przetwarzania wewnętrznych drzew.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="108"/>
        <source>CSync failed to reserve memory.</source>
        <translation>CSync nie mógł zarezerwować pamięci.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="111"/>
        <source>CSync fatal parameter error.</source>
        <translation>Krytyczny błąd parametru CSync.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="114"/>
        <source>CSync processing step update failed.</source>
        <translation>Aktualizacja procesu przetwarzania CSync nie powiodła się.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="117"/>
        <source>CSync processing step reconcile failed.</source>
        <translation>Scalenie w procesie przetwarzania CSync nie powiodło się.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="120"/>
        <source>CSync could not authenticate at the proxy.</source>
        <translation>CSync nie mógł się uwierzytelnić przez proxy.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="123"/>
        <source>CSync failed to lookup proxy or server.</source>
        <translation>CSync nie mógł odnaleźć serwera proxy.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="126"/>
        <source>CSync failed to authenticate at the %1 server.</source>
        <translation>CSync nie mógł uwierzytelnić się na serwerze %1.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="129"/>
        <source>CSync failed to connect to the network.</source>
        <translation>CSync nie mógł połączyć się z siecią.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="132"/>
        <source>A network connection timeout happened.</source>
        <translation>Upłynął limit czasu połączenia.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="135"/>
        <source>A HTTP transmission error happened.</source>
        <translation>Wystąpił błąd transmisji HTTP.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="138"/>
        <source>CSync failed due to not handled permission deniend.</source>
        <translation>CSync nie obsługiwane, odmowa uprawnień.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="141"/>
        <source>CSync failed to access </source>
        <translation>Synchronizacja nieudana z powodu braku dostępu</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="144"/>
        <source>CSync tried to create a directory that already exists.</source>
        <translation>CSync próbował utworzyć katalog, który już istnieje.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="147"/>
        <source>CSync: No space on %1 server available.</source>
        <translation>CSync: Brak dostępnego miejsca na serwerze %1.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="150"/>
        <source>CSync unspecified error.</source>
        <translation>Nieokreślony błąd CSync.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="153"/>
        <source>Aborted by the user</source>
        <translation>Anulowane przez użytkownika</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="156"/>
        <source>The mounted directory is temporarily not available on the server</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="159"/>
        <source>An error opening a directory happened</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="162"/>
        <source>An internal error number %1 happened.</source>
        <translation>Wystąpił błąd wewnętrzny numer %1.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="217"/>
        <source>The item is not synced because of previous errors: %1</source>
        <translation>Ten element nie jest zsynchronizowane z powodu poprzednich błędów: %1</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="340"/>
        <source>Symbolic links are not supported in syncing.</source>
        <translation>Linki symboliczne nie są wspierane przy synchronizacji. </translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="343"/>
        <source>Hard links are not supported in syncing.</source>
        <translation>Linki stałe nie są wspierane podczas synchronizacji.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="346"/>
        <source>File is listed on the ignore list.</source>
        <translation>Plik jest na liście plików ignorowanych.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="349"/>
        <source>File contains invalid characters that can not be synced cross platform.</source>
        <translation>Plik zawiera nieprawidłowe znaki, które nie mogą być synchronizowane wieloplatformowo.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="366"/>
        <source>Filename encoding is not valid</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="567"/>
        <source>Unable to initialize a sync journal.</source>
        <translation>Nie można zainicjować synchronizacji dziennika.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="648"/>
        <source>Cannot open the sync journal</source>
        <translation>Nie można otworzyć dziennika synchronizacji</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="895"/>
        <location filename="../src/libsync/syncengine.cpp" line="902"/>
        <source>Ignored because of the &quot;choose what to sync&quot; blacklist</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="920"/>
        <source>Not allowed because you don&apos;t have permission to add sub-directories in that directory</source>
        <translation>Nie masz uprawnień do dodawania podkatalogów w tym katalogu.</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="926"/>
        <source>Not allowed because you don&apos;t have permission to add parent directory</source>
        <translation>Nie masz uprawnień by dodać katalog nadrzędny</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="933"/>
        <source>Not allowed because you don&apos;t have permission to add files in that directory</source>
        <translation>Nie masz uprawnień by dodać pliki w tym katalogu</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="953"/>
        <source>Not allowed to upload this file because it is read-only on the server, restoring</source>
        <translation>Wgrywanie niedozwolone, ponieważ plik jest tylko do odczytu na serwerze, przywracanie</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="970"/>
        <location filename="../src/libsync/syncengine.cpp" line="990"/>
        <source>Not allowed to remove, restoring</source>
        <translation>Brak uprawnień by usunąć, przywracanie</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="1003"/>
        <source>Local files and share folder removed.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="1058"/>
        <source>Move not allowed, item restored</source>
        <translation>Przenoszenie niedozwolone, obiekt przywrócony</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="1067"/>
        <source>Move not allowed because %1 is read-only</source>
        <translation>Przenoszenie niedozwolone, ponieważ %1 jest tylko do odczytu</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="1068"/>
        <source>the destination</source>
        <translation>docelowy</translation>
    </message>
    <message>
        <location filename="../src/libsync/syncengine.cpp" line="1068"/>
        <source>the source</source>
        <translation>źródło</translation>
    </message>
</context>
<context>
    <name>OCC::Systray</name>
    <message>
        <location filename="../src/gui/systray.cpp" line="49"/>
        <source>%1: %2</source>
        <translation>%1: %2</translation>
    </message>
</context>
<context>
    <name>OCC::Theme</name>
    <message>
        <location filename="../src/libsync/theme.cpp" line="233"/>
        <source>&lt;p&gt;Version %1. For more information please visit &lt;a href=&apos;%2&apos;&gt;%3&lt;/a&gt;.&lt;/p&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="237"/>
        <source>&lt;p&gt;Copyright ownCloud, Incorporated&lt;/p&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="238"/>
        <source>&lt;p&gt;Distributed by %1 and licensed under the GNU General Public License (GPL) Version 2.0.&lt;br/&gt;%2 and the %2 logo are registered trademarks of %1 in the United States, other countries, or both.&lt;/p&gt;</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OCC::ownCloudGui</name>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="221"/>
        <source>Please sign in</source>
        <translation>Proszę się zalogować</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="226"/>
        <source>Disconnected from server</source>
        <translation>Rozłączono z serwerem</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="259"/>
        <source>Folder %1: %2</source>
        <translation>Folder %1: %2</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="264"/>
        <source>No sync folders configured.</source>
        <translation>Nie skonfigurowano synchronizowanych folderów.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="274"/>
        <source>There are no sync folders configured.</source>
        <translation>Nie skonfigurowano żadnych folderów synchronizacji.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="295"/>
        <source>None.</source>
        <translation>Brak.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="299"/>
        <source>Recent Changes</source>
        <translation>Ostatnie zmiany</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="316"/>
        <source>Open %1 folder</source>
        <translation>Otwórz folder %1</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="326"/>
        <source>Managed Folders:</source>
        <translation>Zarządzane foldery:</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="335"/>
        <source>Open folder &apos;%1&apos;</source>
        <translation>Otwórz katalog &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="412"/>
        <source>Open %1 in browser</source>
        <translation>Otwórz %1 w przeglądarce</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="414"/>
        <source>Calculating quota...</source>
        <translation>Obliczam quote...</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="416"/>
        <source>Unknown status</source>
        <translation>Nieznany status</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="418"/>
        <source>Settings...</source>
        <translation>Ustawienia...</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="419"/>
        <source>Details...</source>
        <translation>Szczegóły...</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="424"/>
        <source>Help</source>
        <translation>Pomoc</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="426"/>
        <source>Quit %1</source>
        <translation>Wyjdź %1</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="429"/>
        <source>Sign in...</source>
        <translation>Loguję...</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="431"/>
        <source>Sign out</source>
        <translation>Wyloguj</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="435"/>
        <source>Crash now</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="446"/>
        <source>Quota n/a</source>
        <translation>Quota n/a</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="453"/>
        <source>%1% of %2 in use</source>
        <translation>%1% z %2 w użyciu</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="465"/>
        <source>No items synced recently</source>
        <translation>Brak ostatnich synchronizacji</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="477"/>
        <source>Discovering &apos;%1&apos;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="482"/>
        <source>Syncing %1 of %2  (%3 left)</source>
        <translation>Synchronizacja %1 z %2 (%3 pozostało)</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="487"/>
        <source>Syncing %1 (%2 left)</source>
        <translation>Synchronizuję %1 (%2 pozostało)</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="507"/>
        <source>%1 (%2, %3)</source>
        <translation>%1 (%2, %3)</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudgui.cpp" line="536"/>
        <source>Up to date</source>
        <translation>Aktualne</translation>
    </message>
</context>
<context>
    <name>OCC::ownCloudTheme</name>
    <message utf8="true">
        <location filename="../src/libsync/owncloudtheme.cpp" line="48"/>
        <source>&lt;p&gt;Version %2. For more information visit &lt;a href=&quot;%3&quot;&gt;%4&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;small&gt;By Klaas Freitag, Daniel Molkentin, Jan-Christoph Borchardt, Olivier Goffart, Markus Götz and others.&lt;/small&gt;&lt;/p&gt;&lt;p&gt;Copyright ownCloud, Inc.&lt;/p&gt;&lt;p&gt;Licensed under the GNU General Public License (GPL) Version 2.0&lt;br/&gt;ownCloud and the ownCloud Logo are registered trademarks of ownCloud, Inc. in the United States, other countries, or both.&lt;/p&gt;</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OwncloudAdvancedSetupPage</name>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="20"/>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="32"/>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="78"/>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="115"/>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="234"/>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="272"/>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="299"/>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="322"/>
        <source>TextLabel</source>
        <translation>Etykieta</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="88"/>
        <source>Server</source>
        <translation>Serwer</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="265"/>
        <source>Choose what to sync</source>
        <translation>Wybierz co synchronizować</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="131"/>
        <source>&amp;Local Folder</source>
        <translation>&amp;Lokalny folder</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="174"/>
        <source>&amp;Start a clean sync (Erases the local folder!)</source>
        <translation>&amp;Start czystej synchronizacji (Czyści folder lokalny!)</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="209"/>
        <source>pbSelectLocalFolder</source>
        <translation>pbWybierzLokalnyFolder</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="161"/>
        <source>&amp;Keep local data</source>
        <translation>&amp;Zachowaj dane lokalne</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="171"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If this box is checked, existing content in the local directory will be erased to start a clean sync from the server.&lt;/p&gt;&lt;p&gt;Do not check this if the local content should be uploaded to the servers directory.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Jeśli zaznaczysz, istniejąca zawartość w lokalnym katalogu zostanie wymazana w celu rozpoczęcia czystej synchronizacji z serwerem.&lt;/p&gt;&lt;p&gt;Nie zaznaczaj, jeśli chcesz aby lokalna zawartość została wysłana do katalogu na serwerze.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="224"/>
        <source>S&amp;ync everything from server</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudadvancedsetuppage.ui" line="306"/>
        <source>Status message</source>
        <translation>Status wiadomości</translation>
    </message>
</context>
<context>
    <name>OwncloudConnectionMethodDialog</name>
    <message>
        <location filename="../src/gui/wizard/owncloudconnectionmethoddialog.ui" line="14"/>
        <source>Connection failed</source>
        <translation>Połączenie nie powiodło się</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudconnectionmethoddialog.ui" line="43"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Failed to connect to the secure server address specified. How do you wish to proceed?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudconnectionmethoddialog.ui" line="55"/>
        <source>Select a different URL</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudconnectionmethoddialog.ui" line="62"/>
        <source>Retry unencrypted over HTTP (insecure)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudconnectionmethoddialog.ui" line="69"/>
        <source>Configure client-side TLS certificate</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudconnectionmethoddialog.cpp" line="18"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Failed to connect to the secure server address &lt;em&gt;%1&lt;/em&gt;. How do you wish to proceed?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OwncloudHttpCredsPage</name>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.ui" line="14"/>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.ui" line="38"/>
        <source>&amp;Username</source>
        <translation>&amp;Nazwa użytkownika</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.ui" line="48"/>
        <source>&amp;Password</source>
        <translation>&amp;Hasło</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.ui" line="58"/>
        <source>Error Label</source>
        <translation>Etykieta błędu</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.ui" line="109"/>
        <location filename="../src/gui/wizard/owncloudhttpcredspage.ui" line="122"/>
        <source>TextLabel</source>
        <translation>Etykieta</translation>
    </message>
</context>
<context>
    <name>OwncloudSetupPage</name>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="14"/>
        <location filename="../src/gui/wizard/owncloudsetupnocredspage.ui" line="20"/>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="20"/>
        <source>Server &amp;address:</source>
        <translation>Adres &amp;serwera:</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="36"/>
        <location filename="../src/gui/owncloudsetuppage.ui" line="129"/>
        <location filename="../src/gui/owncloudsetuppage.ui" line="156"/>
        <location filename="../src/gui/wizard/owncloudsetupnocredspage.ui" line="32"/>
        <location filename="../src/gui/wizard/owncloudsetupnocredspage.ui" line="187"/>
        <source>TextLabel</source>
        <translation>Etykieta tekstowa</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="47"/>
        <source>Use &amp;secure connection</source>
        <translation>Użyj &amp;szyfrowanego połączenia</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="60"/>
        <source>CheckBox</source>
        <translation>Pole wyboru</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="75"/>
        <source>&amp;Username:</source>
        <translation>&amp;Nazwa użytkownika:</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="85"/>
        <source>Enter the ownCloud username.</source>
        <translation>Podaj nazwę użytkownika ownCloud.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="92"/>
        <source>&amp;Password:</source>
        <translation>&amp;Hasło</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="102"/>
        <source>Enter the ownCloud password.</source>
        <translation>Podaj hasło ownCloud.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="117"/>
        <source>Do not allow the local storage of the password.</source>
        <translation>Nie zezwalaj na lokalne przechowywanie hasła.</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="120"/>
        <source>&amp;Do not store password on local machine</source>
        <translation>&amp;Nie przechowuj hasła na tej maszynie lokalnej</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="140"/>
        <source>https://</source>
        <translation>https://</translation>
    </message>
    <message>
        <location filename="../src/gui/owncloudsetuppage.ui" line="147"/>
        <source>Enter the url of the ownCloud you want to connect to (without http or https).</source>
        <translation>Wprowadź adres ownCloud, z którym chcesz się połączyć (bez http lub https).</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetupnocredspage.ui" line="83"/>
        <source>Server &amp;Address</source>
        <translation>Adres &amp;serwera</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetupnocredspage.ui" line="99"/>
        <source>https://...</source>
        <translation>https://...</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudsetupnocredspage.ui" line="157"/>
        <source>Error Label</source>
        <translation>Etykieta błędu</translation>
    </message>
</context>
<context>
    <name>OwncloudWizardResultPage</name>
    <message>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.ui" line="14"/>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.ui" line="20"/>
        <source>TextLabel</source>
        <translation>Etykieta tekstowa</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.ui" line="163"/>
        <source>Your entire account is synced to the local folder </source>
        <translation>Twoje całe konto zostało zsynchronizowane z twoim lokalnym folderem</translation>
    </message>
    <message>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.ui" line="98"/>
        <location filename="../src/gui/wizard/owncloudwizardresultpage.ui" line="120"/>
        <source>PushButton</source>
        <translation>
Kliknij</translation>
    </message>
</context>
<context>
    <name>Utility</name>
    <message>
        <location filename="../src/libsync/utility.cpp" line="113"/>
        <source>%L1 TiB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/utility.cpp" line="116"/>
        <source>%L1 GiB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/utility.cpp" line="119"/>
        <source>%L1 MiB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/utility.cpp" line="122"/>
        <source>%L1 KiB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libsync/utility.cpp" line="125"/>
        <source>%L1 B</source>
        <translation>%L1 B</translation>
    </message>
</context>
<context>
    <name>main.cpp</name>
    <message>
        <location filename="../src/gui/main.cpp" line="45"/>
        <source>System Tray not available</source>
        <translation>Systemowy pasek nie dostępny</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="46"/>
        <source>%1 requires on a working system tray. If you are running XFCE, please follow &lt;a href=&quot;http://docs.xfce.org/xfce/xfce4-panel/systray&quot;&gt;these instructions&lt;/a&gt;. Otherwise, please install a system tray application such as &apos;trayer&apos; and try again.</source>
        <translation>%1 potrzebuje na pracującej tacce systemu. Jeżeli używasz XFCE, proszę dostosować się &lt;a href=&quot;http://docs.xfce.org/xfce/xfce4-panel/systray&quot;&gt;do tych instrukcji&lt;/a&gt;. Alternatywnie, proszę zainstalować program tacki systemu jak np. &apos;trayer&apos; i spróbować ponownie.</translation>
    </message>
</context>
<context>
    <name>ownCloudTheme::about()</name>
    <message>
        <location filename="../src/libsync/theme.cpp" line="220"/>
        <source>&lt;p&gt;&lt;small&gt;Built from Git revision &lt;a href=&quot;%1&quot;&gt;%2&lt;/a&gt; on %3, %4 using Qt %5.&lt;/small&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;small&gt;Zbudowane z rewizji Git &lt;a href=&quot;%1&quot;&gt;%2&lt;/a&gt; na %3, %4 przy użyciu Qt %5.&lt;/small&gt;&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>progress</name>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="32"/>
        <source>Downloaded</source>
        <translation>Pobrane</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="34"/>
        <source>Uploaded</source>
        <translation>Wysłane</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="37"/>
        <source>Deleted</source>
        <translation>Usunięte</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="40"/>
        <source>Moved to %1</source>
        <translation>Przeniesione do %1</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="42"/>
        <source>Ignored</source>
        <translation>Ignorowany</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="44"/>
        <source>Filesystem access error</source>
        <translation>Błąd dostępu do systemu plików</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="46"/>
        <source>Error</source>
        <translation>Błąd</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="49"/>
        <location filename="../src/libsync/progressdispatcher.cpp" line="52"/>
        <source>Unknown</source>
        <translation>Nieznany</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="62"/>
        <source>downloading</source>
        <translation>pobieram</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="64"/>
        <source>uploading</source>
        <translation>przesyłanie</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="66"/>
        <source>deleting</source>
        <translation>usuwam</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="69"/>
        <source>moving</source>
        <translation>przenoszę</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="71"/>
        <source>ignoring</source>
        <translation>ignorowane</translation>
    </message>
    <message>
        <location filename="../src/libsync/progressdispatcher.cpp" line="73"/>
        <location filename="../src/libsync/progressdispatcher.cpp" line="75"/>
        <source>error</source>
        <translation>błąd</translation>
    </message>
</context>
<context>
    <name>theme</name>
    <message>
        <location filename="../src/libsync/theme.cpp" line="54"/>
        <source>Status undefined</source>
        <translation>Stan niezdefiniowany</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="57"/>
        <source>Waiting to start sync</source>
        <translation>Trwa oczekiwanie na uruchomienie synchronizacji</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="60"/>
        <source>Sync is running</source>
        <translation>Synchronizacja uruchomiona</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="63"/>
        <source>Sync Success</source>
        <translation>Udana synchronizacja</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="66"/>
        <source>Sync Success, some files were ignored.</source>
        <translation>Synchronizacja ukończona, niektóre pliki zostały zignorowane.</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="69"/>
        <source>Sync Error</source>
        <translation>Błąd synchronizacji</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="72"/>
        <source>Setup Error</source>
        <translation>Błąd ustawień</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="75"/>
        <source>Preparing to sync</source>
        <translation>Przygotowuję do synchronizacji</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="78"/>
        <source>Aborting...</source>
        <translation>Anuluję...</translation>
    </message>
    <message>
        <location filename="../src/libsync/theme.cpp" line="81"/>
        <source>Sync is paused</source>
        <translation>Synchronizacja wstrzymana</translation>
    </message>
</context>
</TS>